//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by PkgAdmin.rc
//
#define IDC_PKGADMIN_LICENSE            26000
#define IDS_ABOUTBOX                    26001
#define IDD_PKGADMIN_DIALOG             26002
#define IDB_PKGADMIN_TREEICONS          26003
#define IDD_PKGADMIN_LICENSE            26004
#define IDC_PKGADMIN_ADD                26005
#define IDC_PKGADMIN_REMOVE             26006
#define IDC_PKGADMIN_TREE               26007
#define IDC_PKGADMIN_REPOSITORY         26009
#define IDR_PKGADMIN_MAINFRAME          26010
#define IDD_PKGADMIN_ABOUTBOX           26011
#define IDM_ABOUTBOX                    26016
#define IDD_PKGADMIN_WAIT               26017

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        26018
#define _APS_NEXT_COMMAND_VALUE         56000
#define _APS_NEXT_CONTROL_VALUE         26017
#define _APS_NEXT_SYMED_VALUE           26017
#endif
#endif
