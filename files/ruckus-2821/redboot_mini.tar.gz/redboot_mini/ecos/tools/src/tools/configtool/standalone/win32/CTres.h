//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Configtool.rc
//
#define IDD_ABOUTBOX                    22000
#define IDC_EDIT                        22001
#define IDC_EDIT_BROWSER                22002
#define IDB_HTML                        22003
#define IDB_HELP                        22004
#define IDB_SPLASH                      22005
#define IDR_MAINFRAME                   22006
#define IDC_BROWSE                      22007
#define IDR_CONTEXTMENU1                22008
#define IDR_OUTPUT_CONTEXT              22009
#define IDD_VIEW_SETTINGS_DIALOG        22010
#define IDD_CONFIGURATION_VIEW_OPTIONS_DIALOG 22011
#define IDD_HEADERS_DIALOG              22012
#define IDD_TOOLCHAINFOLDER_DIALOG      22013
#define IDB_BITMAP3                     22014
#define IDR_MISCBAR                     22015
#define IDR_HELPBAR                     22017
#define IDC_BROWSE_BROWSER              22020
#define IDC_RADIO_ASSOCIATED            22025
#define IDC_RADIO_CUSTOM                22026
#define IDC_RADIO_ASSOCIATED_BROWSER    22027
#define IDC_RADIO_CUSTOM_BROWSER        22028
#define IDC_STATIC_ABOUT                22031
#define IDC_RADIO_INTERNAL_BROWSER      22032
#define IDC_STATIC_ABOUT2               22032
#define IDC_HEADERSTATIC                22033
#define IDC_STATIC_DATETIME             22034
#define IDC_PANECOMBO                   22035
#define IDC_FONT                        22037
#define IDR_MLTFRAME                    22040
#define IDS_ECOS_HOME_URL               22041
#define IDS_ECOS_SOURCEWARE_URL         22042
#define IDS_RED_HAT_HOME_URL            22043
#define IDS_UITRON_HOME_URL             22044
#define IDS_ECOS_PR_URL                 22045
#define ID_BROWSE                       52000
#define ID_ALWAYS_ON_TOP                52001
#define ID_THERMOMETER                  52002
#define ID_RUN_SIM                      52003
#define ID_ENABLE_EXTENSIONS            52004
#define ID_EDIT_FINDAGAIN               52005
#define ID_VIEW_REFRESH                 52006
#define ID_GO_HOME                      52009
#define ID_VIEW_PROPERTIES              52011
#define ID_VIEW_HTML                    52012
#define ID_VIEW_SHORTDESC               52013
#define ID_BUILD_CONFIGURE              52014
#define ID_VIEW_OUTPUT                  52015
#define ID_BUILD_STOP                   52016
#define ID_CONFIGURATION_OPTIONS        52017
#define ID_BUILD_TESTS                  52018
#define ID_CONFIGURATION_CHECKRULES     52019
#define ID_CONFIGURATION_REFRESH        52020
#define ID_CONFIGURATION_REPOSITORY     52021
#define ID_VIEW_SETTINGS                52022
#define ID_LOG_SAVE                     52023
#define ID_TOOLS_PATHS                  52024
#define ID_EDIT_SAVE                    52025
#define ID_DOC_RED_HAT                  52026
#define ID_WINDOW_NEXT                  52027
#define ID_WINDOW_PREV                  52028
#define ID_HELP_RED_HATONTHEWEB         52029
#define ID_SUBMIT_PR                    52030
#define ID_GNUPRO_DOCUMENTATION         52031
#define ID_HELP_SUBMIT_PR               52032
#define ID_HELP_GNUPRO_DOCUMENTATION    52033
#define ID_HELP_ECOS                    52034
#define ID_HELP_UITRON                  52035
#define ID_HELP_ECOSHOME                52036
#define ID_BUILD_CLEAN                  52037
#define ID_TOOLS_SHELL                  52038
#define ID_VIEW_RULES                   52039
#define ID_BUILD_OPTIONS                52040
#define ID_TOOLS_OPTIONS                52041
#define ID_USERTOOLS_PATHS              52042
#define ID_VIEW_MLT                     52043
#define ID_BUILD_TEMPLATES              52044
#define ID_BUILD_PACKAGES               52045
#define ID_VIEW_CONFLICTS               52046
#define ID_MENU_VIEW_SETTINGS           52047
#define ID_VIEW_MLTBAR                  52048
#define ID_BUTTON40001                  52049
#define ID_BUTTON40006                  52050
#define ID_PROPERTIES                   52051
#define ID_TOOLS_ADMINISTRATION         52052
#define ID_FILE_EXPORT                  52057
#define ID_FILE_IMPORT                  52058
#define ID_EDIT_PLATFORMS               52059

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        22055
#define _APS_NEXT_COMMAND_VALUE         52060
#define _APS_NEXT_CONTROL_VALUE         22059
#define _APS_NEXT_SYMED_VALUE           22055
#endif
#endif
