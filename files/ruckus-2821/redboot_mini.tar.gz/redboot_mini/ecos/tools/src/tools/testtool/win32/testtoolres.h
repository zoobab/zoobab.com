//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by TestTool.rc
//
#define IDD_TT_ABOUTBOX                 24000
#define IDS_TT_ABOUTBOX                 24001
#define IDP_TT_SOCKETS_INIT_FAILED      24002
#define IDS_TT_OUTPUT                   24003
#define IDS_TT_SUMMARY                  24004
#define IDC_TT_TESTTIMEOUT              24005
#define IDC_TT_RADIO_REMOTE             24007
#define IDC_TT_RESOURCEHOST             24008
#define IDC_TT_RESOURCEPORT             24009
#define IDC_TT_RESET                    24010
#define IDC_TT_EXTENSION                24011
#define IDC_TT_RECURSE                  24013
#define IDC_TT_CONTROL2                 24017
#define IDC_TT_DOWNLOADTIMEOUT          24018
#define IDC_TT_SELECT_ALL               24019
#define IDC_TT_UNSELECT_ALL             24020
#define IDC_TT_REMOTEHOST               24021
#define IDC_TT_RUNTESTS_LIST            24022
#define IDC_TT_REMOTEPORT               24023
#define IDR_TT_MAINFRAME                24024
#define IDC_TT_RADIO_LOCAL              24025
#define IDD_TT_EXECUTION_PAGE           24026
#define IDD_TT_OUTPUT_PAGE              24027
#define IDC_TT_LOCAL_PORT               24028
#define IDD_TT_ADDFILEDIALOG            24029
#define IDC_TT_BAUD                     24030
#define IDD_TT_SUMMARY_PAGE             24031
#define IDR_TT_CONTEXTMENU              24032
#define IDR_TT_CONTEXTMENU1             24033
#define IDR_TT_CONTEXTMENU2             24034
#define IDD_TT_RUNTESTS_DIALOG          24035
#define IDD_TT_PROPERTIES               24036
#define IDD_TT_PROPERTIES2              24037
#define IDD_TT_PROPERTIES3              24038
#define IDC_TT_RADIO_TCPIP              24039
#define IDC_TT_EDIT                     24040
#define IDC_TT_FOLDER                   24041
#define IDC_TT_PLATFORM                 24042
#define IDC_TT_SPIN3                    24043
#define IDC_TT_SPIN4                    24044
#define IDC_TT_LOCALTCPIPHOST           24045
#define IDC_TT_LOCALTCPIPPORT           24046
#define IDC_TT_RADIO_SERIAL             24047
#define IDC_TT_ADD                      24048
#define IDC_TT_REMOVE                   24049
#define IDC_TT_LIST                     24050
#define IDC_TT_FARMED                   24051
#define IDC_TT_EXPLICIT                 24052
#define IDC_TT_SETTINGS                 24053
#define IDC_TT_DOWNLOADTIMEOUT_COMBO    24054
#define IDC_TT_STATIC_PLATFORM          24055
#define IDC_TT_TIMEOUT_COMBO            24056
#define IDC_TT_CLEAR                    24057
#define IDC_STATIC_EXECUTION            24059
#define IDC_TT_STATIC_RESET             24060
#define IDC_TT_STATIC_METHOD            24061
#define IDC_TT_STATIC_DOWNLOAD          24066
#define IDS_TT_RADIO_LOCAL              24079
#define IDS_TT_RADIO_REMOTE             24080
#define IDD_TT_PLATFORM                 24092
#define IDC_TT_NEW_PLATFORM_PREFIX      24093
#define IDD_TT_NEW_PLATFORM             24094
#define IDD_TT_PLATFORMS_DIALOG         24095
#define IDC_TT_NEW_PLATFORM_GDB         24096
#define IDC_TT_NEW_PLATFORM             24098
#define IDC_TT_DELETE_PLATFORM          24099
#define IDC_TT_ADD_PLATFORM             24100
#define IDC_TT_PLATFORM_LIST            24101
#define IDC_TT_MODIFY_PLATFORM          24104
#define IDC_TT_RESETSTRING              24107
#define IDC_EDIT1                       24108
#define IDC_INFERIOR                    24108
#define IDC_PROMPT                      24109
#define IDC_SERVER_SIDE_GDB             24110
#define ID_TT_EDIT_SAVE                 54000

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        24097
#define _APS_NEXT_COMMAND_VALUE         54001
#define _APS_NEXT_CONTROL_VALUE         24111
#define _APS_NEXT_SYMED_VALUE           24092
#endif
#endif
