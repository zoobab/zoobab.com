bin/nano-X & bin/logfont
