bin/nano-X -A $1 & bin/nxkbd & bin/nanowm & bin/nxterm & bin/nxterm & bin/nxroach -roaches 10 & sleep 10000
