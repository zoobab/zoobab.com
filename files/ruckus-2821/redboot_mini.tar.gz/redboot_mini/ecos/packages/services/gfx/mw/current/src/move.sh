bin/nano-X -p & bin/move; #sleep 10000
