bin/nano-X & bin/nanowm & bin/slider demos/nanox/slidebmp.bmp ; sleep 10000
