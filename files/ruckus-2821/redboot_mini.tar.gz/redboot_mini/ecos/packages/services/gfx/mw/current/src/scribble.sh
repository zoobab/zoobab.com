bin/nano-X & bin/nxkbd & bin/nxscribble & bin/nanowm & bin/nxterm & bin/nxterm & sleep 10000
