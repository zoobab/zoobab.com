bin/nano-X & bin/nxkbd & bin/nanowm & bin/nxterm & bin/demo & sleep 10000
