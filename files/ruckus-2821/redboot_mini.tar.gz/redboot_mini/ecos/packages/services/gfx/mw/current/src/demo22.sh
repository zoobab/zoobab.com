bin/nano-X & bin/nanowm & bin/demo2 & bin/demo2 & sleep 10000
