bin/nano-X & bin/nanowm & bin/ftdemo
