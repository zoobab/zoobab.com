bin/nano-X $1 & bin/nanowm & bin/world
