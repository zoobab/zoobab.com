bin/nano-X -p & bin/npanel
