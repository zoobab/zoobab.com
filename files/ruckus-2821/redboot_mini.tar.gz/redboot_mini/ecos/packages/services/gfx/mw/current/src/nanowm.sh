bin/nano-X & bin/nanowm & bin/demo6 bin/nanogui.ppm & bin/nxclock & sleep 10000
