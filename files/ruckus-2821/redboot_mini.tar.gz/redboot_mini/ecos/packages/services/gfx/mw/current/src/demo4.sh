bin/nano-X -e & bin/nxterm & bin/nanowm & sleep 10000
