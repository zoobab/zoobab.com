bin/nano-X -N & bin/nanowm & bin/nxview $1 $2; sleep 10000
