bin/nano-X & bin/nanowm & bin/launcher bin/launcher.cnf & sleep 10000
