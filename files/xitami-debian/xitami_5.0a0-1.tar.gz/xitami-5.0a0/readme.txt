This is the Xitami 5.0a0 source distribution. To build the package
run the command:

    sh build.sh

Under Linux/Unix, and under Windows, run this command from a console window:

    build

You will need MSVC installed for command line use. Please see www.openamq.org
for more details.
