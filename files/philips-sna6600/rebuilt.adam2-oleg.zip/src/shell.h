/*-----------------------------------------------------------------------------*/
/*                                                                             */
/*   Copyright (C) 1996-2003 by Texas Instruments, Inc.  All rights reserved.  */
/*   Copyright (C) 2001-2003 Telogy Networks.	    						   */
/*                                                                             */
/*-----------------------------------------------------------------------------*/

#ifndef	___SHELL_H___
#define	___SHELL_H___

extern int autoloadFlag;
#if defined(FTP_SERVER_SUPPORT) || defined(TFTP_SERVER_SUPPORT)
extern int crashFlag;
#endif	//defined(FTP_SERVER_SUPPORT) || defined(TFTP_SERVER_SUPPORT) Endif */ 

void fix_vector_for_linux(void);
void AppCopyVectors(void);
void init_env(void);
int executeProgram(int flag, bit32 address, int argc, char *argv[]);
int convert2num(char *str, bit32u *val);
bit32 myatox(char *str,bit32 *num);
void WriteToFlash(UINT8 *pDst, UINT8 *pSrc, UINT32 NumBytes);
bit32u erase(bit32 start, bit32u end);
#ifdef BATCH_SREC_SUPPORT
int batch(char *filename);
#endif
bit32u ShellMain(void);
bit32u ShellDoMultiCommand(char *lineptr);
bit32u ShellDoSingleCommand(char *lineptr);
bit32u dm(int argc,char *argv[]);
bit32u im(int argc,char *argv[]);
bit32 myatox(char *str,bit32 *num);
int BadAddress(bit32u adr);
bit32u infocmd(int argc,char *argv[]);
bit32u setmfreq(int argc,char *argv[]);
bit32u printenvcmd(int argc,char *argv[]);
bit32u setenvcmd(int argc,char *argv[]);
bit32u unsetenvcmd(int argc,char *argv[]);
bit32u fixenv(int argc,char *argv[]);
bit32u rebootcmd(int argc,char *argv[]);
bit32u erasecmd(int argc,char *argv[]);
bit32u adam2help(int argc,char *argv[]);
bit32u gocommand(int argc,char *argv[]);
bit32u memmapcmd(int argc,char *argv[]);
bit32u memop(int argc,char *argv[]);
#ifdef FTP_CLIENT_SUPPORT
bit32u ftpcmd(int argc,char *argv[]);
#endif
#ifdef PING_SUPPORT
bit32u pingcmd(int argc,char *argv[]);
#endif
#endif /* ___SHELL_H___ */

