/*-----------------------------------------------------------------------------*/
/*                                                                             */
/*   Copyright (C) 1996-2003 by Texas Instruments, Inc.  All rights reserved.  */
/*   Copyright (C) 2001-2003 Telogy Networks, Inc.							   */
/*                                                                             */
/*     IMPORTANT - READ CAREFULLY BEFORE PROCEEDING TO USE SOFTWARE.           */
/*                                                                             */
/*  This document is displayed for you to read prior to using the software     */
/*  and documentation.  By using the software and documentation, or opening    */
/*  the sealed packet containing the software, or proceeding to download the   */
/*  software from a Bulletin Board System(BBS) or a WEB Server, you agree to   */
/*  abide by the following Texas Instruments License Agreement. If you choose  */
/*  not to agree with these provisions, promptly discontinue use of the        */
/*  software and documentation and return the material to the place you        */
/*  obtained it.                                                               */
/*                                                                             */
/*                               *** NOTE ***                                  */
/*                                                                             */
/*  The licensed materials contain MIPS Technologies, Inc. confidential        */
/*  information which is protected by the appropriate MIPS Technologies, Inc.  */
/*  license agreement.  It is your responsibility to comply with these         */
/*  licenses.                                                                  */
/*                                                                             */
/*                   Texas Instruments License Agreement                       */
/*                                                                             */
/*  1. License - Texas Instruments (hereinafter "TI"), grants you a license    */
/*  to use the software program and documentation in this package ("Licensed   */
/*  Materials") for Texas Instruments broadband products.                      */
/*                                                                             */
/*  2. Restrictions - You may not reverse-assemble or reverse-compile the      */
/*  Licensed Materials provided in object code or executable format.  You may  */
/*  not sublicense, transfer, assign, rent, or lease the Licensed Materials    */
/*  or this Agreement without written permission from TI.                      */
/*                                                                             */
/*  3. Copyright - The Licensed Materials are copyrighted. Accordingly, you    */
/*  may either make one copy of the Licensed Materials for backup and/or       */
/*  archival purposes or copy the Licensed Materials to another medium and     */
/*  keep the original Licensed Materials for backup and/or archival purposes.  */
/*                                                                             */
/*  4. Runtime and Applications Software - You may create modified or          */
/*  derivative programs of software identified as Runtime Libraries or         */
/*  Applications Software, which, in source code form, remain subject to this  */
/*  Agreement, but object code versions of such derivative programs are not    */
/*  subject to this Agreement.                                                 */
/*                                                                             */
/*  5. Warranty - TI warrants the media to be free from defects in material    */
/*  and workmanship and that the software will substantially conform to the    */
/*  related documentation for a period of ninety (90) days after the date of   */
/*  your purchase. TI does not warrant that the Licensed Materials will be     */
/*  free from error or will meet your specific requirements.                   */
/*                                                                             */
/*  6. Remedies - If you find defects in the media or that the software does   */
/*  not conform to the enclosed documentation, you may return the Licensed     */
/*  Materials along with the purchase receipt, postage prepaid, to the         */
/*  following address within the warranty period and receive a refund.         */
/*                                                                             */
/*  TEXAS INSTRUMENTS                                                          */
/*  Application Specific Products, MS 8650                                     */
/*  c/o ADAM2 Application Manager                                              */
/*  12500 TI Boulevard                                                         */
/*  Dallas, TX 75243  - U.S.A.                                                 */
/*                                                                             */
/*  7. Limitations - TI makes no warranty or condition, either expressed or    */
/*  implied, including, but not limited to, any implied warranties of          */
/*  merchantability and fitness for a particular purpose, regarding the        */
/*  licensed materials.                                                        */
/*                                                                             */
/*  Neither TI nor any applicable licensor will be liable for any indirect,    */
/*  incidental or consequential damages, including but not limited to loss of  */
/*  profits.                                                                   */
/*                                                                             */
/*  8. Term - The license is effective until terminated.   You may terminate   */
/*  it at any other time by destroying the program together with all copies,   */
/*  modifications and merged portions in any form. It also will terminate if   */
/*  you fail to comply with any term or condition of this Agreement.           */
/*                                                                             */
/*  9. Export Control - The re-export of United States origin software and     */
/*  documentation is subject to the U.S. Export Administration Regulations or  */
/*  your equivalent local regulations. Compliance with such regulations is     */
/*  your responsibility.                                                       */
/*                                                                             */
/*                         *** IMPORTANT NOTICE ***                            */
/*                                                                             */
/*  Texas Instruments (TI) reserves the right to make changes to or to         */
/*  discontinue any semiconductor product or service identified in this        */
/*  publication without notice. TI advises its customers to obtain the latest  */
/*  version of the relevant information to verify, before placing orders,      */
/*  that the information being relied upon is current.                         */
/*                                                                             */
/*  TI warrants performance of its semiconductor products and related          */
/*  software to current specifications in accordance with TI's standard        */
/*  warranty. Testing and other quality control techniques are utilized to     */
/*  the extent TI deems necessary to support this warranty. Unless mandated    */
/*  by government requirements, specific testing of all parameters of each     */
/*  device is not necessarily performed.                                       */
/*                                                                             */
/*  Please be aware that Texas Instruments products are not intended for use   */
/*  in life-support appliances, devices, or systems. Use of a TI product in    */
/*  such applications without the written approval of the appropriate TI       */
/*  officer is prohibited. Certain applications using semiconductor devices    */
/*  may involve potential risks of injury, property damage, or loss of life.   */
/*  In order to minimize these risks, adequate design and operating            */
/*  safeguards should be provided by the customer to minimize inherent or      */
/*  procedural hazards. Inclusion of TI products in such applications is       */
/*  understood to be fully at the risk of the customer using TI devices or     */
/*  systems.                                                                   */
/*                                                                             */
/*  TI assumes no liability for TI applications assistance, customer product   */
/*  design, software performance, or infringement of patents or services       */
/*  described herein. Nor does TI warrant or represent that license, either    */
/*  expressed or implied, is granted under any patent right, copyright, mask   */
/*  work right, or other intellectual property right of TI covering or         */
/*  relating to any combination, machine, or process in which such             */
/*  semiconductor products or services might be or are used.                   */
/*                                                                             */
/*  All company and/or product names are trademarks and/or registered          */
/*  trademarks of their respective manaufacturers.                             */
/*                                                                             */
/*-----------------------------------------------------------------------------*/
/*																			   */
/*  Filename : printf.c												   	   	   */
/*																			   */	
/*  Description:															   */	
/*      Alternate sys_printf routines									  	   */
/*																			   */
/*  Revision history:														   */
/*      5 Jun91...Original version..........................Graham Short	   */	
/*      Butchered...........................................Mike Denio		   */	
/*-----------------------------------------------------------------------------*/                      

#include "_stdio.h"
#include "_stdarg.h"
#include "sio.h"
#include "support.h"
                      
/* REPLACE THIS MACRO                                                        */
void (*_PrintfOutStr)(char *) = SioOutStr;

#define  MAX_STRING_SIZE    162
#define  MAX_DIGIT_SIZE     64

#define  LEFT_JUSTIFIED 0x0001
#define  SIGNED         0x0002
#define  SPACE          0x0004
#define  ALTERNATE      0x0008
#define  LEADING_ZERO   0x0010
#define  PRECISION      0x0020
#define  SHORT_INT      0x0040
#define  LONG_INT       0x0080
#define  LONG_DOUBLE    0x0100
#define  UNSIGNED       0x0200

static int _int2str
(
    long  val,
    char  *buffer,
    int   width,
    int   precision,
    int   flag,
    char  type
)
{
   char          *ptr;
   char          *ptr2   = buffer;
   char          *bufend = &buffer[MAX_DIGIT_SIZE];
   int           negative = FALSE;
   char          ch=0;
   long          digit;
   unsigned long tmp;
   int           base=0;
   unsigned long uval;

   /* point to the end of the buffer */
   ptr = bufend;
   uval = val;         

   /* fill up the buffer with digits from the right */
   switch (type)
   {
      case 'd':   
      case 'i':   if (val < 0)
                  {
                     negative = TRUE;
                     uval     = -val;
                  }
      case 'u':   base = 10;           break;
      case 'o':   base = 8;            break;
      case 'x':   base = 16; ch = 'a'; break;
      case 'p':
      case 'X':   base = 16; ch = 'A'; break;
   }

   /* Convert short hex values to 16 bit                                     */
   if( (base==16) && !(flag&LONG_INT) )
        uval &= 0x0ffffffffl;

   while (uval)
   {
      tmp = uval / base;
      digit = uval - (tmp * base);
      *--ptr = (digit > 9) ? digit - 10 + ch : digit + '0';
      uval = tmp;
   }

   /* if we've not reached precision digits, pad with 0s */
   if (!(flag & PRECISION))
      precision = 1; /* default precision if not explicitly specified is 1 */
   precision -= bufend - ptr;
   if ((flag & ALTERNATE) && (type == 'o'))
      precision = 1; /* force a leading 0 */
   if (precision > 0)
   {
      while (precision--)
         *--ptr = '0';
   }

   if ((flag & ALTERNATE) && (type == 'x'))
   {
      *--ptr = 'x';
      *--ptr = '0';
   }
   else
   if ((flag & ALTERNATE) && (type == 'X'))
   {
      *--ptr = 'X';
      *--ptr = '0';
   }
   /* set sign or space prefix */
   if (negative)
      *--ptr = '-';
   else
   if (flag & SIGNED)
      *--ptr = '+';
   else
   if (flag & SPACE)
      *--ptr = ' ';

   if (flag & LEFT_JUSTIFIED)
   {
      /* copy the string to the start of the buffer */
      while(ptr < bufend)
         *ptr2++ = *ptr++;

      /* if larger width required, pad with spaces */
      width -= ptr2 - buffer;
      if (width > 0)
      {
         while (width--)
            *ptr2++ = ' ';
      }
   }
   else
   {
      ptr2 = buffer;
      /* if larger width required, pad with spaces or 0s */
      width -= bufend - ptr;
      if (width > 0)
      {
         if ((flag & LEADING_ZERO) && (!(flag & PRECISION)))
         {
            ch = '0';
            /* copy any sign prior to 0 filling */
            if ((negative) || (flag & (SIGNED | SPACE)))
               *ptr2++ = *ptr++;
         }
         else
            ch = ' ';
         while (width--)
            *ptr2++ = ch;
      }

      /* copy the string from the end of the buffer */
      while(ptr < bufend)
         *ptr2++ = *ptr++;
   }
   return ptr2 - buffer;
}

static int _str2str
(
    char *str,
    char *buffer,
    int  width,
    int  precision,
    int  flag
)
{
   int  ndigits;
   int  i;
   char *ptr = buffer;
   char *ptr2 = str;
                                  
   if (flag & PRECISION)
      for (i = 0; (i < precision) && (*ptr2++ != '\0'); i++);
   else
      for (i = 0; *ptr2++ != '\0'; i++);
   ndigits = i;
   
   /* left-padding if required */
   if ((!(flag & LEFT_JUSTIFIED)) && (width > ndigits))
   {
      width -= ndigits;
      while (width--)
         *ptr++ = ' ';
   }

   /* now copy the string */
   for (i = 0, ptr2 = str; i < ndigits; i++)
      *ptr++ = *ptr2++;

   /* right-padding if required */
   if ((flag & LEFT_JUSTIFIED) && (width > ndigits))
   {
      width -= ndigits;
      while (width--)
         *ptr++ = ' ';
   }
   return ptr - buffer;
}

static int _parsearg
(
char    **fmt,
va_list *arg,
char    *buffer,
int     n
)
{
   int     count          = 0;
   int     width          = 0;
   int     precision      = 0;
   int     flag           = 0;
   int     parsed_flags   = FALSE;
   char    *ptr   = *fmt;
   va_list ap  = *arg;
   char    ch,*cp;

   /* skip % */
   ptr++;

   /* parse the flags */
   while (!parsed_flags)
   {
      switch (*ptr++)
      {
         case '-' : flag |= LEFT_JUSTIFIED;     break;
         case '+' : flag |= SIGNED;             break;
         case ' ' : flag |= SPACE;              break;
         case '#' : flag |= ALTERNATE;          break;
         case '0' : flag |= LEADING_ZERO;       break;
         default  : parsed_flags = TRUE; --ptr; break;
      }
   }

   /* parse for a width */
   if (*ptr == '*')
   {
      width = va_arg(ap, int);
      if (width < 0)
      {
         flag |= LEFT_JUSTIFIED;
         width = -width;
      }
      ptr++;
   }
   else
      while (isdigit(*ptr))
         width = width * 10 + (*ptr++ - '0');

   /* parse for a precision */
   if (*ptr == '.')
   {
      flag |= PRECISION;
      ptr++;
      if (*ptr == '*')
      {
         precision = va_arg(ap, int);
         if (precision < 0)
         {
            /* for a negative precision, treat it as if it were missing */
            flag &= ~PRECISION;
            precision = 0;
         }
         ptr++;
      }
      else
         while (isdigit(*ptr))
            precision = precision * 10 + (*ptr++ - '0');
   }

   /* parse for short/long pointer flags */
   switch (*ptr++)
   {
      case 'h' : flag |= SHORT_INT;    break;
      case 'l' : flag |= LONG_INT;     break;
      case 'L' : flag |= LONG_DOUBLE;  break;
      default  : --ptr;                break;
   }

   /* now parse the types */
   switch (*ptr)
   {
      case 'd':   
      case 'i':
      case 'o':   
      case 'u':
      case 'x':
      case 'X':
                  count = _int2str((flag & LONG_INT) ? va_arg(ap, long) : va_arg(ap, int),
                                   buffer, width, precision, flag, *ptr);
                  break;
      case 'c':   ch = va_arg(ap, int);
                  flag |= PRECISION;
                  count = _str2str(&ch, buffer, width, 1, flag);
                  break;
      case 's':   cp=va_arg(ap, char *);
                  if (cp)
                    count = _str2str(cp, buffer, width, precision, flag);
                   else
                    count = _str2str("NULL", buffer, width, precision, flag);
                  break;
      case 'p':
                  count = _int2str(va_arg(ap, int), buffer, width, precision, flag, *ptr);
                  break;
      case 'n':
                  *(va_arg(ap, int *)) = n;
                  break;
      case '%':
                  *buffer = '%';
                  count = 1;
                  break;   
   }
   *fmt = ++ptr;
   *arg = ap;
   return count;
}

int _printf(char *dest, char *format, va_list ap)
{
   char buffer[MAX_STRING_SIZE];
   char *tstr;
   char *save,*fmt = format;
   int  n = 0; /* number of characters written */
   int  i,count;

   while (*fmt != '\0')
   {
      /* search for % or \0 */
      save = fmt;
      while ((*fmt != '\0') && (*fmt != '%'))
         fmt++;
      /* print out all characters parsed to the buffer */
      if ((count = (fmt - save)))
      {
         n += count;
         tstr = save;
         for(i=0; i<count; i++)
             *dest++ = *tstr++;
      }
      if (*fmt == '%')
      {
         i = _parsearg(&fmt, &ap, buffer, n);
         n += i;
         tstr = buffer;
         while( i-- )
             *dest++ = *tstr++;
      }
   }
   *dest++ = 0;
   return n;
}

int sys_printf(const char *format, ...)
{
   int     count;
   va_list ap;
   char    buffer[MAX_STRING_SIZE];

   va_start(ap, format);
   count = _printf(buffer, (char *)format, ap);
   va_end(ap);
   (*_PrintfOutStr)(buffer);
   return (count);
}

int sys_sprintf(char *s, const char *format, ...)
{
   register int count;
   va_list  ap;

   va_start(ap, format);
   count = _printf(s, (char *)format, ap);
   va_end(ap);
   return(count);
}

int sys_vprintf(const char *format, va_list arg)
{
   register int count;
   char     buffer[MAX_STRING_SIZE];

   count = _printf(buffer, (char *)format, arg);
 (*_PrintfOutStr)(buffer);
   return(count);
}

int sys_vsprintf(char *s, const char *format, va_list arg)
{
   register int count;

   count = _printf(s, (char *)format, arg);
   return(count);
}
void PrintfRedirect(void (*afunction)(char *))
{
  _PrintfOutStr=afunction;
}

void PrintfRestore()
{
  _PrintfOutStr=SioOutStr;
}

