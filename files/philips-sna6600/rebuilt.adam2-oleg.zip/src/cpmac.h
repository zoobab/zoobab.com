/*-----------------------------------------------------------------------------*/
/*                                                                             */
/*   Copyright (C) 2003 by Texas Instruments, Inc.  All rights reserved.       */
/*   Copyright (C) 2003 Telogy Networks.	    						       */
/*   Author: Nakshatra Saha <nakshatra@ti.com> 								   */
/*                                                                             */
/*-----------------------------------------------------------------------------*/

#ifndef _CPMAC_H
#define _CPMAC_H

/* #include <sbl/system.h> */
/* #include <sbl/errno.h> */
/*#include "stddef.h"*/
#include "hw.h"
/* #include "net.h" */

#define CPMAC_0_BASE    0x08610000
#define CPMAC_1_BASE    0x08612800

#if (CONF_CPMAC_IF == 1)
/* #ifndef INTERNAL_PHY by Oleg changed back to original */
#define CPMAC_BASE      KSEG1(CPMAC_1_BASE)
/* #else */
#elif (CONF_CPMAC_IF == 0)
#define CPMAC_BASE      KSEG1(CPMAC_0_BASE)  /* default CPMAC0 for tftp. */
#else
#error macro CONF_CPMAC_IF should have a value of either 0 or 1.
#endif

#define CH_MAX          8

#define LK_DN           0
#define LK_UP           1

typedef struct BUFF_DESC {
	struct BUFF_DESC  *next;
	char              *buff;
	u4                 buff_params;
	u4                 ctrl_n_len;
} BuffDesc;

#define TX_BD_COUNT   1
#define RX_BD_COUNT   5

typedef struct CPMAC_STATE {
	BuffDesc         tx[TX_BD_COUNT];
	BuffDesc         rx[RX_BD_COUNT];
	BuffDesc        *rx_next;         /* this should always be uncached. */
	BOOL             link_state;
} CpmacState;

#define BD_SOP    MASK(31, 31)
#define BD_EOP    MASK(30, 30)
#define BD_OWNS   MASK(29, 29)
#define BD_EOQ    MASK(28, 28)
#define BD_PCRC   MASK(26, 26)

/*
 * RX Buffer descriptor macros.
 */
#define BD_OVRUN  MASK(20, 20)
#define IS_OVRUN(bd) 

/* Macros. */
#define IS_SOP(bd)   ((bd)->ctrl_n_len & BD_SOP)
#define IS_EOP(bd)   ((bd)->ctrl_n_len & BD_EOP)
#define IS_OWNS(bd)  ((bd)->ctrl_n_len & BD_OWNS)
#define IS_EOQ(bd)   ((bd)->ctrl_n_len & BD_EOQ)

/*
 * Register Address/bit defines.
 */
#define CPMAC_A_TX_DMAHDP(ch)    (CPMAC_BASE + 0x600 + ((ch) * 4))
#define CPMAC_A_RX_DMAHDP(ch)    (CPMAC_BASE + 0x620 + ((ch) * 4))

#define CPMAC_A_RX_CTRL          (CPMAC_BASE + 0x004)
#define CPMAC_A_TX_CTRL          (CPMAC_BASE + 0x014)

#define CPMAC_A_RX_MBP           (CPMAC_BASE + 0x100)
#define CPMAC_A_RXUNIS           (CPMAC_BASE + 0x104)
#define CPMAC_A_RXUNIC           (CPMAC_BASE + 0x108)
#define CPMAC_A_RX_BO            (CPMAC_BASE + 0x110)
#define CPMAC_A_RX_FBUFF(ch)     (CPMAC_BASE + 0x140 + ((ch) * 4))

#define CPMAC_A_MACCTRL          (CPMAC_BASE + 0x160)
#define CPMAC_B_MACCTRL_MII      MASK(5, 5)
#define CPMAC_B_MACCTRL_TXFC     MASK(4, 4)
#define CPMAC_B_MACCTRL_RXFC     MASK(3, 3)
#define CPMAC_B_MACCTRL_DPLXM    MASK(0, 0)

#define CPMAC_A_MACST            (CPMAC_BASE + 0x164)

#define CPMAC_A_MACA_LO(ch)      (CPMAC_BASE + 0x1b0 + ((ch) * 4))
#define CPMAC_A_MACA_MED         (CPMAC_BASE + 0x1d0)
#define CPMAC_A_MACA_HI          (CPMAC_BASE + 0x1d4)

#define CPMAC_A_ST_RX_GOODFRAMES  (CPMAC_BASE + 0x200)
#define CPMAC_A_ST_RX_BROADCAST   (CPMAC_BASE + 0x204)
#define CPMAC_A_ST_RX_MULTICAST   (CPMAC_BASE + 0x208)
#define CPMAC_A_ST_RX_PAUSE       (CPMAC_BASE + 0x20c)
#define CPMAC_A_ST_RX_ERR_CRC     (CPMAC_BASE + 0x210)
#define CPMAC_A_ST_RX_ERR_ALIGNC  (CPMAC_BASE + 0x214)
#define CPMAC_A_ST_RX_OVERSIZED   (CPMAC_BASE + 0x218)
#define CPMAC_A_ST_RX_JABBER      (CPMAC_BASE + 0x21c)
#define CPMAC_A_ST_RX_UNDERSIZED  (CPMAC_BASE + 0x220)
#define CPMAC_A_ST_RX_FRAGMENTS   (CPMAC_BASE + 0x224)
#define CPMAC_A_ST_RX_FILTERED    (CPMAC_BASE + 0x228)
#define CPMAC_A_ST_RX_QOSFILTERED (CPMAC_BASE + 0x22c)
#define CPMAC_A_ST_RX_OCTETS      (CPMAC_BASE + 0x230)
#define CPMAC_A_ST_TX_GOODFRAMES  (CPMAC_BASE + 0x234)
#define CPMAC_A_ST_TX_BROADCAST   (CPMAC_BASE + 0x238)
#define CPMAC_A_ST_TX_MULTICAST   (CPMAC_BASE + 0x23c)
#define CPMAC_A_ST_TX_PAUSE       (CPMAC_BASE + 0x240)
#define CPMAC_A_ST_TX_DEFFERED    (CPMAC_BASE + 0x244)
#define CPMAC_A_ST_TX_COLLISION   (CPMAC_BASE + 0x248)
#define CPMAC_A_ST_TX_SINGLECOLL  (CPMAC_BASE + 0x24c)
#define CPMAC_A_ST_TX_MULTICOLL   (CPMAC_BASE + 0x250)
#define CPMAC_A_ST_TX_EXCESSCOLL  (CPMAC_BASE + 0x254)
#define CPMAC_A_ST_TX_LATECOLL    (CPMAC_BASE + 0x258)
#define CPMAC_A_ST_TX_UNDERRUN    (CPMAC_BASE + 0x25c)
#define CPMAC_A_ST_TX_CARRSENSEER (CPMAC_BASE + 0x260)
#define CPMAC_A_ST_TX_OCTETS      (CPMAC_BASE + 0x264)
#define CPMAC_A_ST_TX_OC_64       (CPMAC_BASE + 0x268)
#define CPMAC_A_ST_TX_OC_65_127   (CPMAC_BASE + 0x26c)
#define CPMAC_A_ST_TX_OC_128_255  (CPMAC_BASE + 0x270)
#define CPMAC_A_ST_TX_OC_256_511  (CPMAC_BASE + 0x274)
#define CPMAC_A_ST_TX_OC_512_1023 (CPMAC_BASE + 0x278)
#define CPMAC_A_ST_TX_OC_1024_U   (CPMAC_BASE + 0x27c)
#define CPMAC_A_ST_TX_NETOCTETS   (CPMAC_BASE + 0x280)
#define CPMAC_A_ST_RX_SOF_OVRUN   (CPMAC_BASE + 0x284)
#define CPMAC_A_ST_TX_MOF_OVRUN   (CPMAC_BASE + 0x288)
#define CPMAC_A_ST_TX_DMA_OVRUN   (CPMAC_BASE + 0x28c)
/*
 * Function prototypes.
 */
void delay(u4 units);
Status cpmac_init(void);
Status cpmac_rx_bd_init(BuffDesc *rx_bd_head);
Status cpmac_tx(char *buff, u4 pkt_sz);
Status cpmac_rx(char **buff, u4 *len);
void cpmac_stats(void);
void bd_dbg(BuffDesc *bd);
BOOL lk_st(u4 itf);

#endif /* _CPMAC_H */
