/*-----------------------------------------------------------------------------*/
/*                                                                             */
/*   Copyright (C) 1996-2003 by Texas Instruments, Inc.  All rights reserved.  */
/*   Copyright (C) 2001-2003 Telogy Networks.	    						   */
/*                                                                             */
/*-----------------------------------------------------------------------------*/

int SioVersion(void);
void SioLock(int lock);
int SioGetBaud(char *str,int *rb);
void SioReset(void);
void SioInit(void);
void IfFlowEnable(void);
void SioOutChar(char chr);
int SioTxEmpty(void);
void SioBackground(void);
void SioFlush(void);
void SioOutStr(char *str);
void SioOutStrNum(char *str,int num);
void SioOutDec(int num,int siz);
void SioOutStr1(char *str,int num);
int SioInCharCheck(char *al);
int SioInChar(void);
void SioDump(void);
