/*-----------------------------------------------------------------------------*/
/*                                                                             */
/*   Copyright (C) 1996-2003 by Texas Instruments, Inc.  All rights reserved.  */
/*   Copyright (C) 2001-2003 Telogy Networks.	    						   */
/*                                                                             */
/*   NOTE: THIS VERSION OF CODE IS MAINTAINED BY TELOGY NETWORKS AND NOT TI!   */
/*                                                                             */
/*-----------------------------------------------------------------------------*/

#ifndef _MAIN_H_
#define _MAIN_H_

#ifdef AR5D01
#define ProductIDStr	"AR5D01"
#else
#ifdef ACPEP
#define ProductIDStr	"ACPEP"
#else
#ifdef WA100
#define ProductIDStr	"WA100"
#else
#ifdef AR5W01
#define ProductIDStr	"AR5W01"
#else
#ifdef AR7DB
#define ProductIDStr	"AR7DB"
#else
#ifdef AR7RD
#define ProductIDStr	"AR7RD"
#else
#ifdef AR7WRD
#define ProductIDStr	"AR7WRD"
#else
#ifdef SEAD2
#define ProductIDStr	"SEAD2"
#else
#define ProductIDStr	"EVM3"
#endif /* SEAD2 */
#endif /* AR7WRD */
#endif /* AR7RD */
#endif /* AR7DB */
#endif /* AR5W01 */
#endif /* WA100 */
#endif /* ACPEP */
#endif /* AR5D01 */


//Addition by Charles for Show Flash Vendor promet 05-05-2004
#ifdef AMD
	#define FLASH_VENDOR_STRING	"AMD"
#else 
#ifdef INTEL
	#define FLASH_VENDOR_STRING	"INTEL"
#else
	#define FLASH_VENDOR_STRING	"NONE"
#endif	/* INTEL Endif */	
#endif	/* AMD Endif */

//Addition by Charles for Show code pattern promet 05-05-2004

#ifdef WAG2
	#define CODE_PATTERN_STRING	"WAG2"
#else
#ifdef WA2B
	#define CODE_PATTERN_STRING	"WA2B"
#else
#ifdef WA21
	#define	CODE_PATTERN_STRING 	"WA21"
#else
#ifdef WA22
	#define	CODE_PATTERN_STRING 	"WA22"
#else
#ifdef DWGA
	#define CODE_PATTERN_STRING	"DWGA"
#else
#ifdef DWGB
	#define CODE_PATTERN_STRING	"DWGB"
#else
#ifdef DWGE
	#define CODE_PATTERN_STRING	"DWGE"
#else
#ifdef DWG1
	#define CODE_PATTERN_STRING	"DWG1"
#else
#ifdef NONE
	#define	CODE_PATTERN_STRING "NONE"

#else
#ifdef AG1A
	#define	CODE_PATTERN_STRING "AG1A"
#else
#ifdef AG1B
	#define	CODE_PATTERN_STRING "AG1B"
#else
#ifdef AG2A
	#define	CODE_PATTERN_STRING "AG2A"
#else
#ifdef AG2B
	#define	CODE_PATTERN_STRING "AG2B"
#endif
#endif	/* AG1B Endif*/
#endif
#endif	/* AG1B Endif*/
#endif
#endif	/* AG1A Endif*/
#endif
#endif	/* NONE Endif*/
#endif	/* DWG1 Endif*/
#endif	/* DWGE Endif*/
#endif	/* DWGB Endif*/
#endif	/* DWGA Endif*/
#endif	/* WAG2 Endif */

void ResetMMS(void);
void DispStr(char *val);
void DispHex(int val);

/* Routines in Avalanche that main calls */

void SetRefClkDivReg(int v);
void SetRefClkPllReg(int v, int w);

bit32u getflashsize(bit32u base, bit32u size);

#if defined(AR7DB) || defined(AR7RD) || defined(AR7WRD)
void platform_init();
/* int cfg_cpufreq(bit32u freq); */
int cfg_cpufreq(bit32u sysf, bit32u cpuf, bit32u dbg_opt);
unsigned int get_mips_freq();
#endif /* AR7DB | AR7RD | AR7WRD */

#ifdef ACPEP
unsigned int get_clk_setting(unsigned int base_clk);
#endif /* ACPEP */

#endif /* _MAIN_H_ */
