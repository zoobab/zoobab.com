/*-----------------------------------------------------------------------------*/
/*                                                                             */
/*   Copyright (C) 1999-2003 by Texas Instruments, Inc.  All rights reserved.  */
/*   Copyright (C) 2001-2003 Telogy Networks.	    						   */
/*                                                                             */
/*   NOTE: THIS VERSION OF CODE IS MAINTAINED BY TELOGY NETWORKS AND NOT TI!   */
/*                                                                             */
/*-----------------------------------------------------------------------------*/

#ifndef EMACPHY_INC
#define EMACPHY_INC

#define PHY_CONTROL_REG       0
  #define PHY_RESET           (1<<15)
  #define PHY_LOOP            (1<<14)
  #define PHY_100             (1<<13)
  #define AUTO_NEGOTIATE_EN   (1<<12)
  #define PHY_PDOWN           (1<<11)
  #define PHY_ISOLATE         (1<<10)
  #define RENEGOTIATE         (1<<9)
  #define PHY_FD              (1<<8)

#define PHY_STATUS_REG        1
  #define NWAY_COMPLETE       (1<<5)
  #define NWAY_CAPABLE        (1<<3)
  #define PHY_LINKED          (1<<2)

#define NWAY_ADVERTIZE_REG    4
#define NWAY_REMADVERTISE_REG 5
  #define NWAY_FD100          (1<<8)
  #define NWAY_HD100          (1<<7)
  #define NWAY_FD10           (1<<6)
  #define NWAY_HD10           (1<<5)
  #define NWAY_SEL            (1<<0)
  #define NWAY_AUTO           (1<<0)

/*Called once at the begining of time */
void EmacMdioInit(int macbase, int *PhyState, int cpufreq);

/*Called every 10 mili Seconds, returns TRUE if there has been a mode change */
int EmacMdioTic(int macbase,int *PhyState);

/*Called to set Phy mode */
void EmacMdioSetPhyMode(int macbase,int *PhyState,int PhyMode);

/*Calls to retreive info after a mode change! */
int  EmacMdioGetDuplex(int macbase,int *PhyState);   /*Get The Duplex info   */
int  EmacMdioGetSpeed(int macbase,int *PhyState);    /*Get the Speed Info    */
int  EmacMdioGetPhyNum(int macbase,int *PhyState);   /*Get The Phy Number    */
int  EmacMdioGetLinked(int macbase,int *PhyState);   /*Get The Phy Linked State*/
void EmacMdioLinkChange(int macbase,int *PhyState);  /*Used to report a link change event!*/

#endif /* EMACPHY_INC */
