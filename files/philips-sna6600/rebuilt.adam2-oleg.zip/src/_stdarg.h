/*-----------------------------------------------------------------------------*/
/*                                                                             */
/*   Copyright (C) 1993-2003 by Texas Instruments, Inc.  All rights reserved.  */
/*   Copyright (C) 2001-2003 Telogy Networks.	    						   */
/*                                                                             */
/*-----------------------------------------------------------------------------*/

#ifndef _STDARG_ADAM2_
#define _STDARG_ADAM2_

typedef char *va_list;
 /********************************************************************/
/* WARNING - va_arg will not work for "float" type, must use double */
/* ALSO NOTE THAT DOUBLES MUST BE DOUBLE WORD ALIGNED               */
/********************************************************************/
#define va_end(_ap)
  
#define va_start(_ap, _parmN) \
         (_ap = ((char *)&(_parmN)) + (sizeof(_parmN) < 4 ? 4 : sizeof(_parmN)))

#define va_arg(_ap, _type)                                       \
         ((sizeof(_type) == sizeof(double)                       \
             ? ((_ap = (void *)(((int)_ap + 7) & ~7)),           \
	        (_ap += 8), (*(_type *)(_ap - 8)))               \
	     : ((_ap += 4), (*(_type *)(_ap - 4)))))


#endif
