/*-----------------------------------------------------------------------------*/
/*                                                                             */
/*   Copyright (C) 1996-2003 by Texas Instruments, Inc.  All rights reserved.  */
/*   Copyright (C) 2001-2003 Telogy Networks, Inc.							   */
/*                                                                             */
/*     IMPORTANT - READ CAREFULLY BEFORE PROCEEDING TO USE SOFTWARE.           */
/*                                                                             */
/*  This document is displayed for you to read prior to using the software     */
/*  and documentation.  By using the software and documentation, or opening    */
/*  the sealed packet containing the software, or proceeding to download the   */
/*  software from a Bulletin Board System(BBS) or a WEB Server, you agree to   */
/*  abide by the following Texas Instruments License Agreement. If you choose  */
/*  not to agree with these provisions, promptly discontinue use of the        */
/*  software and documentation and return the material to the place you        */
/*  obtained it.                                                               */
/*                                                                             */
/*                               *** NOTE ***                                  */
/*                                                                             */
/*  The licensed materials contain MIPS Technologies, Inc. confidential        */
/*  information which is protected by the appropriate MIPS Technologies, Inc.  */
/*  license agreement.  It is your responsibility to comply with these         */
/*  licenses.                                                                  */
/*                                                                             */
/*                   Texas Instruments License Agreement                       */
/*                                                                             */
/*  1. License - Texas Instruments (hereinafter "TI"), grants you a license    */
/*  to use the software program and documentation in this package ("Licensed   */
/*  Materials") for Texas Instruments broadband products.                      */
/*                                                                             */
/*  2. Restrictions - You may not reverse-assemble or reverse-compile the      */
/*  Licensed Materials provided in object code or executable format.  You may  */
/*  not sublicense, transfer, assign, rent, or lease the Licensed Materials    */
/*  or this Agreement without written permission from TI.                      */
/*                                                                             */
/*  3. Copyright - The Licensed Materials are copyrighted. Accordingly, you    */
/*  may either make one copy of the Licensed Materials for backup and/or       */
/*  archival purposes or copy the Licensed Materials to another medium and     */
/*  keep the original Licensed Materials for backup and/or archival purposes.  */
/*                                                                             */
/*  4. Runtime and Applications Software - You may create modified or          */
/*  derivative programs of software identified as Runtime Libraries or         */
/*  Applications Software, which, in source code form, remain subject to this  */
/*  Agreement, but object code versions of such derivative programs are not    */
/*  subject to this Agreement.                                                 */
/*                                                                             */
/*  5. Warranty - TI warrants the media to be free from defects in material    */
/*  and workmanship and that the software will substantially conform to the    */
/*  related documentation for a period of ninety (90) days after the date of   */
/*  your purchase. TI does not warrant that the Licensed Materials will be     */
/*  free from error or will meet your specific requirements.                   */
/*                                                                             */
/*  6. Remedies - If you find defects in the media or that the software does   */
/*  not conform to the enclosed documentation, you may return the Licensed     */
/*  Materials along with the purchase receipt, postage prepaid, to the         */
/*  following address within the warranty period and receive a refund.         */
/*                                                                             */
/*  TEXAS INSTRUMENTS                                                          */
/*  Application Specific Products, MS 8650                                     */
/*  c/o ADAM2 Application Manager                                              */
/*  12500 TI Boulevard                                                         */
/*  Dallas, TX 75243  - U.S.A.                                                 */
/*                                                                             */
/*  7. Limitations - TI makes no warranty or condition, either expressed or    */
/*  implied, including, but not limited to, any implied warranties of          */
/*  merchantability and fitness for a particular purpose, regarding the        */
/*  licensed materials.                                                        */
/*                                                                             */
/*  Neither TI nor any applicable licensor will be liable for any indirect,    */
/*  incidental or consequential damages, including but not limited to loss of  */
/*  profits.                                                                   */
/*                                                                             */
/*  8. Term - The license is effective until terminated.   You may terminate   */
/*  it at any other time by destroying the program together with all copies,   */
/*  modifications and merged portions in any form. It also will terminate if   */
/*  you fail to comply with any term or condition of this Agreement.           */
/*                                                                             */
/*  9. Export Control - The re-export of United States origin software and     */
/*  documentation is subject to the U.S. Export Administration Regulations or  */
/*  your equivalent local regulations. Compliance with such regulations is     */
/*  your responsibility.                                                       */
/*                                                                             */
/*                         *** IMPORTANT NOTICE ***                            */
/*                                                                             */
/*  Texas Instruments (TI) reserves the right to make changes to or to         */
/*  discontinue any semiconductor product or service identified in this        */
/*  publication without notice. TI advises its customers to obtain the latest  */
/*  version of the relevant information to verify, before placing orders,      */
/*  that the information being relied upon is current.                         */
/*                                                                             */
/*  TI warrants performance of its semiconductor products and related          */
/*  software to current specifications in accordance with TI's standard        */
/*  warranty. Testing and other quality control techniques are utilized to     */
/*  the extent TI deems necessary to support this warranty. Unless mandated    */
/*  by government requirements, specific testing of all parameters of each     */
/*  device is not necessarily performed.                                       */
/*                                                                             */
/*  Please be aware that Texas Instruments products are not intended for use   */
/*  in life-support appliances, devices, or systems. Use of a TI product in    */
/*  such applications without the written approval of the appropriate TI       */
/*  officer is prohibited. Certain applications using semiconductor devices    */
/*  may involve potential risks of injury, property damage, or loss of life.   */
/*  In order to minimize these risks, adequate design and operating            */
/*  safeguards should be provided by the customer to minimize inherent or      */
/*  procedural hazards. Inclusion of TI products in such applications is       */
/*  understood to be fully at the risk of the customer using TI devices or     */
/*  systems.                                                                   */
/*                                                                             */
/*  TI assumes no liability for TI applications assistance, customer product   */
/*  design, software performance, or infringement of patents or services       */
/*  described herein. Nor does TI warrant or represent that license, either    */
/*  expressed or implied, is granted under any patent right, copyright, mask   */
/*  work right, or other intellectual property right of TI covering or         */
/*  relating to any combination, machine, or process in which such             */
/*  semiconductor products or services might be or are used.                   */
/*                                                                             */
/*  All company and/or product names are trademarks and/or registered          */
/*  trademarks of their respective manaufacturers.                             */
/*                                                                             */
/*-----------------------------------------------------------------------------*/

#include "_stdio.h"
#include "support.h"
#include "env.h"
#include "hw.h"
#include "shell.h"

//wwzh add for tftp server
#ifdef TFTP_SERVER_SUPPORT
extern int tftp_update;
#endif

#if defined(DHCP_SUPPORT) || defined(FTP_SERVER_SUPPORT) || defined(TFTP_SERVER_SUPPORT)
#include "tinyip.h"
#endif

#if defined(AR7DB) || defined(AR7RD) || defined(AR7WRD)
extern unsigned int _SysFrequency;
#endif
		
#ifdef EB
#define BEO 3
#else
#define BEO 0
#endif

#define SIO0__BASE    	UARTB_BASE 
#define SIO0__OFFSET   	4
#define SIO0__EN       	1
#define SIO0__FDEN     	1
#define SIO0__RSTMASK  	0x42
#define SIO1__BASE     	UARTA_BASE
#define SIO1__OFFSET   	4
#define SIO1__EN       	1
#define SIO1__FDEN     	0
#define SIO1__RSTMASK  	0x01

#define SIO0_RDAT (*(volatile char *)(SIO0__BASE+(SIO0__OFFSET*0)+BEO))
#define SIO0_TDAT (*(volatile char *)(SIO0__BASE+(SIO0__OFFSET*0)+BEO))
#define SIO0_IE   (*(volatile char *)(SIO0__BASE+(SIO0__OFFSET*1)+BEO))
#define SIO0_IIR  (*(volatile char *)(SIO0__BASE+(SIO0__OFFSET*2)+BEO))
#define SIO0_LC   (*(volatile char *)(SIO0__BASE+(SIO0__OFFSET*3)+BEO))
#define SIO0_MC   (*(volatile char *)(SIO0__BASE+(SIO0__OFFSET*4)+BEO))
#define SIO0_LS   (*(volatile char *)(SIO0__BASE+(SIO0__OFFSET*5)+BEO))
#define SIO0_MS   (*(volatile char *)(SIO0__BASE+(SIO0__OFFSET*6)+BEO))

#define SIO1_RDAT (*(volatile char *)(SIO1__BASE+(SIO1__OFFSET*0)+BEO))
#define SIO1_TDAT (*(volatile char *)(SIO1__BASE+(SIO1__OFFSET*0)+BEO))
#define SIO1_IE   (*(volatile char *)(SIO1__BASE+(SIO1__OFFSET*1)+BEO))
#define SIO1_IIR  (*(volatile char *)(SIO1__BASE+(SIO1__OFFSET*2)+BEO))
#define SIO1_LC   (*(volatile char *)(SIO1__BASE+(SIO1__OFFSET*3)+BEO))
#define SIO1_MC   (*(volatile char *)(SIO1__BASE+(SIO1__OFFSET*4)+BEO))
#define SIO1_LS   (*(volatile char *)(SIO1__BASE+(SIO1__OFFSET*5)+BEO))
#define SIO1_MS   (*(volatile char *)(SIO1__BASE+(SIO1__OFFSET*6)+BEO))

/* LSR status */
#define SIO_LS_RX            0x01    /* Character ready             */
#define SIO_LS_OE            0x02    /* RX-ERROR: Overrun           */
#define SIO_LS_PE            0x04    /* RX-ERROR: Parity            */
#define SIO_LS_FE            0x08    /* RX-ERROR: Framing (stop bit)*/
#define SIO_LS_BI            0x10    /* 'BREAK' detected            */
#define SIO_LS_TE            0x20    /* Transmit Holding empty      */
#define SIO_LS_TI            0x40    /* Transmitter empty (IDLE)    */
#define SIO_LS_FIFOERR       0x80    /* RX-ERROR: FIFO              */

/* MSR status */
#define SIO_MS_CTS           0x10    /* Clear to send               */
#define SIO_MS_DSR           0x20    /* Data Set Ready              */
#define SIO_MS_RI            0x40    /* Ring Indicator              */
#define SIO_MS_DCD           0x80    /* Data carrier detect         */

int AvSio0Inited = 0;
int AvSio1Inited = 0;
int sflow = 0;
int siolock = 0;
int siolast = 0;

void main_Handler (void);

int SioVersion(void) 
  { 
  return(0x01); 
  } 

void SioLock(int lock)
  {
  siolock=lock;
  }

int SioGetBaud(char *str,int *rb)
  {
  char *cp,sbaud[30];
  int i,baudtmp,commas;

  baudtmp=0;
  commas=0;
  cp=sys_getenv(str);
  if (cp)
    { 
    for(i=0;(*cp)&&(i<((sizeof sbaud)-1));i++,cp++)
      sbaud[i]=*cp;
    sbaud[i]=0;
    for(cp=sbaud;*cp;cp++)
      if (*cp==',')
        {
        *cp=0;
        commas++;
        }
    baudtmp=atoui(sbaud);
    }
  if (baudtmp)
    *rb=baudtmp;
  return((baudtmp)&&(commas==4));
  }

void SioReset(void)
  {
  AvSio0Inited=0;
  AvSio1Inited=0;
  }

void SioInit(void)
  {
  int baud,avbaud,requested_baud0,requested_baud1,cpufreq;
  char ctmp;

  siolast=0;
  siolock=FALSE;
  
#if defined(AR7DB) || defined(AR7RD) || defined(AR7WRD)
  {
    int mips_async;
    mips_async = REG32_R(0xa8611a00, 25, 25);
    if(mips_async == 0)
       cpufreq=_CpuFrequency/2;
    else
       cpufreq=_SysFrequency/2;
  }
#else
  cpufreq=_PbusFrequency;
#endif

  requested_baud0=38400;
  requested_baud1=38400;
  SioGetBaud("modetty0",&requested_baud0);
  SioGetBaud("modetty1",&requested_baud1);

  if (cpufreq<500000)   //Deal with QuickTurn slowness
   {
   requested_baud0=1200;
   requested_baud1=1200;
   }

  /* Try our best to get as close to the baud rate as possible */

  AvSio0Inited=0;
  AvSio1Inited=0;
  sflow=0;

  CLK_PDCR=0;

  baud=(3686400/requested_baud0);
  if ((baud%16)>7) baud+=8;
  baud/=16;

  avbaud=((cpufreq)/requested_baud0);
  if ((avbaud%16)>7) avbaud+=8;
  avbaud/=16;

  if (SIO0__EN)
    {
    RESET_PRCR|=SIO0__RSTMASK;
    if ( ((SIO0_LS&0x60)==0x60) && ((SIO0_MC&0xc0)==0) )
      {
      if (SIO0__RSTMASK&0x40)
        GPIO_EN&=0xffffff00;   /*Enable Uart B pins to output                */
      SIO0_LC=0x03;      /*Clear Divisor latch                               */
      SIO0_IE=0x00;      /*Disable all interrupts                            */
      SIO0_MC=0x00;      /*Set modem control                                 */
      SIO0_IIR=0x00;     /*Set fifo disabled                                 */
      SIO0_LC=0x83;      /*Set divisor latch                                 */
      if (SIO0__RSTMASK)
        {
        SIO0_RDAT=avbaud;  /*Set baud rate LSB                               */
        SIO0_IE=avbaud>>8; /*Set baud rate MSB                               */
        }
       else
        {
        SIO0_RDAT=baud;  /*Set baud rate LSB                                 */
        SIO0_IE=baud>>8; /*Set baud rate MSB                                 */
        }
      SIO0_LC=0x03;      /*Set word length                                   */
      SIO0_MC=0x0f;      /*Set modem control                                 */
      SIO0_IIR=0x41;     /*Set fifo enabled(Signal at 4 bytes)               */
      AvSio0Inited=1;      

      ctmp =SIO0_LS;
      ctmp|=SIO0_RDAT;
      ctmp|=SIO0_MS;
      ctmp|=SIO0_IIR;

      if ((SIO0_MS&SIO_MS_CTS)&&(SIO0__FDEN))
        {
        SIO0_MC=0x2f;    /*Set modem control, enable AutoFlowControl         */
        sflow=1;
        }
      }
    }

  baud=(3686400/requested_baud1);
  if ((baud%16)>7) baud+=8;
  baud/=16;

  avbaud=((cpufreq)/requested_baud1);
  if ((avbaud%16)>7) avbaud+=8;
  avbaud/=16;

  if (SIO1__EN)
    {
    RESET_PRCR|=SIO1__RSTMASK;
    if ( ((SIO1_LS&0x60)==0x60) && ((SIO1_MC&0xc0)==0) )
      {
      if (SIO1__RSTMASK&0x40)
        GPIO_EN&=0xffffff00;   /*Enable Uart B pins to output                */
      SIO1_LC=0x03;      /*Clear Divisor latch                               */
      SIO1_IE=0x00;      /*Disable all interrupts                            */
      SIO1_MC=0x00;      /*Set modem control                                 */
      SIO1_IIR=0x00;     /*Set fifo disabled                                 */
      SIO1_LC=0x83;      /*Set divisor latch                                 */
      if (SIO1__RSTMASK)
        {
        SIO1_RDAT=avbaud;  /*Set baud rate LSB                               */
        SIO1_IE=avbaud>>8; /*Set baud rate MSB                               */
        }
       else
        {
        SIO1_RDAT=baud;  /*Set baud rate LSB                                 */
        SIO1_IE=baud>>8; /*Set baud rate MSB                                 */
        }
      SIO1_LC=0x03;      /*Set word length                                   */
      SIO1_MC=0x0f;      /*Set modem control                                 */
      SIO1_IIR=0x41;     /*Set fifo enabled(Signal at 4 bytes)               */
      AvSio1Inited=1;      

      ctmp =SIO1_LS;
      ctmp|=SIO1_RDAT;
      ctmp|=SIO1_MS;
      ctmp|=SIO1_IIR;

      if ((SIO1_MS&SIO_MS_CTS)&&(SIO1__FDEN))
        {
        SIO1_MC=0x2f;    /*Set modem control, enable AutoFlowControl         */
        sflow=1;
        }
      }
    }
  }

void IfFlowEnable(void)
  {

  if (sflow) return;

  if ((AvSio0Inited)&&(SIO0__FDEN))
    {
    if (SIO0_MS&SIO_MS_CTS)
      {
      SIO0_MC=0x2f;    /*Set modem control, enable AutoFlowControl           */
      sflow=1;
      }
    }

  if ((AvSio1Inited)&&(SIO1__FDEN))
    {
    if (SIO1_MS&SIO_MS_CTS)
      {
      SIO1_MC=0x2f;    /*Set modem control, enable AutoFlowControl           */
      sflow=1;
      }
    }
  }

void SioOutChar(char chr)
  {
  int i;

  i=0;
  
  if (((AvSio0Inited)&&(!siolock))||
      ((AvSio0Inited)&&(siolast==0)))
    {
    while((SIO0_LS&SIO_LS_TE)==0)
      i++;
    SIO0_TDAT=chr;
    }

  if (((AvSio1Inited)&&(!siolock))||
      ((AvSio1Inited)&&(siolast==1)))
    {
    while((SIO1_LS&SIO_LS_TE)==0)
      i++;
    SIO1_TDAT=chr;
    }
  }

/* Return the tx status of the open serial ports */
int SioTxEmpty()
  {

  if (((AvSio0Inited)&&(!siolock))||
      ((AvSio0Inited)&&(siolast==0)))
    {
    if((SIO0_LS&SIO_LS_TE)==0)
      return(FALSE);
    }

  if (((AvSio1Inited)&&(!siolock))||
      ((AvSio1Inited)&&(siolast==1)))
    {
    if((SIO1_LS&SIO_LS_TE)==0)
      return(FALSE);
    }
  return(TRUE);
  }

void SioBackground(void)
  {
  }

void SioFlush(void)     
{

  if (AvSio0Inited)
    {
    do 
      {
      if ((SIO0_LS&0x60)!=0x60)  
        SioBackground();
      }while((SIO0_LS&0x60)!=0x60);
    }
  if (AvSio1Inited)
    {
    do 
      {
      if ((SIO1_LS&0x60)!=0x60)  
        SioBackground();
      }while((SIO1_LS&0x60)!=0x60);
    }
  SioBackground();  
}  

void SioOutStr(char *str)
  {
  while (*str)
    {
    if (*str=='\n')
      SioOutChar(13);
    SioOutChar(*str++);
    }
  }

void SioOutStrNum(char *str,int num)
  {
  while (num)
    {
    if (*str=='\n')
      SioOutChar(13);
    SioOutChar(*str++);
    num--;
    }
  }

void SioOutDec(int num,int siz)
  {

  if (num>=10)
    {
    SioOutDec(num/10,siz-1);
    }
  SioOutChar((num%10)+'0');
  }

void SioOutStr1(char *str,int num)
  {
  while (*str)
    {
    if (*str=='\n')
      SioOutChar(13);
    if ((*str=='%')&&((str[1]=='c')||(str[1]=='d')||(str[1]=='s')))
      {
      str++;
      switch (*str)
        {
        case 'c': SioOutChar(num);
                  break;
        case 'd': SioOutDec(num,0);
                  break;
        case 's': SioOutStr((char *)num);
                  break;
        default:  break;
        }
      if (*str)
        str++;
      }
     else
      SioOutChar(*str++);
    }
  }

int SioInCharCheck(char *al)
  {

  if (((AvSio0Inited)&&(!siolock))||
      ((AvSio0Inited)&&(siolast==0)))
    {
    if (SIO0_LS&SIO_LS_RX)
      {
      *al=SIO0_RDAT;
      siolast=0;
      return(TRUE);
      }
    }
  if (((AvSio1Inited)&&(!siolock))||
      ((AvSio1Inited)&&(siolast==1)))
    {
    if (SIO1_LS&SIO_LS_RX)
      {
      *al=SIO1_RDAT;
      siolast=1;
      return(TRUE);
      }
    }
  return(FALSE);
  }


int SioInChar(void)
  {
  char achar = 0;
  
  while(1)
    {
    if (((AvSio0Inited)&&(!siolock))||
        ((AvSio0Inited)&&(siolast==0)))
      {
      if (SIO0_LS&SIO_LS_RX)
        {
        achar=SIO0_RDAT;
        siolast=0;				
        }
      }
    if (((AvSio1Inited)&&(!siolock))||
        ((AvSio1Inited)&&(siolast==1)))
      {
      if (SIO1_LS&SIO_LS_RX)
        {
        achar=SIO1_RDAT;
        siolast=1;        
        }
      }
	
	if (achar != 0)
	  {
	  if (autoloadFlag == TRUE)
	    autoloadFlag = FALSE;
	  return(achar);
	  }
	main_Handler();	
	}
  }

#define AUTOLOAD_TIMEOUT_SECS	8  	/* Wait 5 secs before loading OS; PCApp can connect within this time */
#define REBOOT_TIMEOUT_SECS		3 	/* Wait 3 secs before rebooting the target */
#define CRASH_TIMEOUT_SECS		1   /* LED timer for crash notification */

extern void t_clear(void);
extern int t_get(void);

void main_Handler (void)
{
	static UINT32 autoload_timeout = 0;
	static int timeoutvalue = 0;
	static char *cp = NULL;
	
#if defined(DHCP_SUPPORT) || defined(FTP_SERVER_SUPPORT) || defined(TFTP_SERVER_SUPPORT)
	/* Check for IP Packets. */
	ip_Handler();
#endif
	
#ifdef TFTP_SERVER_SUPPORT
	//wwzh add for tftp server 
	//if tftp client is connected, STOP loading OS
	if (tftp_update == 1)
		autoloadFlag = FALSE;
#endif

#ifdef FTP_SERVER_SUPPORT
	{
		static UINT32 reboot_timeout = 0;
		static UINT32 crash_timeout = 0;
		static int led_flag = 0;
		
		/* Check for reboot Flag set, start the timer for 5 secs before 
		 * rebooting the system. */
		if (rebootFlag)
		{
			t_clear();
			reboot_timeout = t_get() + GetTicks(REBOOT_TIMEOUT_SECS);
			rebootFlag = FALSE;
			sys_printf("Rebooting the system in %d secs...\n", REBOOT_TIMEOUT_SECS);
		}
		if ((reboot_timeout != 0) && (t_get() > reboot_timeout))
			reboot();

		/* If ftp session is closed, start it again. */
		if (ftpServerStatus == STATUS_NONE)
			FTPServer();
		/* STOP loading OS, if PCApp is connected */
		else if (ftpServerStatus != STATUS_WELCOME)
			autoloadFlag = FALSE; 
	
		/* crash notification through LED */
		if ((crashFlag != CRASH_NONE) && (crash_timeout == 0))
		{
			crash_timeout = t_get() + (GetTicks(CRASH_TIMEOUT_SECS))/3;
		
			/* STOP loading OS, if a crash is identified */
			autoloadFlag = FALSE;
		}
		if ((crash_timeout != 0) && t_get() > crash_timeout)
		{
			toggle_leds(led_flag);
			if (crashFlag == CRASH_KERNEL)
				led_flag = !led_flag;
			else if (crashFlag == CRASH_FS)
			{
				led_flag++;
				if (led_flag >= 4)
					led_flag = 1;
			}
			crash_timeout = 0;
		}	
	}
#endif
	
	/* Check for autoloadFlag set, start the timer for autoload_timeout/AUTOLOAD_TIMEOUT_SECS
	 * before giving control to the Linux kernel. */
	if (autoloadFlag == TRUE)	
	{
		if (autoload_timeout == 0)
		{
			t_clear();
	    	timeoutvalue = (cp = sys_getenv("autoload_timeout")) ? atoui(cp) : AUTOLOAD_TIMEOUT_SECS;
		  	sys_printf("\nPress any key to abort OS load, or wait %d seconds for OS to boot...\n", timeoutvalue);
			autoload_timeout = t_get() + GetTicks(timeoutvalue);
		}
		else if (t_get() > autoload_timeout)
		{
  	  		int argc = 1;
		  	char *argv[1];  	
			argv[0] = "go";
			gocommand(argc, argv);		
			autoloadFlag = FALSE;
		}
	}
}

#if 0
bit32 RxOverrun, RxError, RxBits;
void SioDump(void)
  {
  sys_printf("RxOverrun: %d, RxError: %d, ",RxOverrun,RxError);
  sys_printf("bits:%8x\n",RxBits);
  }
#endif

