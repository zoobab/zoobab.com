/*------------------------------------------------------------------------------*/
/*                                                                             	*/
/*   Copyright (C) 1993-2003 by Texas Instruments, Inc.  All rights reserved.  	*/
/*   Copyright (C) 2001-2003 Telogy Networks.	    						   	*/
/*                                                                             	*/
/*																				*/
/* 	FILE:	stdio.h		Standard I/O include file								*/
/*																				*/
/* 	DESCRIPTION:																*/
/*		This file contains function declarations for standard I/O functions.	*/
/*																				*/
/* 	HISTORY:																	*/
/*		26Feb01	BEGR	Updated to isolate stdio functions only					*/
/*		01Dec00	DRB		Original version written								*/
/*------------------------------------------------------------------------------*/

#ifndef _STDIO
#define _STDIO


#include "sysdefs.h"
#include "_stdarg.h"

/*typedef unsigned size_t;*/
extern char *strcat(char *s1, const char *s2);
extern char *strcpy(char *s1, const char *s2);
extern char *strchr(const char *s, int c);
extern char *strrchr(char *s, int	c);
extern int strncmp(const char * cs,const char * ct,size_t count);
extern size_t strlen(const char *s);
extern void* sys_malloc(size_t);
extern void* sys_realloc(void*,size_t);
extern void sys_free(void*);

#ifdef _UTILS_
#include "_ctype.h"
#define sys_printf printf
#define sys_sprintf sprintf
#define sys_malloc malloc
#define sys_realloc realloc
#define sys_free free
#define FILE FFS_FILE
#define SEEK_SET FFS_SEEK_SET
#define SEEK_CVR FFS_SEEK_CVR
#define SEEK_END FFS_SEEK_END
#endif

#define FFS_SEEK_SET  (0x0000)
#define FFS_SEEK_CUR  (0x0001)
#define FFS_SEEK_END  (0x0002)

typedef struct _fs_sFILE	
          {
          bit32	_AvailableBytes;            /* Available Bytes in buffer        */
          struct _fs_sFILE *SubFileSystem;  /* Pointer to sub file system       */
          bit8	*_NextBytePtr;	            /* next byte from/to here in buffer */
          bit8	*_BufferBase;	            /* the malloc pointer               */
          bit8  _SubSystemType;             /* File Subsystem Type              */
          bit8	_FileState;	                /* the state of the file            */
          }FFS_FILE;

int sys_printf(const char *format, ...); 
int sys_sprintf(char *s, const char *format, ...);
int sys_vprintf(const char *format, va_list arg);
int sys_vsprintf(char *s, const char *format, va_list arg); 
int sys_fprintf(FFS_FILE *fp, const char *format, ...);
#define ADAM2_MAX_FN 80 /* This is more of a convention rather than a rule to be followed */

FFS_FILE *fopen(const char *filename, const char *type);
size_t fread(void *ptr, size_t size, size_t nitems, FFS_FILE *stream);
size_t fwrite(const void *ptr, size_t size, size_t nitems, FFS_FILE *stream);
int fseek(FFS_FILE *stream, bit32 offset, int ptrname);
void rewind(FFS_FILE *stream);
extern int remove(const char *);
bit32 ftell(FFS_FILE *stream);
int fflush(FFS_FILE *stream);
int feof(FFS_FILE *stream);
int fclose(FFS_FILE *stream);
void PrintfRedirect(void (*afunction)(char *));
void PrintfRestore(void);
char *fgets(char *buffer, size_t size, FFS_FILE *stream);

/* Sio Library entries */
extern int SioVersion(void);
extern void SioInit(void);
extern void SioOutChar(char);
extern void SioOutStr(char *);
int SioTxEmpty(void);
extern void SioFlush(void);
extern int SioInChar(void);
extern int SioInCharCheck(char *);
#if 0
extern void SioDump(void);
#endif

#define getch 	SioInChar
#define getchar SioInChar
#define putchar SioOutChar

#ifndef _ERRNO_
#define _ERRNO_

/* NOTE: In general, error codes should be handled through the "syserror"
 * system -- see "syserror.h".
 * The errno.h include file is only included for std c compatability reasons.
 */


/*
 * Error codes for standard library functions,
 * - add new ones when required
 */

#define ERANGE          34      /* Result not representable             */

extern int errno;

#endif  /* _ERRNO_ */

void AllDone(unsigned int val);

void GetInputLine(char *str,int len,char *leagals);

/* File Library entries */

int FileVersion(void);
void _FileSystemInit(void);   

FFS_FILE *ffs_fopen(const char *filename, const char *type);
int ffs_fseek(FFS_FILE *stream, bit32 offset, int ptrname);
size_t ffs_fread(void *ptr, size_t size, size_t nitems, FFS_FILE *stream);
size_t ffs_fwrite(const void *ptr, size_t size, size_t nitems, FFS_FILE *stream);
int ffs_fclose(FFS_FILE *stream);  

bit32 ffs_fgetc(FFS_FILE *fh);
void ffs_rewind(FFS_FILE *stream); 

bit32 ffs_ftell(FFS_FILE *stream);
int ffs_fflush(FFS_FILE *stream);
int ffs_feof(FFS_FILE *);

unsigned int atoui(char *cp);
void _FCBCloseWriteFiles(void);
bit32u GetCurrentDateTime(void);

#endif
