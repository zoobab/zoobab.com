/*-----------------------------------------------------------------------------*/
/*                                                                             */
/*   Copyright (C) 1999-2003 by Texas Instruments, Inc.  All rights reserved.  */
/*   Copyright (C) 2001-2003 Telogy Networks.	    						   */
/*                                                                             */
/*-----------------------------------------------------------------------------*/

#ifndef	___FILES_H___
#define	___FILES_H___

#define FILE_WAIT_TIME 4800000l

#define FILER   0x02
#define FOPEN   0x01
#define FREAD   0x02
#define FWRITE  0x03
#define FCLOSE  0x04
#define FALIVE  0x05
#define FREWIND 0x06
#define FTELL   0x07
#define FEOF    0x08
#define FFLUSH  0x09
#define FSEEK   0x0a
#define FINIT   0x0b
#define FREMOVE 0x0c

int FileVersion(void);
void Zap(int i);
void _FileSystemInit(void);
void sfs_InitFileSystem(void);
void _FilePutString(const char *str);
int _FileGetByte(char *cVal);
void _FilePutShort(short sVal);
void _FilePutBit32(bit32 lVal);
int _FileHandlerResponce(char cVal);
int _FileHandlerCheck(void);
int _FileGetBit32(bit32 *lVal);
int _SioFileRemove(const char *file_name);
FFS_FILE *_SioFileOpen(const char *file_name, const char *mode);
int _SioFileClose(FFS_FILE *handle);
size_t _SioFileRead(void *buf, size_t size, size_t count, FFS_FILE *fp);
size_t _SioFileWrite(const void *buf, size_t size, size_t count, FFS_FILE *fp);
bit32 fgetc(FFS_FILE *fh);
int IsFileExist(char *ifile, char *imode);
int remove(const char *filename);

int  _SioFileSeek(FFS_FILE *stream, bit32 offset, int ptrname);

int sys_fprintf(FFS_FILE *fp, const char *format, ...);

#endif


