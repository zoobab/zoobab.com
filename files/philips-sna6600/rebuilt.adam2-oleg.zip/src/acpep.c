/*-----------------------------------------------------------------------------*/
/*                                                                             */
/*   Copyright (C) 1999-2003 by Texas Instruments, Inc.  All rights reserved.  */
/*   Copyright (C) 2001-2003 Telogy Networks.	    						   */
/*                                                                             */
/*   NOTE: THIS VERSION OF CODE IS MAINTAINED BY TELOGY NETWORKS AND NOT TI!   */
/*-----------------------------------------------------------------------------*/

#include "_stdio.h"
#include "env.h"
#include "main.h"
#include "hw.h"

unsigned int SetupCpuFrequency()
{
  return(0);
}


bit32u GetCurrentDateTime()
{
  return(0);
}

/* This function returns the current clock speed based upon the PLL, DIV and base clock setting */  
unsigned int get_clk_setting(unsigned int base_clk)
{
	bit32u			mips_pll_setting;
	bit32u			mips_div_setting;
	unsigned int	pll_factor;
		
	mips_div_setting = (0xF & TNETD53XX_REG32(TNETD53XX_MIPS_DIV))+1; /* Divisor is a 4 bit N+1 divisor */		
	base_clk = base_clk / mips_div_setting;
	
	mips_pll_setting = TNETD53XX_REG32(TNETD53XX_MIPS_PLL);	

	/* Get the PLL multiplication factor */
	pll_factor = ((mips_pll_setting & 0xF000) >>12) + 1;
	
	/* Check if we're in divide mode or multiply mode */
	if((mips_pll_setting & 0x1)	== 1)
	{
		if((mips_pll_setting & 0x0802) == 0x802) /* See if PLLNDIV & PLLDIV are set */
		{
			if(mips_pll_setting & 0x1000)
			{
				/* clk = base_clk * (k-1) / 4)*/
				return((base_clk * (pll_factor - 1)) >>2);
			}
			else
			{
				/* clk = base_clk * k /2 */
				return((base_clk * pll_factor) >> 1);
			}
		}
		else
		{	
			if(pll_factor == 0x10)
			{
				pll_factor = 1;
			}
			return(base_clk*pll_factor);
		}
	}
	else		/* We're in divide mode */
	{
		if(pll_factor < 0x10)
		{
			/* clk = base_clk /2 */
			return(base_clk >> 1);
		}
		else
		{
			/* clk = base_clk / 4 */
			return(base_clk >> 2);
		}
	}
	return(0); /* Should never reach here */
}
