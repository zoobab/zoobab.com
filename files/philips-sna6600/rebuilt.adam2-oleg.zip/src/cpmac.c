/*------------------------------------------------------------------------------*/
/*                                                                             	*/
/*   Copyright (C) 2003 by Texas Instruments, Inc.  All rights reserved.  		*/
/*   Copyright (C) 2003 Telogy Networks.	    						   		*/
/*                                                                             	*/
/*     IMPORTANT - READ CAREFULLY BEFORE PROCEEDING TO USE SOFTWARE.           	*/
/*                                                                             	*/
/*  This document is displayed for you to read prior to using the software     	*/
/*  and documentation.  By using the software and documentation, or opening    	*/
/*  the sealed packet containing the software, or proceeding to download the   	*/
/*  software from a Bulletin Board System(BBS) or a WEB Server, you agree to   	*/
/*  abide by the following Texas Instruments License Agreement. If you choose  	*/
/*  not to agree with these provisions, promptly discontinue use of the        	*/
/*  software and documentation and return the material to the place you        	*/
/*  obtained it.                                                               	*/
/*                                                                             	*/
/*                               *** NOTE ***                                  	*/
/*                                                                             	*/
/*  The licensed materials contain MIPS Technologies, Inc. confidential        	*/
/*  information which is protected by the appropriate MIPS Technologies, Inc.  	*/
/*  license agreement.  It is your responsibility to comply with these         	*/
/*  licenses.                                                                  	*/
/*                                                                             	*/
/*                   Texas Instruments License Agreement                       	*/
/*                                                                             	*/
/*  1. License - Texas Instruments (hereinafter "TI"), grants you a license    	*/
/*  to use the software program and documentation in this package ("Licensed   	*/
/*  Materials") for Texas Instruments broadband products.                      	*/
/*                                                                             	*/
/*  2. Restrictions - You may not reverse-assemble or reverse-compile the      	*/
/*  Licensed Materials provided in object code or executable format.  You may  	*/
/*  not sublicense, transfer, assign, rent, or lease the Licensed Materials    	*/
/*  or this Agreement without written permission from TI.                      	*/
/*                                                                             	*/
/*  3. Copyright - The Licensed Materials are copyrighted. Accordingly, you    	*/
/*  may either make one copy of the Licensed Materials for backup and/or       	*/
/*  archival purposes or copy the Licensed Materials to another medium and     	*/
/*  keep the original Licensed Materials for backup and/or archival purposes.  	*/
/*                                                                             	*/
/*  4. Runtime and Applications Software - You may create modified or          	*/
/*  derivative programs of software identified as Runtime Libraries or         	*/
/*  Applications Software, which, in source code form, remain subject to this  	*/
/*  Agreement, but object code versions of such derivative programs are not    	*/
/*  subject to this Agreement.                                                 	*/
/*                                                                             	*/
/*  5. Warranty - TI warrants the media to be free from defects in material    	*/
/*  and workmanship and that the software will substantially conform to the    	*/
/*  related documentation for a period of ninety (90) days after the date of   	*/
/*  your purchase. TI does not warrant that the Licensed Materials will be     	*/
/*  free from error or will meet your specific requirements.                   	*/
/*                                                                             	*/
/*  6. Remedies - If you find defects in the media or that the software does   	*/
/*  not conform to the enclosed documentation, you may return the Licensed     	*/
/*  Materials along with the purchase receipt, postage prepaid, to the         	*/
/*  following address within the warranty period and receive a refund.         	*/
/*                                                                             	*/
/*  TEXAS INSTRUMENTS                                                          	*/
/*  Application Specific Products, MS 8650                                     	*/
/*  c/o ADAM2 Application Manager                                              	*/
/*  12500 TI Boulevard                                                         	*/
/*  Dallas, TX 75243  - U.S.A.                                                 	*/
/*                                                                             	*/
/*  7. Limitations - TI makes no warranty or condition, either expressed or    	*/
/*  implied, including, but not limited to, any implied warranties of          	*/
/*  merchantability and fitness for a particular purpose, regarding the        	*/
/*  licensed materials.                                                        	*/
/*                                                                             	*/
/*  Neither TI nor any applicable licensor will be liable for any indirect,    	*/
/*  incidental or consequential damages, including but not limited to loss of  	*/
/*  profits.                                                                   	*/
/*                                                                             	*/
/*  8. Term - The license is effective until terminated.   You may terminate   	*/
/*  it at any other time by destroying the program together with all copies,   	*/
/*  modifications and merged portions in any form. It also will terminate if   	*/
/*  you fail to comply with any term or condition of this Agreement.           	*/
/*                                                                             	*/
/*  9. Export Control - The re-export of United States origin software and     	*/
/*  documentation is subject to the U.S. Export Administration Regulations or  	*/
/*  your equivalent local regulations. Compliance with such regulations is     	*/
/*  your responsibility.                                                       	*/
/*                                                                             	*/
/*                         *** IMPORTANT NOTICE ***                            	*/
/*                                                                             	*/
/*  Texas Instruments (TI) reserves the right to make changes to or to         	*/
/*  discontinue any semiconductor product or service identified in this        	*/
/*  publication without notice. TI advises its customers to obtain the latest  	*/
/*  version of the relevant information to verify, before placing orders,      	*/
/*  that the information being relied upon is current.                         	*/
/*                                                                             	*/
/*  TI warrants performance of its semiconductor products and related          	*/
/*  software to current specifications in accordance with TI's standard        	*/
/*  warranty. Testing and other quality control techniques are utilized to     	*/
/*  the extent TI deems necessary to support this warranty. Unless mandated    	*/
/*  by government requirements, specific testing of all parameters of each     	*/
/*  device is not necessarily performed.                                       	*/
/*                                                                             	*/
/*  Please be aware that Texas Instruments products are not intended for use   	*/
/*  in life-support appliances, devices, or systems. Use of a TI product in    	*/
/*  such applications without the written approval of the appropriate TI       	*/
/*  officer is prohibited. Certain applications using semiconductor devices    	*/
/*  may involve potential risks of injury, property damage, or loss of life.   	*/
/*  In order to minimize these risks, adequate design and operating            	*/
/*  safeguards should be provided by the customer to minimize inherent or      	*/
/*  procedural hazards. Inclusion of TI products in such applications is       	*/
/*  understood to be fully at the risk of the customer using TI devices or     	*/
/*  systems.                                                                   	*/
/*                                                                             	*/
/*  TI assumes no liability for TI applications assistance, customer product   	*/
/*  design, software performance, or infringement of patents or services       	*/
/*  described herein. Nor does TI warrant or represent that license, either    	*/
/*  expressed or implied, is granted under any patent right, copyright, mask   	*/
/*  work right, or other intellectual property right of TI covering or         	*/
/*  relating to any combination, machine, or process in which such             	*/
/*  semiconductor products or services might be or are used.                   	*/
/*                                                                             	*/
/*  All company and/or product names are trademarks and/or registered          	*/
/*  trademarks of their respective manaufacturers.                             	*/
/*                                                                             	*/
/*																				*/
/* cpmac.c: SANGAM CPMAC driver.												*/
/*																				*/
/* Author: Nakshatra Saha <nakshatra@ti.com>									*/
/*------------------------------------------------------------------------------*/

#define BD_OFFSET     0
#define RX_BUFF_SZ    1548

#define TX_DELAY      10000
#define RX_DELAY      500000
#define TRX_MIN_DELAY 100

CpmacState    cpmac_sw_state;
u1            sys_et_addr[6];
u1            et_bcast_addr[6] = {0xff, 0xff, 0xff, 0xff, 0xff, 0xff};
CpmacState   *cpmac_st = NULL;

void FlushICache();
void FlushDCache();

void delay(u4 units)
{
	volatile u4  ii;
	for (ii = 0; ii < units; ii++);
}

/* SBL_ERESCRUNCH: failed to malloc buffer for rx bds. */
Status cpmac_init (void)
{
	u4   ii;
    volatile unsigned int pp;

  	Move(sed_lclEthAddr, sys_et_addr, sizeof(eth_HwAddress));

	if (cpmac_st != NULL) {
#if CPMAC_DEBUG
		sys_printf("\nInit called multiple times.");
#endif
		return SBL_SUCCESS;
	}
	cpmac_st = (CpmacState *)KSEG1(&cpmac_sw_state); /* Placed in uncached */

	/* Explicitly reset and bring it out of reset, the CPMAC.
	 * NOTE: EMAC0 is reset here only.
	 */
	REG32_RMW(0xa8611600, 17, 17, 0);
	delay(1000);
	REG32_RMW(0xa8611600, 17, 17, 1);
	delay(1000);
	
	/*
	 * Zero all of TX/RX DMA state head descriptor pointer registers.
	 */
	for (ii = 0; ii < CH_MAX; ii++) {
		REG32_W(CPMAC_A_TX_DMAHDP(ii), 0);
		REG32_W(CPMAC_A_RX_DMAHDP(ii), 0);
	}
	
	/* Enable TX/RX in Control registers.
	 */
	REG32_W(CPMAC_A_TX_CTRL, 1);
	REG32_W(CPMAC_A_RX_CTRL, 1);
	
	/* 
	 * Initialize the other registers as required - MII EN should be done
	 * at the end.
	 */
	REG32_W(CPMAC_A_RXUNIS, 1);    /* initialize `only' ch 0 */
	REG32_W(CPMAC_A_RXUNIC, 0xfe);
	REG32_W(CPMAC_A_RX_BO, BD_OFFSET);
	
	/* Set the MAC address. */
	for (ii = 0; ii < CH_MAX; ii++) {
		REG32_W(CPMAC_A_MACA_LO(ii), sys_et_addr[5] + ii);
	}
	REG32_W(CPMAC_A_MACA_MED, sys_et_addr[4]);
	REG32_W(CPMAC_A_MACA_HI,  sys_et_addr[0] | (sys_et_addr[1] << 8) |
		                    (sys_et_addr[2] << 16) | (sys_et_addr[3] << 24));

	REG32_RMW(CPMAC_BASE + 0x10c, 15, 0, 0x5dc);

	/* enable broadcast */
	REG32_RMW(CPMAC_BASE + 0x100, 13, 8, 0x20);
#if CPMAC_DEBUG
	sys_printf("\nallowed pkt sz: 0x%x", REG32_R(CPMAC_BASE + 0x10c, 31, 0));
#endif
	
	/* 
	 * Initialize cpmac_st, as required, eg link_state, rx_next, et al.
	 */ 
	cpmac_st->link_state = LK_DN;
	cpmac_st->rx_next = &cpmac_st->rx[0];
	
	/* 
	 * Initialize the TX/RX buffer descriptors.
	 */
	for (ii = 0; ii < TX_BD_COUNT; ii++) {
		/* Clear only the OWNS bit for the cpmac_tx to start smoothly. */
		cpmac_st->tx[ii].ctrl_n_len = 0;
	}

	if (SBL_SUCCESS != cpmac_rx_bd_init(cpmac_st->rx)) {
		return SBL_EFAILURE;
	}

	REG32_W(CPMAC_A_MACCTRL, (CPMAC_B_MACCTRL_MII |  /*| 
							  CPMAC_B_MACCTRL_TXFC |
							  CPMAC_B_MACCTRL_RXFC | */
							  CPMAC_B_MACCTRL_DPLXM));
	/* sekhar */
    for(pp=0;pp<600000; pp++);
	
    FlushICache();
	FlushDCache();
    
#ifdef CPMAC_DEBUG
    sys_printf("PHY CLK SOURCE: %d\n", REG32_R(0xA8611A00, 21,20));
#endif


	return SBL_SUCCESS;
}

/*
 * rx_bd_head should be passed as a pointer to an array of rx bds.
 * This routine initializes the rx bds as well as sets the RX DMA HDP.
 *
 * rx_bd_head passed should be in KSEG1.
 *
 * SBL_SUCCESS: Success.
 * SBL_EFAILURE: Caller should exit.
 * SBL_ERESCRUNCH: Caller should exit.
 */

/* char rx_buf[RX_BD_COUNT*RX_BUFF_SZ + (5 * RX_BD_COUNT)];*/
char rx_buf[RX_BD_COUNT][RX_BUFF_SZ + 5];

Status cpmac_rx_bd_init(BuffDesc *rx_bd_head)
{
	u4  ii;
    char* tmp;

	if (rx_bd_head == NULL) {
		return SBL_EFAILURE;
	}
     
	for (ii = 0; ii < RX_BD_COUNT; ii++) {
		rx_bd_head[ii].next = (BuffDesc *)((ii < RX_BD_COUNT - 1) ?
									PHYS(&rx_bd_head[ii + 1]) : NULL);

	tmp = &rx_buf[ii][0];
	tmp = (char *)(((((int)tmp + 3)/4) * 4) + 2);

#ifdef CPMAC_DEBUG
    sys_printf("buf %d: %08x\n", ii, tmp);
#endif

		if ((rx_bd_head[ii].buff = (char *) PHYS(tmp)) == NULL) {
			return SBL_ERESCRUNCH;
		}
		
		rx_bd_head[ii].buff_params = 0; /* clears the buffer offset. */
		rx_bd_head[ii].buff_params = RX_BUFF_SZ & MASK(15, 0);

		rx_bd_head[ii].ctrl_n_len = 0;
		rx_bd_head[ii].ctrl_n_len |= BD_OWNS;
	}

	/* Set the RX DMA HDP. Only 1 channel (0) is used. */
	/* debug. */
	if (REG32_R(CPMAC_A_RX_DMAHDP(0), 31, 0) != 0) {
		sys_printf("\nPanic: RX DMA HDP is not cleared before setting !");
		for (;;);
	}
  
	REG32_W(CPMAC_A_RX_DMAHDP(0), PHYS(rx_bd_head));

	/* Set the Free Buffer Count reg, for flow control. */
	REG32_W(CPMAC_A_RX_FBUFF(0), RX_BD_COUNT);

	return SBL_SUCCESS;
}

/* Returns:
 * SBL_SUCCESS: Success.
 * SBL_ETIMEOUT: Timeout to tx.
 * SBL_ELKDN: Link is down.
 * SBL_ERESCRUNCH: TX BD not free.
 *
 * buff status:
 * - buff passed by caller should be in KSEG1.
 * - If tx successful, buff is freed.
 * - If link goes down after updating tx BD, or timeout happens buff is locked. 
 *     Can not be reused (by caller).
 * - If resource crunch, buff can be reused (by caller).
 */
Status cpmac_tx(char *buff, u4 pkt_sz)
{
	BuffDesc  *tx_bd;
	u4         ii, pp;
	u4         ret = FALSE;
#ifdef CPMAC_DEBUG
	sys_printf("Entered CpMac Tx\n");
#endif
	
	if ((cpmac_st->link_state = lk_st(0)) == LK_DN) {
		return SBL_ELKDN;
	}
	/* TX BD update should be in uncached region. */
	tx_bd = &cpmac_st->tx[0];

#ifdef CPMAC_DEBUG
    sys_printf("TX BD: 0x%08x\n",tx_bd);
    sys_printf("TX BF: 0x%08x\n",buff);
#endif

	if (!(tx_bd->ctrl_n_len & BD_OWNS)) {
		/* Free. Update and send the buffer. */
		tx_bd->buff = (char *)PHYS(buff);
		tx_bd->next = PHYS(0);  /* PHYS is a placeholder. */
		tx_bd->buff_params = 0; /* This clears the buffer offset. */
		tx_bd->ctrl_n_len = 0;  /* This clears the control bits, holding the 
								   last tx status.
								 */
		tx_bd->buff_params = tx_bd->ctrl_n_len = pkt_sz & MASK(15, 0);
		tx_bd->ctrl_n_len |= BD_SOP | BD_EOP | BD_OWNS;
		bd_dbg(&cpmac_st->tx[0]);

        FlushDCache();
		/* Start the tx process. */
		REG32_W(CPMAC_A_TX_DMAHDP(0), PHYS(tx_bd));
		
	} else {
		/* debug. */
		sys_printf("\nNo free TX BD found !");

		return SBL_ERESCRUNCH;
	}

	/* Tx process has been started. Pend till it's complete. */
	for (ii = 0; ii < TX_DELAY/TRX_MIN_DELAY; ii++) {
		pp = 0;
		while(pp++ < TRX_MIN_DELAY) {
			if (!IS_OWNS(tx_bd)) {
				ret = TRUE;
				break;
			}
		} /* while */

		if (ret == TRUE)
			break;
		if ((cpmac_st->link_state = lk_st(0)) == LK_DN)
			return SBL_ELKDN;
	} /* for */

	if (ret == TRUE) {
		#if CPMAC_DEBUG
		sys_printf("TX delay: ii: %d, pp: %d", ii, pp);
		#endif
		pp = 0;
		while (pp++ < 50) {
			if (REG32_R(CPMAC_A_TX_DMAHDP(0), 31, 0) == 0)
				break;
		}
		if (pp == 50) {
			sys_printf("\nPanic: TX DMA HDP is not cleared still !");
			for (;;);
		}
	/*	_free((void *)KSEG0(buff)); */
		return SBL_SUCCESS;
	}
	return SBL_ETIMEOUT;
}

/* 
 * SBL_SUCCESS:
 * SBL_ELKDN:
 * SBL_ETIMEOUT:
 * SBL_EFAILURE: failed to malloc buffers for rx. Caller should exit.
 */
Status cpmac_rx(char **buff, u4 *len)
{
	BuffDesc  *rx_bd;
    
    /* sys_wb_invalidate_dchache(); */

    rx_bd = cpmac_st->rx_next; /* rx_next is always uncached. */

	*buff = NULL;	

	/* debug. */
	if (rx_bd == NULL) {
		sys_printf("\nPanic: rx_next not updated !");
		for (;;);
	}

	if (IS_OWNS(rx_bd)) {
		/* No pkts pending. */
		if ((cpmac_st->link_state = lk_st(0)) == LK_DN) {
			return SBL_ELKDN;
		}
		return SBL_ETIMEOUT;
	}
	/* 
	 * Pkt received. process to return it. NOTE: return one by one.
	 */
	bd_dbg(rx_bd);
	/* Debug. This should not be there if the buff size is max and hw is
	 * correct.
	 */
	if (!IS_SOP(rx_bd) || !IS_EOP(rx_bd)) {
		sys_printf("\nERR: SOP missing OR rx pkt spans multiple buffs. "
				   "Not supported currently.");
		return SBL_EFAILURE;
	}

	/* not sensing overrun; pass crc (as MBP reg disables); teardown. */
	/* fetch buffer pointer and packet length to return to caller. */
	*buff = (char *)(KSEG1(rx_bd->buff));
#ifdef CPMAC_DEBUG
	sys_printf("Address in cpmac_rx: 0x%08x\n", *buff);
#endif
	*len  = rx_bd->ctrl_n_len & MASK(15, 0);

	/* Debug. */
	if ((rx_bd->ctrl_n_len & MASK(15, 0)) != 
									(rx_bd->buff_params & MASK(15, 0))) {
		sys_printf("\nPanic: rx sz mismatch");
		for (;;);
	}

	if (IS_EOQ(rx_bd)) {
		/* debug. see if the RX DMA HDP is cleared. */
		if (REG32_R(CPMAC_A_RX_DMAHDP(0), 31, 0) != 0) {
			sys_printf("\nPanic: RX DMA HDP is not cleared still !");
			for (;;);
		}

		/* debug. check for misaligned, which is not supported currently. */
		if (rx_bd->next) {
			sys_printf("\nPanic: Misaligned rx while not supported !");
			for (;;);
		}

		/* Initialize the RX BDs, malloc buffers, start rx and finally, 
		 * set cpmac_st->rx_next to the head.
		 * Pass the head of the BDs to init routine.
		 */
		if (SBL_SUCCESS != cpmac_rx_bd_init(cpmac_st->rx)) {
			return SBL_EFAILURE;
		}
		cpmac_st->rx_next = &cpmac_st->rx[0];
	} else {
		(cpmac_st->rx_next)++;
		/* debug */
		if (cpmac_st->rx_next != (BuffDesc *)KSEG1(rx_bd->next)) {
			sys_printf("\nPanic: rx bd next ptr not updated correctly !");
			for (;;);
		}
	}

	return SBL_SUCCESS;	
}

void bd_dbg(BuffDesc *bd)
{
#if CPMAC_DEBUG
	bd = (BuffDesc *)KSEG1(bd); /* stay explicit for erroneous conditions. */

	sys_printf("\nnext:0x%x", (u4)bd->next);
	sys_printf(" buff:0x%08x", (u4)bd->buff);
	sys_printf(" Off:%d (BD_OFFSET:%d)", 
			   (bd->buff_params & MASK(31, 16)) >> 16, BD_OFFSET);
	sys_printf(" BLen:%d", bd->buff_params & MASK(15, 0));
	sys_printf(" PLen:%d", bd->ctrl_n_len & MASK(15, 0));
	sys_printf(" Ctrl:0x%04x\n", (bd->ctrl_n_len & MASK(31, 16)) >> 16);
#endif
}

BOOL lk_st(u4 itf)
{
	/* debug. */
	if (itf != 0) {
		sys_printf("Panic: itf requested is not 0 !");
		for (;;);
	}

	return TRUE;
}

void cpmac_stats(void)
{

	sys_printf("\nRxGoodFrames: %d", REG32_R(CPMAC_A_ST_RX_GOODFRAMES, 31, 0));
	sys_printf("\t\tRxBroadcast : %d", REG32_R(CPMAC_A_ST_RX_BROADCAST, 31, 0));
	sys_printf("\nRxMulticast : %d", REG32_R(CPMAC_A_ST_RX_MULTICAST, 31, 0));
	sys_printf("\t\tRxPause     : %d", REG32_R(CPMAC_A_ST_RX_PAUSE, 31, 0));
	sys_printf("\nRxCRC       : %d", REG32_R(CPMAC_A_ST_RX_ERR_CRC, 31, 0));
	sys_printf("\t\tRxAlignCodeE: %d", REG32_R(CPMAC_A_ST_RX_ERR_ALIGNC, 31, 0));
	sys_printf("\nRxOversized : %d", REG32_R(CPMAC_A_ST_RX_OVERSIZED, 31, 0));
	sys_printf("\t\tRxJabber    : %d", REG32_R(CPMAC_A_ST_RX_JABBER, 31, 0));
	sys_printf("\nRxUndersized: %d", REG32_R(CPMAC_A_ST_RX_UNDERSIZED, 31, 0));
	sys_printf("\t\tRxFragments : %d", REG32_R(CPMAC_A_ST_RX_FRAGMENTS, 31, 0));
	sys_printf("\nRxFiltered  : %d", REG32_R(CPMAC_A_ST_RX_FILTERED, 31, 0));
	sys_printf("\t\tRxQOSFilter : %d", REG32_R(CPMAC_A_ST_RX_QOSFILTERED, 31, 0));
	sys_printf("\nRxOctets    : %d", REG32_R(CPMAC_A_ST_RX_OCTETS, 31, 0));
	sys_printf("\t\tTxGoodFrames: %d", REG32_R(CPMAC_A_ST_TX_GOODFRAMES, 31, 0));
	sys_printf("\nTxBroadcast : %d", REG32_R(CPMAC_A_ST_TX_BROADCAST, 31, 0));
	sys_printf("\t\tTxMulticast : %d", REG32_R(CPMAC_A_ST_TX_MULTICAST, 31, 0));
	sys_printf("\nTxPause     : %d", REG32_R(CPMAC_A_ST_TX_PAUSE, 31, 0));
	sys_printf("\t\tTxDeffered  : %d", REG32_R(CPMAC_A_ST_TX_DEFFERED, 31, 0));
	sys_printf("\nTxCollision : %d", REG32_R(CPMAC_A_ST_TX_COLLISION, 31, 0));
	sys_printf("\t\tTxSingleColl: %d", REG32_R(CPMAC_A_ST_TX_SINGLECOLL, 31, 0));
	sys_printf("\nTxMultiColl : %d", REG32_R(CPMAC_A_ST_TX_MULTICOLL, 31, 0));
	sys_printf("\t\tTxExcessColl: %d", REG32_R(CPMAC_A_ST_TX_EXCESSCOLL, 31, 0));
	sys_printf("\nTxLateColl  : %d", REG32_R(CPMAC_A_ST_TX_LATECOLL, 31, 0));
	sys_printf("\t\tTxUnderrun  : %d", REG32_R(CPMAC_A_ST_TX_UNDERRUN, 31, 0));
	sys_printf("\nTxCarSenseEr: %d", REG32_R(CPMAC_A_ST_TX_CARRSENSEER, 31, 0));
	sys_printf("\t\tTxOctets    : %d", REG32_R(CPMAC_A_ST_TX_OCTETS, 31, 0));
	sys_printf("\nTxO_64      : %d", REG32_R(CPMAC_A_ST_TX_OC_64, 31, 0));
	sys_printf("\t\tTxO_65_127  : %d", REG32_R(CPMAC_A_ST_TX_OC_65_127, 31, 0));
	sys_printf("\nTxO_128_155 : %d", REG32_R(CPMAC_A_ST_TX_OC_128_255, 31, 0));
	sys_printf("\t\tTxO_256_511 : %d", REG32_R(CPMAC_A_ST_TX_OC_256_511, 31, 0));
	sys_printf("\nTxO_512_1023: %d", REG32_R(CPMAC_A_ST_TX_OC_512_1023, 31, 0));
	sys_printf("\t\tTxO_1024_U  : %d", REG32_R(CPMAC_A_ST_TX_OC_1024_U, 31, 0));
	sys_printf("\nTxNetOctets : %d", REG32_R(CPMAC_A_ST_TX_NETOCTETS, 31, 0));
	sys_printf("\t\tRxSOFovrun  : %d", REG32_R(CPMAC_A_ST_RX_SOF_OVRUN, 31, 0));
	sys_printf("\nRxMOFovrun  : %d", REG32_R(CPMAC_A_ST_TX_MOF_OVRUN, 31, 0));
	sys_printf("\t\tRxDMAovrun  : %d", REG32_R(CPMAC_A_ST_TX_DMA_OVRUN, 31, 0));

}
