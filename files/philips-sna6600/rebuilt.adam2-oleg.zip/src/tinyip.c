/*-----------------------------------------------------------------------------*/
/*                                                                             */
/*   Copyright (C) 2002-2003 by Texas Instruments, Inc.  All rights reserved.  */
/*   Copyright (C) 2002-2003 Telogy Networks, Inc.							   */
/*                                                                             */
/*   NOTE: THIS VERSION OF CODE IS MAINTAINED BY TELOGY NETWORKS AND NOT TI!   */
/*-----------------------------------------------------------------------------*/
/*                                                                             */
/* TINYIP.C - contains basic IP handler for incomming packets.				   */
/* 	NOTE: much of the TCP/UDP/IP layering is done at the data structure		   */
/*		level, not in separate routines or tasks							   */
/*                                                                             */
/*-----------------------------------------------------------------------------*/

#include "support.h"
#include "env.h"
#include "tinyip.h"
#include "hw.h"
#include "shell.h"

extern int my_getenv(char *val, char *envvar, char *prepend);
extern int convert2num(char *str, bit32u *val);
	
int ip_initialized = 0;

int ip_init(void)
{
	bit32u my_ipval;
	char env_setting[18]; /* Generic place holder */
	char *cp, *start_cp, *end_cp;
	int i, ret = 0;
	int zero = 0x30, column = 0x3A;
	char tmpethadr[sizeof(eth_HwAddress)];
	
	rtim = t_get();
	av_cpufreq = (cp = sys_getenv("cpufrequency")) ? atoul(cp) : 125000000;
  	ticdiv = av_cpufreq / 2000;

	sin_lclINAddr = 0;
	net_IpMask = 0;
  	net_Gateway = 0;
	emacbase = EMACA_BASE;
	
	strcpy(env_setting, sys_getenv("maca"));
        if ((env_setting[0]!=zero)||(env_setting[1]!=zero)||(env_setting[2]!=column)) // correct MAC address must starts with "00:"
	{
		sys_printf("Error: \"maca\" invalid, reset to default\n");
		strcpy(env_setting, DEFAULT_MAC); // by Oleg changed from default
		sys_setenv("maca", DEFAULT_MAC);
	}		

	start_cp = env_setting;
	for (i = 0; i < sizeof(eth_HwAddress); i++)
	{
		tmpethadr[i] = (UINT8)(strtol(start_cp, &end_cp, 16));
		start_cp = ++end_cp;
	}
  	Move(tmpethadr, sed_lclEthAddr, sizeof(eth_HwAddress));

	if ((my_getenv(env_setting, "my_ipaddress", "")) && (convert2num(env_setting, &my_ipval)))
	 sin_lclINAddr = my_ipval;
	else
	{
	 sys_printf("Error: \"my_ipaddress\" broken, reset to default\n");
	 sys_setenv("my_ipaddress", DEFAULT_IP);
	 sin_lclINAddr = 3232235777;
	}

/* initialize ethernet interface */
	if (sed_Init(0) == 0) ip_initialized = 1; else ret = 1;
	sar_initTable();
	return (ret);
}

int ip_deinit(void)
{
	if (ip_initialized == 1) sed_shutdown();
	ip_initialized = 0;
	return 1;
}

int ip_Handler(void)
{
	in_Header *ip;
	int protocol;

	if (ip_initialized != 1)
		return 0;

	ip = (in_Header *)sed_IsPacket();

	if (ip == NULL)
		return 0;

	if (sed_CheckPacket(ip, 0x806) == 1) {
		/* do arp */
		sar_CheckPacket((arp_Header *)ip);
	}
	else if (sed_CheckPacket(ip, 0x800) == 1) {
		/* do IP */
		/* 1. Verify checksum
		 * 2. Verify if the packet is meant for us 
		 * 3. Verify if the packet is broadcast 
		 * 4. Verify if the packet is meant to us through DHCP. 
		*/
        if (((ip->destination == lfix(sin_lclINAddr)) || 
			(ip->destination == INADDR_BROADCAST) || (sin_lclINAddr == 0x0)) &&
			(checksum(ip, in_GetHdrlenBytes(ip)) == 0xFFFF)) {				
			
			protocol = in_GetProtocol(ip);
			
			switch(protocol) {
			#if defined(FTP_SERVER_SUPPORT) || defined(FTP_CLIENT_SUPPORT)
				case TCP_PROTO:
					tcp_Handler(ip);
					break;	
			#endif

			#if defined(DHCP_SUPPORT) || defined(FTP_SERVER_SUPPORT) || defined(TFTP_SERVER_SUPPORT)
				case UDP_PROTO:
					udp_Handler(ip);
					break;
			#endif

			#ifdef PING_SUPPORT
				case ICMP_PROTO:
					icmp_Handler(ip);
					break;
			#endif
			}
		}
		else
			return(0);				
	}
	return(1);
}

//#if defined(FTP_SERVER_SUPPORT) //By Charles addition for Support tftp server 08-13-2004
#if defined(FTP_SERVER_SUPPORT) || defined(TFTP_SERVER_SUPPORT) 

#ifdef AR5D01
/* LED DETAILS on AR5D01 
 * *********************
 * LED D610: Power: 		Cannot be controlled by software 
 * LED D101: WAN link: 		Controlled by GPIO0
 * LED D700: LAN link: 		Controlled by EINT1
 * LED D102: LAN activity:	Controlled by GPIO1.
 * Note:
 * GPIO2 is used to control hardware reset.
 * GPIO3 is used to control Raptor reset.
 * */
void leds_init(void)
{
	/* If the GPIO is not reset, then reset it */
	if ((RESET_PRCR & GPIO_RESET)==0) {
		RESET_PRCR &= ~GPIO_RESET;
	}	
	/* Setup the LED pins . */
	GPIO_EN |= GPIO_0 | GPIO_1;	/* Enable GPIO 0, 1 */
	GPIO_DIR &= ~(GPIO_0 | GPIO_1 | EINT_1);	/* Make it an output */

	/* Initialized the LEDs to off */
	toggle_leds(0);
}

void toggle_leds(int bitFlag)
{
	switch (bitFlag)
	{
		case 1 :
			if (crashFlag == CRASH_KERNEL)
			{
				GPIO_OUT |= GPIO_0; /* ON  */
				GPIO_OUT |= EINT_1; /* ON  */
				GPIO_OUT &= ~GPIO_1;/* ON  */
			}
			else if (crashFlag == CRASH_FS)
			{
				GPIO_OUT |= GPIO_0; /* ON  */
				GPIO_OUT &= ~EINT_1;/* OFF */
				GPIO_OUT |= GPIO_1; /* OFF */
			}
			break;
			
		case 2 :
			GPIO_OUT &= ~GPIO_0;/* OFF */
			GPIO_OUT |= EINT_1; /* ON  */ 
			GPIO_OUT |= GPIO_1; /* OFF */
			break;
			
		case 3 :
			GPIO_OUT &= ~GPIO_0;/* OFF */
			GPIO_OUT &= ~EINT_1;/* OFF */
			GPIO_OUT &= ~GPIO_1;/* ON  */
			break;

		case 0 :
		default :
			GPIO_OUT &= ~GPIO_0;/* OFF */
			GPIO_OUT |= GPIO_1; /* OFF */			
			GPIO_OUT &= ~EINT_1;/* OFF */
			break;
	}
}
#else /* AR5D01 */

#ifdef AR5W01
/* LED DETAILS on AR5W01 
 * *********************
 * WAN link: 		Controlled by GPIO0
 * LAN activity: 	Controlled by GPIO1
 * WLAN link:		Controlled by GPIO2.
 * */
void leds_init(void)
{
	/* If the GPIO is not reset, then reset it */
	if ((RESET_PRCR & GPIO_RESET)==0) {
		RESET_PRCR &= ~GPIO_RESET;
	}	
	/* Setup the LED pins . */
	GPIO_EN |= GPIO_0 | GPIO_1 | GPIO_2;	/* Enable GPIO 0, 1, 2 */
	GPIO_DIR &= ~(GPIO_0 | GPIO_1 | GPIO_2);/* Make it an output */

	/* Initialized the LEDs to off */
	toggle_leds(0);
}

void toggle_leds(int bitFlag)
{
	switch (bitFlag)
	{
		case 1 :
			if (crashFlag == CRASH_KERNEL)
			{
				GPIO_OUT |= GPIO_0; /* ON */
				GPIO_OUT |= GPIO_2; /* ON */
				GPIO_OUT &= ~GPIO_1;/* ON */
			}
			else if (crashFlag == CRASH_FS)
			{
				GPIO_OUT |= GPIO_0; /* ON */
				GPIO_OUT &= ~GPIO_2;/* OFF */
				GPIO_OUT |= GPIO_1; /* OFF */
			}
			break;
			
		case 2 :
			GPIO_OUT &= ~GPIO_0;/* OFF */
			GPIO_OUT |= GPIO_2; /* ON  */
			GPIO_OUT |= GPIO_1; /* OFF */
			break;
			
		case 3 :
			GPIO_OUT &= ~GPIO_0;/* OFF */
			GPIO_OUT &= ~GPIO_2;/* OFF */
			GPIO_OUT &= ~GPIO_1;/* ON  */
			break;

		case 0 :
		default :
			GPIO_OUT &= ~GPIO_0;/* OFF */
			GPIO_OUT &= ~GPIO_2;/* OFF */
			GPIO_OUT |= GPIO_1; /* OFF */
			break;
	}
}
#else /* AR5W01 */

#if defined(AR7DB) || defined(AR7RD) || defined(AR7WRD)
#define PPP_GPIO	(1<<13)
#define USB_GPIO	(1<<12)

#define SYS_GPIO_4	(1<<4)
#define SYS_GPIO_5	(1<<5)
#define SYS_GPIO_8	(1<<8)

/* LED DETAILS on AR7RD 
 * *********************
 * USB link: 	Controlled by GPIO 12
 * PPP link: 	Controlled by GPIO 13
 * */
void red_led(void)
{
	GPIO_OUT |=  SYS_GPIO_4;
	GPIO_OUT &= (~(SYS_GPIO_5));
	GPIO_OUT &= (~(SYS_GPIO_8));
}
void green_led(void)
{
	GPIO_OUT &= (~(SYS_GPIO_4));
	GPIO_OUT |=  SYS_GPIO_5;
	GPIO_OUT |=  SYS_GPIO_8;
}
void leds_init(void)
{
	int i;
	/* Setup the LED pins . */
	GPIO_EN |= USB_GPIO;	/* Enable USB GPIO */
	GPIO_EN |= PPP_GPIO;	/* Enable PPP GPIO */
	
	GPIO_EN |= SYS_GPIO_4;
	GPIO_EN |= SYS_GPIO_5;
	GPIO_EN |= SYS_GPIO_8;

	GPIO_DIR &= (~(USB_GPIO)); /* Make it an output */
	GPIO_DIR &= (~(PPP_GPIO)); /* Make it an output */

	GPIO_DIR &= (~(SYS_GPIO_4));
	GPIO_DIR &= (~(SYS_GPIO_5));
	GPIO_DIR &= (~(SYS_GPIO_8));

	/* Initialized the LEDs to off */
	toggle_leds(0);
	red_led();
	for (i = 0; i < 0x1000000; i++);
	green_led();
}

void toggle_leds(int bitFlag)
{
	switch (bitFlag)
	{
		case 1 :
			if (crashFlag == CRASH_KERNEL)
			{
				GPIO_OUT &= (~(USB_GPIO)); /* ON */
				GPIO_OUT &= (~(PPP_GPIO)); /* ON */
			}
			else if (crashFlag == CRASH_FS)
			{
				GPIO_OUT &= (~(USB_GPIO)); /* ON */
				GPIO_OUT |= PPP_GPIO; /* OFF */
			}
			break;
			
		case 2 :
			GPIO_OUT |= USB_GPIO; /* OFF */
			GPIO_OUT &= (~(PPP_GPIO)); /* ON */			
			break;
			
		case 3 :
			GPIO_OUT |= PPP_GPIO; /* OFF */
			GPIO_OUT &= (~(USB_GPIO)); /* ON */
			break;

		case 0 :
		default :
			GPIO_OUT |= USB_GPIO; /* OFF */
			GPIO_OUT |= PPP_GPIO; /* ON */			
			break;
	}
}
#else /* defined(AR7DB) || defined(AR7RD) || defined(AR7WRD) */

/* Dummy functions for other boards. */
void leds_init(void)
{
}

void toggle_leds(int bitFlag)
{
}
#endif /* defined(AR7DB) || defined(AR7RD) || defined(AR7WRD) */
#endif /* AR5W01 */
#endif /* AR5D01 */

#endif /* defined(FTP_SERVER_SUPPORT) || defined(TFTP_SERVER_SUPPORT)  */

