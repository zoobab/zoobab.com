#include "hw.h"

#define RESERVE_MAC     8
#define PER_MAC_LEN     18      // contain '\0'

#define PMON_MAC_START_ADDRESS  0x2000
#define PMON_VER_START_ADDRESS  0x2100

#define CFE_MAC_START_ADDRESS  0x1E00
#define CFE_VER_START_ADDRESS  0x1F00

#define FLASH_BASE	0xBFC00000

#define NOT_NULL(var,m,c) ( \
        var[m] != c && var[m+1] != c && var[m+2] != c && var[m+3] != c && var[m+4] != c && var[m+5] != c \
)

#define IS_NULL(var,m,c) ( \
        var[m] == c && var[m+1] == c && var[m+2] == c && var[m+3] == c && var[m+4] == c && var[m+5] == c \
)

#define MAC_ADD(mac) ({\
                int i,j; \
                unsigned char m[6]; \
                /* sscanf(mac,"%x:%x:%x:%x:%x:%x",&m[0],&m[1],&m[2],&m[3],&m[4],&m[5]);   will error */ \
                for(j=0,i=0 ; i<PER_MAC_LEN ; i+=3,j++) { \
                        if(mac[i] >= 'A' && mac[i] <= 'F')              mac[i] = mac[i] - 55;\
                        if(mac[i+1] >= 'A' && mac[i+1] <= 'F')  mac[i+1] = mac[i+1] - 55;\
                        if(mac[i] >= 'a' && mac[i] <= 'f')              mac[i] = mac[i] - 87;\
                        if(mac[i+1] >= 'a' && mac[i+1] <= 'f')  mac[i+1] = mac[i+1] - 87;\
                        if(mac[i] >= '0' && mac[i] <= '9')              mac[i] = mac[i] - 48;\
                        if(mac[i+1] >= '0' && mac[i+1] <= '9')  mac[i+1] = mac[i+1] - 48;\
                        m[j] = mac[i]*16 + mac[i+1]; \
                } \
                for(i=5 ; i>=3 ; i--){ \
                        if( m[i] == 0xFF)       { m[i] = 0x0; continue; } \
                        else                    { m[i] = m[i] + 1; break; } \
                } \
                sprintf(mac,"%02X:%02X:%02X:%02X:%02X:%02X",m[0],m[1],m[2],m[3],m[4],m[5]); \
})

static int MAC_START_ADDRESS;
extern int mac_get(char *);

static int location;
static char get_mac[PER_MAC_LEN];

static int
mac_init(void){
	unsigned char vars[RESERVE_MAC*PER_MAC_LEN];
	unsigned long *src2 = (unsigned long *) (MAC_START_ADDRESS);	// 0xBFC02000
	unsigned long *dst2 = (unsigned long *) vars;
	int i,j, k;
	char *var;

	sys_printf("\n");
	
//	for(k=0; k<18; k++)
//		sys_printf("%02x ", src2[k]);
	
	location = -1;
	strcpy(get_mac,"");

	for (i = 0; i < sizeof(vars); i += 4)
		*dst2++ = *src2++;

	for (i=0,j=0; i<sizeof(vars); i += PER_MAC_LEN) {
		if((j == RESERVE_MAC-1 && NOT_NULL(vars,i,0xff) && NOT_NULL(vars,i,0x0)) 			// the last
		|| (j < RESERVE_MAC -1 && NOT_NULL(vars,i,0xff) && IS_NULL(vars,i+PER_MAC_LEN,0xff))){
			var = &vars[i];
			sys_printf("mac_init(): Find mac [%s] in location %d\n", var, j);
			if(strlen(var) != 17){
				sys_printf("\tIllegal mac [%s], skip\n", var);
				return 0;
			}
			strncpy(get_mac, var, PER_MAC_LEN-1);
			get_mac[PER_MAC_LEN] = '\0';
			location = j;

		//	for(k=0; k<18; k++)
		//		sys_printf("%02x ", get_mac[k]);

			return 1;
		}
		j++;
	}

	sys_printf("No mac find, use default mac\n");

	return 0;
}

int
mac_get(char *mac_addr){
//	char wan_mac[PER_MAC_LEN];
	
//	MAC_START_ADDRESS = CS0_BASE + 0xFF00;
	MAC_START_ADDRESS = CS0_BASE + 0x1FF00;

	if(mac_init()){
		sys_printf("Find mac [%s] in location %d\n", get_mac, location);
#if 0	
		if(strcmp(nvram_safe_get("et0macaddr"),get_mac)){
			strcpy(wan_mac,get_mac);
			printf("Update lan mac from [%s] to [%s]\n", nvram_safe_get("et0macaddr"),get_mac);
			nvram_set("et0macaddr",get_mac);
			return 1;
		}
		else{
			printf("Nothing...\n");		
		}
		
#else
		if(strcmp(mac_addr, get_mac))
		{
			sys_printf("Update lan mac from [%s] to [%s]\n",
				mac_addr, get_mac);
			strcpy(mac_addr, get_mac);
		}
	}
#endif
	return 0;
}

