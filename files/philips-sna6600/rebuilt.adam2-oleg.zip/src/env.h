/*-----------------------------------------------------------------------------*/
/*                                                                             */
/*   Copyright (C) 1996-2003 by Texas Instruments, Inc.  All rights reserved.  */
/*   Copyright (C) 2001-2003 Telogy Networks.	    						   */
/*                                                                             */
/*-----------------------------------------------------------------------------*/

#ifndef ___ENV_H_ADAM2___
#define	___ENV_H_ADAM2___

#define DEFAULT_MAC "00:e0:a0:a6:70:80"
#define DEFAULT_IP "192.168.1.1"
/* The env space is just 10K, thus allowing 80 variables of 128 bytes each */
#define FLASH_ENV_ENTRY_SIZE	128
#define MAX_ENV_ENTRY			80

/* These definitions MUST match the ones found in the Linux kernel. And
 * they must be consistent with the size and num of env var enties. */
#define ENV_VAR_MTD          (3)
#define ENV_VAR_MTD_OFFSET   (0)
#define ENV_VAR_MTD_SIZE     (FLASH_ENV_ENTRY_SIZE * MAX_ENV_ENTRY)

#define CFGMAN_MTD           (3)
#define CFGMAN_MTD_OFFSET    (ENV_VAR_MTD_SIZE)
#define CFGMAN_MTD_SIZE      (MIN_BOOT_BLOCK_SIZE - ENV_VAR_MTD_SIZE)

int EnvInit(void);
int sys_unsetenv(char *var);
int sys_setenv(char *var,char *val);
char *sys_getenv(char *var);
char *sys_getienv(int sindex);
int sys_initenv(void);
void init_env(void);

typedef struct
  {
  char *name;
  char *val;
  }t_env_var;

#define SYS_USER_ENVIRONMENT_MAX_INDEX	256	

extern t_env_var env_vars[];

#if 0
#define SYS_ENV_BOOT_LEVEL    "bootlevel"
#define SYS_BOOT_OFF_STR	"off"
#define SYS_BOOT_MXP_STR	"mxp"
#define SYS_BOOT_APPL_STR	"appl"

#define   SYS_ENV_EMACA_IP_ADDR    "EMACA_IPADDR"
#define   SYS_ENV_EMACB_IP_ADDR    "EMACB_IPADDR"

#define   SYS_ENV_EMACA_GW    "EMACA_GW"
#define   SYS_ENV_EMACB_GW    "EMACB_GW"

#define   SYS_ENV_EMACA_NETMASK    "EMACA_NETMASK"
#define   SYS_ENV_EMACB_NETMASK    "EMACB_NETMASK"

#define   SYS_ENV_FTP_SERVER_DIR   "FTP_SERVER_DIR"
#define   SYS_ENV_FTP_SERVER_USER  "FTP_SERVER_USER"
#define   SYS_ENV_FTP_SERVER_PASS  "FTP_SERVER_PASS"
#define   SYS_ENV_FTP_SERVER_IP    "FTP_SERVER_IP"
#define   SYS_ENV_FTP_DEVICE       "FTP_USE_DEV"

#define	SYS_ENV_CPU_FREQUENCY	    "cpufrequency"

#define SYS_NMM_CONFIG    "genconfig"
#define SYS_ATPM_CONFIG	  "atpmconfig"
#define SYS_BOOT_CONFIG   "bootconfig"
#define	SYS_ENV_MAC_ADDRESS_A		"EMACA_MAC"
#define	SYS_ENV_MAC_ADDRESS_B		"EMACB_MAC"
#define	SYS_ENV_MAC_ADDRESS_C		"EMACC_MAC"
#define	SYS_ENV_MAC_ADDRESS_D		"EMACD_MAC"


#define	SYS_ENV_BOOT_LINE1		"bootline1"
#define	SYS_ENV_BOOT_LINE2		"bootline2"
#define	SYS_ENV_ATM_BOOT_LINE	"atmbootline"
#define	SYS_ENV_RNDIS_BOOT_LINE	"rndisbootline"


#define	SYS_ENV_CPU_FREQUENCY		"cpufrequency"

#define	SYS_ENV_CLK_FREQUENCY		"clkfrequency"
#define	SYS_ENV_PLL_MULTIPLIER		"pllmultiplier"

#define SYS_ENV_USB_ENDPOINT_POLLING_INTERVAL	"usb_ep_poll"
#define SYS_ENV_USB_PRODUCT_ID					"usb_prod_id"
#define SYS_ENV_USB_VENDOR_ID					"usb_vend_id"

#define SYS_ENV_TNETD53XX_BASE_FREQUENCY		"base_freq"
#endif

#endif /* ___ENV_H_ADAM2___ */

