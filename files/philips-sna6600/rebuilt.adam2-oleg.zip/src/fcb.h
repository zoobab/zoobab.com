/*-----------------------------------------------------------------------------*/
/*                                                                             */
/*   Copyright (C) 1999-2003 by Texas Instruments, Inc.  All rights reserved.  */
/*   Copyright (C) 2001-2003 Telogy Networks.	    						   */
/*                                                                             */
/*-----------------------------------------------------------------------------*/

#ifndef _FCB
#define _FCB

#include "_stdio.h"

#define MAX_OPEN_FILES 5

/* FileSTate */

#define FILE_FREE  0x00
#define FILE_OPEN  0x01
#define FILE_RO    0x02
#define FILE_BIN   0x04
#define FILE_EOF   0x08
#define FILE_WRITE 0x10

/* subsystem type */

#define FILE_FLASH 0
#define FILE_SIO   1
 
extern FFS_FILE _FileArray[MAX_OPEN_FILES];

void fcb_InitFCB(void);
FFS_FILE *fcb_FileGetFCB(void);

#endif
