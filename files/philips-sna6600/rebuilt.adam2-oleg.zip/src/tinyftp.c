/*-----------------------------------------------------------------------------*/
/*																			   */	
/* tinyftp.c - user ftp built on tinytcp.c									   */	
/*																			   */
/* Written March 31, 1986 by Geoffrey Cooper								   */
/*																			   */
/* Copyright (C) 1986, IMAGEN Corporation									   */
/*  "This code may be duplicated in whole or in part provided that [1] there   */
/*   is no commercial gain involved in the duplication, and [2] that this      */
/*   copyright notice is preserved on all copies.  Any other duplication       */
/*   requires written notice of the author."								   */
/*-----------------------------------------------------------------------------*/

#include "_stdio.h"
#include "env.h"
#include "tinyip.h"
#include "support.h"
#include "flashop.h"
#include "srloader.h"
#include "shell.h"
#include "revision.h"

tcp_Socket ftp_ctl, ftp_data;

static byte ftp_cmdbuf[128];
static int ftp_cmdbufi;

static byte ftp_outbuf[ftp_MaxData];
static int ftp_outbufix, ftp_outbuflen;

#ifdef FTP_SERVER_SUPPORT

#define USERNAME_LEN		16

#define REC_GET_TAG		0
#define REC_GET_LEN		1
#define REC_GET_ADDR		2
#define REC_GET_DATA		3
#define REC_GET_CHECKSUM	4
#define REC_GET_ABORT		5
#define REC_GET_DONE		6

#define CFG_MAGIC_NUMBER	0x434D4D4C /* CMML */
// by Oleg can be 0x0300 #define CFG_VERSION_NUMBER	0x0200

int ftpServerStatus = STATUS_NONE;
int rebootFlag = FALSE;

static char buffer[ftp_MaxData];
static longword ftpRemoteHost;
static longword ftpRemotePort;
static int dlen;
static bit32 flashAddress;
static bit32u flashOffset;
static bit32 endAddress;
static bit32u ramAddress;
static bit32u recState, recLen, recAddr, recChecksum;
static short ftpMedia;
static short ftpType;

static FTPCommand commandList[] = {
	{TOK_ABOR, 	"ABOR",  FALSE},/*Abort transfer: ABOR.*/
/*	{TOK_BYE,  	"BYE",   FALSE}, Logout or break connection: BYE.*/
	{TOK_QUIT, 	"QUIT",  FALSE},/*Logout or break connection: QUIT.*/ 
	{TOK_PORT, 	"PORT",  TRUE}, /*Specify the client port number: PORT a0,a1,a2,a3,a4,a5.*/
	{TOK_USER,	"USER",  TRUE},	/*Supply a username: USER username.*/ 
	{TOK_PASS, 	"PASS",  TRUE},	/*Supply a user password: PASS password.*/
/* #if 0 */
	{TOK_HELP, 	"HELP",  FALSE},/*Show help: HELP*/
/* #endif */
/*	{TOK_SYST, 	"SYST",  FALSE}, Get operating system type: SYST.*/
	{TOK_PASV, 	"PASV",  FALSE},/*Set server in passive mode: PASV.*/
/*	{TOK_PASW, 	"P@SW",  FALSE}, Set server in passive mode: P@SV.*/
#if 0	
	{TOK_NLST, 	"NLST",  FALSE},/*List filenames only: NLST.*/ 
	{TOK_LIST, 	"LIST",  FALSE},/*Get directory listing: LIST.*/
#endif
	{TOK_STOR, 	"STOR",  TRUE},	/*Store file: STOR file-name.*/ 
	{TOK_TYPE, 	"TYPE",  TRUE},	/*Set filetype: TYPE [A | I].*/
	{TOK_RETR,	"RETR",	 TRUE},	/*Get file: RETR file-name.*/
	{TOK_MEDIA,	"MEDIA", TRUE},	/*Set storage media - Flash/SDRAM: MEDIA [FLSH | SDRM].*/
	{TOK_GETENV,	"GETENV",TRUE},	/*Retreive the value for an env variable: GET env-name.*/
	{TOK_SETENV,	"SETENV",TRUE},	/*Set an env value-variable pair: SET env-name,value.*/
	{TOK_UNSETENV,"UNSETENV",TRUE},	/*Unset an env value-variable pair: UNSET env-name.*/
	{TOK_FIXENV,	"FIXENV",FALSE},/*rebuild env: FIXENV.*/
	{TOK_PRINTENV,"PRINTENV",FALSE},/*print env variables: PRINTENV.*/
	{TOK_REBOOT,	"REBOOT",FALSE},/*Reboot the server: REBOOT.*/
	{TOK_ERROR,	"", 	 FALSE},
};

void FlushICache(void);
int RetrConfigSpace(tcp_Socket *s);
int RetrMtdSpace(tcp_Socket *s);

void FTPSend (tcp_Socket *s, char *data, int len)
{
	char *sr;
	char *dp;
			
	sr = data;
   	dp = (char *)ftp_outbuf;

	if (len == 0) len = strlen(data);
	if (len > ftp_MaxData) len = ftp_MaxData;
	
	sys_memcpy(dp, data, len);
	ftp_outbuflen = len;
   	ftp_outbufix = 0;
	if ( len > 0 ) 
	{
		len = tcp_Write(s, &ftp_outbuf[ftp_outbufix], len);
		ftp_outbufix += len;
		tcp_Flush(s);
	}
}

int flashStore (byte *dp, int len)
{
	if ((dlen == 0) && (dp))
	{
		if (FWBValid((bit32u)flashAddress) == 0) {
			return FALSE;
		}

		if (FWBOpen((bit32u)flashAddress) == 0) {
			return FALSE;
		}
		
		/* The code assumes that every time you want to start writing to the flash you want
		 * to start at the beginning of the block.  Since the env var and cfgman data are 
		 * sharing the same block, this is no longer true.  Therefore, we include this
		 * hack here to adjust the offset on the first write */
		flashAddress+=flashOffset;
		sys_printf("WriteToFlash\n");
	}
	if ((flashAddress + len) > endAddress) return FALSE;

	if ((dp) && (len))
	{
		WriteToFlash((UINT8 *)flashAddress, (UINT8 *)dp, len);
		dlen += len;
		flashAddress += len;
	}	
	return TRUE;
}

int ramStore (byte *dp, int len)
{
 bit32u recTag, newChecksum;
 static UINT32 TotalBytes = 0;

 while (len)
 {
  switch (recState)
  {
   case REC_GET_TAG:
	if (getf32((bit32u)dp, &recTag, FALSE) == 4) {
		if (recTag != TAG_WANTED) {
			recState = REC_GET_ABORT;
			sys_printf("Error: File for wrong endian.\n");
		}
		else	recState = REC_GET_LEN;
	}
	ramAddress = 0;
	len -= 4;
	dp += 4;
	sys_printf("\n");
	break;

   case REC_GET_LEN:
	if (getf32((bit32u)dp, &recLen, FALSE) == 4) {
		recChecksum = recLen;
		recState = REC_GET_ADDR;
	}
	len -= 4;
	dp += 4;
	break;

   case REC_GET_ADDR:
	if (getf32((bit32u)dp, &recAddr, FALSE) == 4) {
		if (recLen == 0) {
			ramAddress = recAddr;
			recState = REC_GET_DONE;
		}
		else {
			recChecksum += recAddr;
				recState = REC_GET_DATA;
		}
	}
	len -= 4;
	dp += 4;
	break;

   case REC_GET_DATA:
	while ((recLen != 0) && (len != 0))	{
		recChecksum += ((bit32u)*dp)&0x0ff;
	   	*(char *)recAddr++ = *dp++;
		recLen--;
		len--;
		if ((TotalBytes++ % INDICATE_WRITE) == 0) sys_printf(".");
	}
	if (recLen == 0) recState = REC_GET_CHECKSUM;
	break;

   case REC_GET_CHECKSUM:
	if (getf32((bit32u)dp, &newChecksum, FALSE) == 4) {
		recChecksum += newChecksum;
		if (recChecksum != 0) {
			sys_printf("Error: Bad Checksum.\n");
			recState = REC_GET_ABORT;
		}
		else recState = REC_GET_LEN;
	}
	dp += 4;
	len -= 4;
	break;

   case REC_GET_ABORT:				
   case REC_GET_DONE:
	len = 0;
	break;				
  }
 }
 if (recState == REC_GET_ABORT) return FALSE;
 return TRUE;
}

void FTPDataHandler (tcp_Socket *s, byte *dp, int len, int state)
{
 int ret = FALSE;

 switch (state)
 {
  case SOPEN:
	dlen = 0;
	flashOffset=0;
	recState = REC_GET_TAG;
	recChecksum = 0;			
	recLen = recAddr = 0;
	break;
	
  case SDATA:
	if (ftpServerStatus == STATUS_DOWNLOAD)
	{
		if (s->dataSize == 0)
	   	{
// by Oleg
			if ((RetrConfigSpace(&ftp_data) == FALSE)&&(RetrMtdSpace(&ftp_data) == FALSE))
			{
				dlen = 0;
				flashOffset=0;
				tcp_Close(&ftp_data);
				FTPSend(&ftp_ctl, "226 complete.\r\n", 0);
				ftpServerStatus = STATUS_IDLE;
			}
		}
		break;
	}
	else if (ftpServerStatus != STATUS_UPLOAD) break;
	
	if (ftpMedia == MEDIA_FLASH) {

//		sys_printf("\nflashStore 0x%x to 0x%x offset 0x%x length %d\n", flashAddress, endAddress, flashOffset, len); // by Oleg for debug
		ret = flashStore(dp, len);
	}
	else if (ftpMedia == MEDIA_SDRAM) {				
		ret = ramStore(dp, len);
	}
		if (ret == FALSE)
	{
		sys_printf("ERROR: Store to media failed\n");
		tcp_Close(&ftp_data);
		FTPSend(&ftp_ctl, "426 Connection close; transfer aborted.\r\n", 0);
		ftpServerStatus = STATUS_IDLE;				
	}
	break;
	
  case SCLOSE:
  case SABORT:
	if (ftpServerStatus != STATUS_UPLOAD) break;
	if (dlen && (ftpMedia == MEDIA_FLASH))
	{
		if (!FWBClose())
      			sys_printf("ERROR: Could not close flash block, dlen = %d\n", dlen);
	}			
	dlen = 0;
	flashOffset=0;
	tcp_Close(&ftp_data);
	FTPSend(&ftp_ctl, "226 Transfer complete.\r\n", 0);
	ftpServerStatus = STATUS_IDLE;
	sys_printf("\n");
	if ((ftpMedia == MEDIA_SDRAM) && (ramAddress != 0)) {
		FlushICache();
		sys_printf("\nExecuting the RAM image at 0x%x.\n", ramAddress);
		if (executeProgram(0, ramAddress, 0, NULL) == 0)
			FTPSend(&ftp_ctl, "200 Execution successful.\r\n", 0);
		else
			FTPSend(&ftp_ctl, "214 Execution failed.\r\n", 0);
		ramAddress = 0;
	}
	break;			
 }
}

int ftpCheckState (void)
{
 if (ftp_data.state != tcp_StateESTAB) return 0;
 if ((ftpServerStatus != STATUS_PASSIVE) && (ftpServerStatus != STATUS_ACTIVE))
  return 0;
 return 1;
}

int RetrEnvSpace(tcp_Socket *s)
{
	int i;
	char *cp,*cp2;

	for(i=0;i<256;i++)
	{
		cp=sys_getienv(i);
		if (cp)
		{
			cp2=sys_getenv(cp);
			if (!cp2) cp2 = "";
			sys_sprintf(buffer, "%-20s  %s\r\n", cp, cp2);
			FTPSend(s, buffer, 0);
		}
	}
	return TRUE;
}

int RetrMtdSpace(tcp_Socket *s)
{
	int len = (ftp_MaxData - 1);
	static bit32u size = 0x0;
	static bit32 configAddress = 0x0;
	if (dlen == 0)
	{		
	 sys_printf("RetrMtdSpace: 0x%x; 0x%x\r\n", flashAddress, endAddress);
	 configAddress = flashAddress;
	 configAddress &= 0x1fffffff;
	 configAddress |= 0xa0000000; // by Oleg 0xB-------
	 size = endAddress-flashAddress;
	}
	if ((configAddress == 0x0) || (size == 0x0)) return FALSE;
	if (size < len) len = size;
	sys_memset(buffer, 0, ftp_MaxData);
	sys_memcpy(buffer, (void *) configAddress, len);
	FTPSend(s, buffer, len);
	configAddress += len; // by Oleg : this is static variable=> preserve state
	dlen += len;
	size -= len; // by Oleg : this is static variable=> preserve state
	return TRUE;
}

int RetrConfigSpace(tcp_Socket *s)
{
	char *cp;
	bit32u magicNumber, versionNumber;
	char cfgman_mtd_name[FLASH_ENV_ENTRY_SIZE];

	int len = (ftp_MaxData - 1);
	static bit32u size = 0x0;
	static bit32 configAddress = 0x0;
	
	if (dlen == 0)
	{		
		/* calculate the address for the config block */
		sys_sprintf(cfgman_mtd_name,"mtd%d", CFGMAN_MTD);
		cp = sys_getenv(cfgman_mtd_name);
		if ((cp == NULL) || (myatox(cp,&configAddress) == 0))
			return FALSE;
		configAddress &= 0x1fffffff;
		configAddress |= 0xa0000000;

		/* adjust for the offset */
		configAddress += CFGMAN_MTD_OFFSET;

		/* Get magic number, version and size, but leave configAddress as it is. */
		if ((getf32((bit32u)configAddress, &magicNumber, FALSE) != 4) || 
				(magicNumber != CFG_MAGIC_NUMBER))
			return FALSE;
		configAddress += 4;
		
		
// by Oleg remove if ((getf32((bit32u)configAddress, &versionNumber, FALSE) != 4) || (versionNumber != CFG_VERSION_NUMBER)) return FALSE;
		configAddress += 4;
	
		if ((getf32((bit32u)configAddress, &size, FALSE) != 4) || (size >= 0xFFFF))
			return FALSE;
/* by Oleg		configAddress += 8; Leaving size and crc; No need to read the crc */
		configAddress -= 8; // by Oleg to read config with headrer, to be able "put config.xml"
		size +=8;
	}

	if ((configAddress == 0x0) || (size == 0x0)) return FALSE;

	if (size < len) len = size;
	sys_memset(buffer, 0, ftp_MaxData);
	sys_memcpy(buffer, (void *)configAddress, len);
	FTPSend(s, buffer, len);
	configAddress += len; // by Oleg : this is static variable=> preserve state
	dlen += len;
	size -= len; // by Oleg : this is static variable=> preserve state
	return TRUE;
}

void FTPCommandLine(tcp_Socket *s)
{
	char *cmdstr, *argstr;
	int ncmd, i, port;
	char *cp, *start, *end;
	char *strArr[10];
	static char username[USERNAME_LEN];	
	char ipaddr[USERNAME_LEN];
	
	cmdstr = (char *)ftp_cmdbuf;
	argstr = strtok(cmdstr, ' ');

	for (ncmd = TOK_ABOR; ncmd < TOK_ERROR; ncmd++) {
		if (strcmp(cmdstr, commandList[ncmd].commandName) == 0) {
			if ((commandList[ncmd].argFlag == TRUE) && (argstr == NULL)) {
				FTPSend(s, "501 Invalid number of parameters.\r\n", 0);
				return;
			}
			break;
		}
	}
	
	if ((ncmd != TOK_USER && ncmd != TOK_PASS) && (ftpServerStatus == STATUS_LOGIN))
	{
		FTPSend(s, "530 Please login with USER and PASS.\r\n", 0);
		sys_memset(username, 0, USERNAME_LEN);
		return;
	}

	switch(ncmd) {
		case TOK_ABOR:
			if (ftpServerStatus != STATUS_IDLE)
				FTPSend(s, "426 Data connection closed.\r\n", 0);
			FTPSend(s, "226 ABOR command successful.\r\n", 0);
			if (ftp_data.state != tcp_StateCLOSED)
    			tcp_Abort(&ftp_data);
			break;
			
//		case TOK_BYE:
		case TOK_QUIT:
			sys_sprintf(buffer, "221 Goodbye.\r\n");
			FTPSend(s, buffer, 0);
			tcp_Close(s); // by Oleg to exit from telnet client
			tcp_Abort(s);
			ftpServerStatus = STATUS_NONE;
			break;
		
		case TOK_PORT:
			i = 0;
			cp = argstr;
			argstr = strtok(cp, ',');
			while (argstr != NULL && i < 10) {
				strArr[i] = cp;
				cp = argstr;
				argstr = strtok(cp, ',');
				i++;
			}
			if (i != 10) {
				strArr[i] = cp;
			}

			sys_sprintf(ipaddr, "%s.%s.%s.%s", strArr[0], strArr[1], strArr[2], strArr[3]);
			convert2num(ipaddr, &ftpRemoteHost);
			ftpRemotePort = (256 * atoui(strArr[4])) + atoui(strArr[5]);
			tcp_Open(&ftp_data, 20, ftpRemoteHost, ftpRemotePort, FTPDataHandler);
			FTPSend(s, "200 Port command successful.\r\n", 0);
			ftpServerStatus = STATUS_ACTIVE;
			break;
			
		case TOK_USER:
			ftpServerStatus = STATUS_LOGIN;
			if (argstr != NULL) {
				strncpy(username, argstr, (USERNAME_LEN-1));
				sys_sprintf(buffer, "331 Password required for %s.\r\n", username);
			}
			else
				sys_sprintf(buffer, "530 Please login with USER and PASS.\r\n");
			FTPSend(s, buffer, 0);
			break;
			
		case TOK_PASS:
			if (username[0] == 0)
				FTPSend(s, "503 Login with USER first.\r\n", 0);
			else {
				if (strcmp(username, "adam2") == 0) // by Oleg not needed && (strcmp(argstr, "adam2") == 0))
				{
					ftpServerStatus = STATUS_IDLE;
					sys_sprintf(buffer, "230 %s logged in.\r\n", username);
					FTPSend(s, buffer, 0);
				}
				else
					FTPSend(s, "530 Login incorrect.\r\n", 0);
			}
			break;			
			

		case TOK_HELP:
			sys_sprintf(buffer, "214-commands:\r\n");
			for (i = TOK_ABOR; i < TOK_ERROR; i++) {
				strcat(buffer, commandList[i].commandName);
				strcat(buffer, "\r\n");
			}	
			FTPSend(s, buffer, 0);
			sys_sprintf(buffer, "214 HELP Command successful\r\n");
			FTPSend(s, buffer, 0);
			break;		
	#if 0	
		case TOK_SYST:
			FTPSend(s, "215 UNIX emulated bye ADAM2's FTP Server.\r\n", 0);
			break;
		case TOK_PASW:
	#endif
		case TOK_PASV:
    		port = (sed_lclEthAddr[2] + rtim) & 0xFFFF;
			sys_sprintf(buffer, "227 Entering Passive Mode (%d,%d,%d,%d,%d,%d).\r\n", 
				((sin_lclINAddr>>24) & 0xff), ((sin_lclINAddr>>16) & 0xff), 
				((sin_lclINAddr>>8) & 0xff), (sin_lclINAddr & 0xff), port/256, port%256);
			tcp_Listen(&ftp_data, port, FTPDataHandler, 0);
			FTPSend(s, buffer, 0);
			ftpServerStatus = STATUS_PASSIVE;
			break;
	
	#if 0	
		case TOK_NLST:
		case TOK_LIST:				
			if (ftpCheckState() == 0) {
				FTPSend(s, "550 Data Socket is not ready.\r\n", 0);
				break;
			}
			
			ftpServerStatus = STATUS_LIST;
			FTPSend(s, "150 Opening ASCII mode.\r\n", 0);
			strcpy(buffer, "FLASH-Adam2\r\nFLASH-Linux Kernel\r\nFLASH-Linux FileSystem\r\nFLASH-Linux Configuration\r\nFLASH-Env Space\r\nSDRAM-POST\r\n");
			FTPSend(&ftp_data, buffer, 0);
			tcp_Close(&ftp_data);
			FTPSend(s, "226 Transfer complete.\r\n", 0);
			ftpServerStatus = STATUS_IDLE;
			break;		
	#endif
		
		case TOK_STOR:
			if (ftpCheckState() == 0) {
				FTPSend(s, "550 Data Socket not ready.\r\n", 0);
				break;
			}
			if (ftpType != TYPE_BINARY) {
				FTPSend(s, "550 Data connection mode not set to BINARY.\r\n", 0);
				tcp_Close(&ftp_data);
				break;
			}
/*			
			if (ftpMedia == MEDIA_NONE)
				ftpMedia = MEDIA_SDRAM;
*/		
			if (ftpMedia == MEDIA_FLASH) {

				char cfgman_mtd_name[FLASH_ENV_ENTRY_SIZE];
				bit8u *pdata;
				bit8u *pdst;
				
				sys_sprintf(cfgman_mtd_name,"mtd%d", CFGMAN_MTD);
			
				cp = strtok(argstr, ' ');
				if (cp == NULL)	{
					FTPSend(s, "550 No <blockname> specified.\r\n", 0);
					tcp_Close(&ftp_data);
					break;
				}
				start = sys_getenv(cp);
				if (start == NULL) {
					FTPSend(s, "550 <blockname> environment variable not set.\r\n", 0);
					tcp_Close(&ftp_data);
					break;
				}
				end = strtok(start, ',');
				if ((start == NULL) || (end == NULL) || 
					(myatox(start,&flashAddress) == 0) || (myatox(end,&endAddress) == 0)) {
					FTPSend(s, "550 invalid <blockname>.\r\n", 0);
					tcp_Close(&ftp_data);
					break;
				}		
				flashAddress &= 0x1fffffff;
				flashAddress |= 0xa0000000;
				endAddress &= 0x1fffffff;
				endAddress |= 0xa0000000;

				/* when updating the config.xml, we need to save the env vars data since
				 * we are sharing the same block */
				if(strcmp(cp,cfgman_mtd_name)==0)
				{
					/* create a buffer to hold the data */
					pdata=sys_malloc(ENV_VAR_MTD_SIZE);
					if(!pdata) {
						FTPSend(s, "550 malloc failed.\r\n", 0);
						tcp_Close(&ftp_data);
						break;
					}

					/* save the env vars */
					sys_memcpy(pdata,(void *)(flashAddress+ENV_VAR_MTD_OFFSET), ENV_VAR_MTD_SIZE);
				}
// by Oleg add check to protect Adam, it can not be erased
				if ((FWBValid((bit32u)flashAddress) == 0)||(erase(flashAddress, endAddress) != 0))
				{
					FTPSend(s, "550 can not erase\r\n", 0);
					tcp_Close(&ftp_data);
					if(pdata) sys_free(pdata);
					break;
				}
				/* when updating the config.xml, we need to restore the env vars data */
				if(strcmp(cp,cfgman_mtd_name)==0)
				{
					pdst=(bit8u *)(flashAddress+ENV_VAR_MTD_OFFSET);

					if( !FWBOpen((bit32u)flashAddress) ) {
						FTPSend(s, "550 Could not open flash for write.\r\n", 0);
						tcp_Close(&ftp_data);
						sys_free(pdata);
						break;
					}

					WriteToFlash(pdst, pdata, ENV_VAR_MTD_SIZE);

					if( !FWBClose() ) {
						FTPSend(s, "550 Could not close flash.\r\n", 0);
						tcp_Close(&ftp_data);
						sys_free(pdata);
						break;
					}

					sys_free(pdata);

					/* Here is the hack that will adjust the offset so that the store 
					 * will write to the correct area in the flash */
					flashOffset=CFGMAN_MTD_OFFSET;
				}
			}

			FTPSend(s, "150 Opening BINARY mode.\r\n", 0);
			ftpServerStatus = STATUS_UPLOAD;
			break;
			
		case TOK_TYPE:
			sys_sprintf(buffer, "200 Type set to %s.\r\n", argstr);
			FTPSend(s, buffer, 0);
			if (strcmp(argstr, "I") == 0)
				ftpType = TYPE_BINARY;
			else
				ftpType = TYPE_ASCII;
			break;

		case TOK_RETR:
			if (ftpCheckState() == 0) {
				FTPSend(s, "550 Data Socket is not ready.\r\n", 0);
				break;
			}
/*			if (ftpMedia == MEDIA_NONE)
				ftpMedia = MEDIA_SDRAM;
*/			
			if (ftpType == TYPE_BINARY)
				strcpy(buffer,  "150 Opening BINARY mode data connection for file transfer.\r\n");
			else
				strcpy(buffer, "150 Opening ASCII mode data connection for file transfer.\r\n");
			
			ftpServerStatus = STATUS_DOWNLOAD;

			if (strcmp(argstr, "config.xml") == 0) {
				FTPSend(s, buffer, 0);	
				if (RetrConfigSpace(&ftp_data) == TRUE)
					break;
			}
			else if (strcmp(argstr, "env") == 0) {
				FTPSend(s, buffer, 0);
				RetrEnvSpace(&ftp_data);
			}
	else if (sys_getenv(argstr) != NULL)
	{ // by Oleg
	 start = sys_getenv(argstr);
	 end = strtok(start, ',');
	 if ((start == NULL) || (end == NULL) || 
	  (myatox(start,&flashAddress) == 0) || (myatox(end,&endAddress) == 0))
	 {
	  FTPSend(s, "550 invalid <blockname>.\r\n", 0);
	  tcp_Close(&ftp_data);
	  break;
	 }
	 FTPSend(s, buffer, 0);
	 if (RetrMtdSpace(&ftp_data) == TRUE) break; // transfer by parts

	}
			else {
				FTPSend(s, "550 File not found.\r\n", 0);
				tcp_Close(&ftp_data);
				break;
			}
			tcp_Close(&ftp_data);
			FTPSend(s, "226 Transfer complete.\r\n", 0);
			ftpServerStatus = STATUS_IDLE;					
			break;

		case TOK_MEDIA:
			if (strcmp(argstr, "FLSH") == 0)
			{
				ftpMedia = MEDIA_FLASH;
				FTPSend(s, "200 media set to FLASH\r\n", 0);
			}
			else
			{
				ftpMedia = MEDIA_SDRAM;
				FTPSend(s, "200 media set to SDRAM\r\n", 0);
			}
			break;

		case TOK_GETENV:
			cp = sys_getenv(argstr);
			if (cp == NULL)
				sys_sprintf(buffer, "501 %s environment variable not set.\r\n", argstr);
			else {
				sys_sprintf(buffer, "%-20s  %s\r\n\r\n200 GETENV successful\r\n", argstr, cp);
			}
			FTPSend(s, buffer, 0);
			break;
			
		case TOK_SETENV:
			cp = strtok(argstr, ',');
			if (sys_setenv(argstr, cp) == 0)
				FTPSend(s, "200 SETENV successful\r\n", 0);
			else
				FTPSend(s, "501 SETENV failed.\r\n", 0);
			break;

		case TOK_UNSETENV:
			if (sys_unsetenv(argstr) != 0) 
				FTPSend(s, "501 no such variable.\r\n", 0);
			else
				FTPSend(s, "200 UNSETENV successful\r\n", 0);
			break;
			
		case TOK_FIXENV:
			if (fixenv(0, NULL) != 0) 
				FTPSend(s, "501 FIXENV error.\r\n", 0);
			else
				FTPSend(s, "200 FIXENV successful\r\n", 0);
			break;

		case TOK_PRINTENV:
			FTPSend(s, "214-list\r\n", 0);
			RetrEnvSpace(s);
			FTPSend(s, "214 PRINTENV successful\r\n", 0);
			break;

		case TOK_REBOOT:
			sys_sprintf(buffer, "221 Goodbye.\r\n");
			FTPSend(s, buffer, 0);
			tcp_Close(s);
			rebootFlag = TRUE;
			break;
			
		default:
			FTPSend(s, "502 not implemented - Try HELP.\r\n", 0);
			break;
	}
}

void FTPCommandHandler (tcp_Socket *s, byte *dp, int len, int state)
{
  	byte c, *bp, data[80];
  	int i;

  	if (state == SOPEN || state == SABORT || state == SCLOSE) {
		if (ftp_ctl.state == tcp_StateCLOSED)
			ftpServerStatus = STATUS_NONE;
		return;
	}
	
  	if (dp == 0) 
	{
		if ((ftp_data.state != 0) &&(ftp_data.state != tcp_StateCLOSED)) {
			tcp_Abort(&ftp_data);
		}
		return;
	}
	
  	do 
	{
		i = len;
		if ( i > sizeof data ) 
			i = sizeof data;
		MoveW(dp, data, i);
		dp += i;
		len -= i;
		bp = data;
		while ( i-- > 0 ) 
		{
			c = *bp++;
      		if ( c != '\r' ) 
        	{
        		if ( c == '\n' ) 
          		{
          			ftp_cmdbuf[ftp_cmdbufi] = 0;
          			FTPCommandLine(s);
          			ftp_cmdbufi = 0;
          		} 
         		else 
          		{
          			if ( ftp_cmdbufi < ((sizeof ftp_cmdbuf)-1) ) 
				{
					ftp_cmdbuf[ftp_cmdbufi++] = c;
				}
          		}
        	}
		}
	}while(len > 0);
}

void FTPCtrlHandler(tcp_Socket *s, byte *dp, int len, int state)
{
	switch (ftpServerStatus)
	{
		case STATUS_WELCOME:
			FTPSend(s, "220 ADAM2 FTP Server ready.\r\n", 0);
			ftpServerStatus = STATUS_LOGIN;
			break;

		case STATUS_LOGIN:
		case STATUS_IDLE:
		case STATUS_PASSIVE:
		case STATUS_ACTIVE:
		case STATUS_LIST :
		case STATUS_UPLOAD :
		case STATUS_DOWNLOAD :
		case STATUS_NONE:
			FTPCommandHandler(s, dp, len, state);
			break;
	
		default:
			sys_printf("FTPCtrlHandler: Unknown -%d\n", ftpServerStatus);
			break;
	}
}

int FTPServer(void)
{
	tcp_Init();
	rebootFlag = FALSE;
	ftpMedia = MEDIA_SDRAM; /* MEDIA_NONE; */
	ftpType = TYPE_NONE;
	tcp_Listen(&ftp_ctl, 21, FTPCtrlHandler, 0);
	ftpServerStatus = STATUS_WELCOME;
	return 1;
}

void autodetect_Handler(void)
{
 char cp[20];
 longword rcv_ipaddress, req_ipaddress = 0x0;
 autodetectPacket rxpacket;
 UINT32 bootloaderVersion = 0x0;

 if ((udp_receive(&rcv_ipaddress, &rxpacket, sizeof(autodetectPacket), FALSE)) == 0) return;

 bootloaderVersion = lfix(rxpacket.version);
// by Oleg commented this check
/*
 sys_printf("adam2app packet received: 0x%x\n", bootloaderVersion);

 if ((((bootloaderVersion>>16) & 0xFF) == MonitorMajorRev) &&
  (((bootloaderVersion>>8) & 0xFF) == MonitorMinorRev) &&
  ((bootloaderVersion & 0xFF) == TelogyMonitorRev))
*/
 {
/* Check the version in the packet from PC Application If it is same as 
 * BootLoader version then proceed further.*/
	if (rxpacket.type == TYPE_REQUEST)
	{
		req_ipaddress = lfix(rxpacket.data);
		sys_memset(&rxpacket, 0, sizeof(autodetectPacket));
		rxpacket.version = lfix(bootloaderVersion);
		rxpacket.type = TYPE_RESPONSE;
		if (req_ipaddress == 0x0) rxpacket.data = sin_lclINAddr;
		else
	   	{
			sin_lclINAddr = req_ipaddress;
			sys_memset(cp, 0, sizeof(cp));
			sys_sprintf(cp, "%d.%d.%d.%d",
				((req_ipaddress>>24) & 0xff),
				((req_ipaddress>>16) & 0xff),
				((req_ipaddress>>8) & 0xff),
				(req_ipaddress & 0xff));
			sys_setenv("my_ipaddress", cp);
			rxpacket.data = req_ipaddress;
		}
		udp_send(rcv_ipaddress, sizeof(autodetectPacket), &rxpacket);
	}
 }
}

int adam2Autodetect(void)
{
	if (!udplib_init(sin_lclINAddr)) return 0;
	if (!udplib_open(5035, 5035, autodetect_Handler)) return 0;
	return 1;
}
#endif /* FTP_SERVER_SUPPORT */













/*****************************************************************************************/

#ifdef FTP_CLIENT_SUPPORT
int datainbound;
short ftp_rcvState;
#define ftp_StateGETCMD     0       /* get a command from the user */
#define ftp_StateIDLE       1       /* idle connection */
#define ftp_StateINCOMMAND  2       /* command sent, awaiting response */
#define ftp_StateRCVRESP    3       /* received response, need more data */

char *ftp_script[8];
int ftp_scriptline;
BOOL ftp_echoMode;

void ftp_ctlHandler (tcp_Socket *s, byte *dp, int len, int state)
{
  	byte c, *bp, data[80];
  	int i;

  	if (state == SOPEN)
    	return;

  	if (dp == 0) 
    {
    	tcp_Abort(&ftp_data);
    	return;
    }

  	do 
    {
    	i = len;
    	if ( i > sizeof data ) 
      		i = sizeof data;
    	MoveW(dp, data, i);
    	dp += i;
    	len -= i;
    	bp = data;
    	while ( i-- > 0 ) 
      	{
      		c = *bp++;
      		if ( c != '\r' ) 
        	{
        		if ( c == '\n' ) 
          		{
          			ftp_cmdbuf[ftp_cmdbufi] = 0;
          			ftp_commandLine();
          			ftp_cmdbufi = 0;
          		} 
         		else 
          		{
          			if ( ftp_cmdbufi < ((sizeof ftp_cmdbuf)-1) ) 
            		{
            			ftp_cmdbuf[ftp_cmdbufi++] = c;
            		}
          		}
        	}
      	}
    }while(len > 0);
}

void ftp_commandLine(void)
{
  	char anum[10], *sp, *dp;
  	int i;

  	dp = anum;
  	sp = (char *)ftp_cmdbuf;
  	while ((*sp == ' ') && (*sp == '\t')) 
    	sp++;
  	i = 0;
  	while (( i< ((sizeof anum) - 1)) && (*sp >= '0') && (*sp <= '9'))
    	*dp++ = *sp++;
  	*dp = 0;
  	i = atol(anum);
  	if ((i == 553) || (i == 450) || (i == 550) || (i == 425) || (i == 426) ||
       	(i == 451) || (i == 500) || (i == 501) || (i == 421) || (i == 530))
		sys_printf("> %s\n", ftp_cmdbuf);
	
    switch (ftp_rcvState) 
	{
    	case ftp_StateIDLE:
        	if (ftp_cmdbuf[3] == '-')
            	ftp_rcvState = ftp_StateRCVRESP;
        	break;

     	case ftp_StateINCOMMAND:
        	if ( ftp_cmdbuf[3] == '-' )
            	ftp_rcvState = ftp_StateRCVRESP;
			
     	case ftp_StateRCVRESP:
        	if ( ftp_cmdbuf[3] == ' ' )
            	ftp_rcvState = ftp_StateIDLE;
        	break;
    }
}

void ftp_Abort(void)
{
	tcp_Abort(&ftp_ctl);
	tcp_Abort(&ftp_data);
}

void ftp_application(void)
{
    char *s;
    char *dp;
    int i;
    char achar;

    i = -1;
    if (SioInCharCheck(&achar)) 
    {
      	i = achar & 0177;      	
		if ( i == ('C' & 037) ) 
		{
        	tcp_Close(&ftp_ctl);
        }
   	}

    switch (ftp_rcvState) 
    {
      	case ftp_StateGETCMD:
 getcmd:	if ( i != -1 ) 
			{
            	ftp_outbuf[ftp_outbuflen] = 0;
            	switch (i) 
				{
                	case 'H' & 037:
                	case 0177:
                    	if ( ftp_outbuflen > 0 ) 
						{
                        	ftp_outbuflen--;
                        	sys_printf("\010 \010");
                    	}
                    	break;

                	case 'R' & 037:
                    	if ( ftp_echoMode )
                        	sys_printf("\nFtpCmd> %s", ftp_outbuf);
                    	break;

                	case 033:
                    	ftp_echoMode = ! ftp_echoMode;
                    	break;

                	case '\r':
                	case '\n':
                    	SioOutChar('\n');
                    	dp = (char *)&ftp_outbuf[ftp_outbuflen];
                    	goto docmd;

                	default:
                    	if ( i >= ' ' && ftp_outbuflen < sizeof ftp_outbuf ) 
						{
                        	ftp_outbuf[ftp_outbuflen++] = i;
                        	if ( ftp_echoMode ) SioOutChar(i);
                    	}
            	}
        	}
        	break;

      	case ftp_StateIDLE:
        	if ( ftp_scriptline < 0 ) 
			{
            	ftp_rcvState = ftp_StateGETCMD;
            	ftp_echoMode = TRUE;
	            ftp_outbuflen = 0;
    	        sys_printf("FtpCmd> ");
        	    goto getcmd;
        	}
	        if (datainbound)     /*Don't process commands whiles data is inbound!!*/
		        return;
        	s = ftp_script[ftp_scriptline];
	        if ( s == NULL )
    	        break;
        	ftp_scriptline++;
        	dp = (char *)ftp_outbuf;
	        while (( *dp++ = *s++ ));
        	dp--;
docmd: 		*dp++ = '\r';
        	*dp++ = '\n';
        	ftp_outbuflen = (int)dp - (int)ftp_outbuf;
        	ftp_outbufix = 0;
        	ftp_rcvState = ftp_StateINCOMMAND;
        	/* fall through */
			
    	case ftp_StateINCOMMAND:
	        i = ftp_outbuflen - ftp_outbufix;
    	    if ( i > 0 ) 
			{
            	i = tcp_Write(&ftp_ctl, &ftp_outbuf[ftp_outbufix], i);
            	ftp_outbufix += i;
            	tcp_Flush(&ftp_ctl);
        	}
        	/* fall through */

    	case ftp_StateRCVRESP:
        	break;
    }
}

void ftp(in_HwAddress host, in_HwAddress my_ipval, char *user, char *pass, char *cwd, char *fn, procref dataHandler)
{
    word port;
    char filecmd[80];
    char portcmds[80];
    int index;

    index = 0;
    port = (sed_lclEthAddr[2] + rtim) | 0x8000;
    if (fn) 
	{
        /* set up the script for this session */
        ftp_script[index++] = user;
        ftp_script[index++] = pass;
        if (strlen(cwd))
        	ftp_script[index++] = cwd;
        ftp_script[index++] = "type i";

        sys_sprintf(portcmds,"port %d,%d,%d,%d,%d,%d",
                (my_ipval>>24)&0x0ff,
                (my_ipval>>16)&0x0ff,
                (my_ipval>> 8)&0x0ff,
                (my_ipval    )&0x0ff,
                ((port>>8)&0x0ff),
                (port&0x0ff));
        ftp_script[index++] = portcmds;

        sys_sprintf(filecmd, "retr %s", fn);
        ftp_script[index++] = filecmd;

        ftp_script[index++] = "quit";
        ftp_script[index++] = 0;
        ftp_scriptline = 0;
    } 
	else 
	{
        ftp_scriptline = -1;        /* interactive mode */
        ftp_echoMode = TRUE;
    }

    /* set up state variables */
    ftp_rcvState = ftp_StateRCVRESP;
    ftp_cmdbufi = 0;
    tcp_Listen(&ftp_data, port, dataHandler, 0);
    tcp_Open(&ftp_ctl, port, host, 21, ftp_ctlHandler);
#ifndef DHCP_SUPPORT
	tcp(ftp_application);
#else
    tcp_receive(ftp_application);
#endif
}

static char inseq[]="0123456789-=\\`!@#$\%^&*()_+|~qwertyuiop[]QWERTYUIOP{}asdfghjkl;'ASDFGHJKL:\"zxcvbnm,./ZXCVBNM<>?";

void getpass(char *str, char *rpass, int len)
{
  	char achar;

  	*rpass = 0;
  	sys_printf("%s ",str);
  	if (len==0) return;
  	len--;
  	do
    {
    	achar=getch();
    	if ((achar!='\015')&&(achar!='\n'))
      	{
      		sys_printf("*");
      		if (len)
        	{
        		*rpass++=achar;
        		len--;
        		*rpass=0;
	        }
      	}
    }while((achar!='\015') && (achar!='\n'));
  	sys_printf("\n");
}

int encrypt(char *inp, char *outp)
{
  	int j,i,modo;
  	char *cp;

  	j = 0;
  	*outp=0;
  	modo = strlen(inseq);
  	*outp++='~';
  	while(*inp)
    {
    	j++;
    	i = 0;
    	cp = inseq;
    	while(*cp != *inp)
      	{
      		i++;
      		cp++;
      	}
    	if (!(*cp)) 
      		return(FALSE); 
    	i += 10 + (j * 2);
    	i = i % modo;
    	*outp++ = inseq[i];
    	*outp = 0;
    	inp++;
    }
  	return(TRUE);
}

/*NOTE:gg30e application specific:
 * this decrypt implementation is copied and used as such in 
 * vng/pform/gg30e/hardware/adam_if.c file.
 * Any updates to this function here need to be reflected in 
 * that file too*/
int decrypt(char *inp, char *outp)
{
  	int j, i, modo;
  	char *cp;

  	j = 0;
  	*outp = 0;
  	modo = strlen(inseq);
  	if (*inp++ != '~')
    	return(FALSE);
  	while(*inp)
    {
    	j++;
    	i = 0;
    	cp = inseq;
    	while(*cp != *inp)
      	{
      		i++;
      		cp++;
      	}
    	if (!(*cp)) 
      		return(FALSE); 
    	i += modo - (10 + (j * 2));
    	i = i % modo;
    	*outp++ = inseq[i];
    	*outp = 0;
    	inp++;
    }
  	return(TRUE);
}

int newpass(void)
{
  	char pass[31], pass1[30], pass2[30];

  	getpass("   Enter Password:", pass1, sizeof pass1);
  	getpass("Re-Enter Password:", pass2, sizeof pass2);
	
  	if (strcmp(pass1, pass2)!=0)
	{
		sys_printf("Passwords are not the same.\n");
		return(1);
	}
  	if (strlen(pass1) < 4) 
	{
		sys_printf("Password to small, must be at least 4 characters.\n");
		return(1);
	}		
  	if (!encrypt(pass1, pass))
	{
		sys_printf("Cannot encrypt password.\n");
		return(1);
	}  	
	sys_setenv("remote_pass", pass);
  	return(0);
}
#endif /* FTP_CLIENT_SUPPORT */




#if 0
#define isprint(a) ((a >=' ')&&(a <= '~'))
void xdump (byte *cp, int length, char *prefix)
{
    int col, count;
    byte prntBuf[120];
    char  *pBuf = (char *)prntBuf;
    count = 0;
    while(count < length)
	{
        pBuf += sys_sprintf( pBuf, "%s", prefix );
        for(col = 0;count + col < length && col < 16; col++){
            if (col != 0 && (col % 4) == 0)
                pBuf += sys_sprintf( pBuf, " " );
            pBuf += sys_sprintf( pBuf, "%02X ", cp[count + col] );
        }
        while(col++ < 16)
		{      
			/* pad end of buffer with blanks */
            if ((col % 4) == 0)
                sys_sprintf( pBuf, " " );
            pBuf += sys_sprintf( pBuf, "   " );
        }
        pBuf += sys_sprintf( pBuf, "  " );
        
		for(col = 0;count + col < length && col < 16; col++)
		{
            if (isprint((int)cp[count + col]))
                pBuf += sys_sprintf( pBuf, "%c", cp[count + col] );
            else
                pBuf += sys_sprintf( pBuf, "." );
        }
        sys_sprintf( pBuf, "\n" );
        sys_printf((char *)prntBuf);
        count += col;
        pBuf = (char *)prntBuf;
    }
}
#endif
