/*-----------------------------------------------------------------------------*/
/*                                                                             */
/*   Copyright (C) 1996-2003 by Texas Instruments, Inc.  All rights reserved.  */
/*   Copyright (C) 2001-2003 Telogy Networks, Inc.							   */
/*                                                                             */
/*     IMPORTANT - READ CAREFULLY BEFORE PROCEEDING TO USE SOFTWARE.           */
/*                                                                             */
/*  This document is displayed for you to read prior to using the software     */
/*  and documentation.  By using the software and documentation, or opening    */
/*  the sealed packet containing the software, or proceeding to download the   */
/*  software from a Bulletin Board System(BBS) or a WEB Server, you agree to   */
/*  abide by the following Texas Instruments License Agreement. If you choose  */
/*  not to agree with these provisions, promptly discontinue use of the        */
/*  software and documentation and return the material to the place you        */
/*  obtained it.                                                               */
/*                                                                             */
/*                               *** NOTE ***                                  */
/*                                                                             */
/*  The licensed materials contain MIPS Technologies, Inc. confidential        */
/*  information which is protected by the appropriate MIPS Technologies, Inc.  */
/*  license agreement.  It is your responsibility to comply with these         */
/*  licenses.                                                                  */
/*                                                                             */
/*                   Texas Instruments License Agreement                       */
/*                                                                             */
/*  1. License - Texas Instruments (hereinafter "TI"), grants you a license    */
/*  to use the software program and documentation in this package ("Licensed   */
/*  Materials") for Texas Instruments broadband products.                      */
/*                                                                             */
/*  2. Restrictions - You may not reverse-assemble or reverse-compile the      */
/*  Licensed Materials provided in object code or executable format.  You may  */
/*  not sublicense, transfer, assign, rent, or lease the Licensed Materials    */
/*  or this Agreement without written permission from TI.                      */
/*                                                                             */
/*  3. Copyright - The Licensed Materials are copyrighted. Accordingly, you    */
/*  may either make one copy of the Licensed Materials for backup and/or       */
/*  archival purposes or copy the Licensed Materials to another medium and     */
/*  keep the original Licensed Materials for backup and/or archival purposes.  */
/*                                                                             */
/*  4. Runtime and Applications Software - You may create modified or          */
/*  derivative programs of software identified as Runtime Libraries or         */
/*  Applications Software, which, in source code form, remain subject to this  */
/*  Agreement, but object code versions of such derivative programs are not    */
/*  subject to this Agreement.                                                 */
/*                                                                             */
/*  5. Warranty - TI warrants the media to be free from defects in material    */
/*  and workmanship and that the software will substantially conform to the    */
/*  related documentation for a period of ninety (90) days after the date of   */
/*  your purchase. TI does not warrant that the Licensed Materials will be     */
/*  free from error or will meet your specific requirements.                   */
/*                                                                             */
/*  6. Remedies - If you find defects in the media or that the software does   */
/*  not conform to the enclosed documentation, you may return the Licensed     */
/*  Materials along with the purchase receipt, postage prepaid, to the         */
/*  following address within the warranty period and receive a refund.         */
/*                                                                             */
/*  TEXAS INSTRUMENTS                                                          */
/*  Application Specific Products, MS 8650                                     */
/*  c/o ADAM2 Application Manager                                              */
/*  12500 TI Boulevard                                                         */
/*  Dallas, TX 75243  - U.S.A.                                                 */
/*                                                                             */
/*  7. Limitations - TI makes no warranty or condition, either expressed or    */
/*  implied, including, but not limited to, any implied warranties of          */
/*  merchantability and fitness for a particular purpose, regarding the        */
/*  licensed materials.                                                        */
/*                                                                             */
/*  Neither TI nor any applicable licensor will be liable for any indirect,    */
/*  incidental or consequential damages, including but not limited to loss of  */
/*  profits.                                                                   */
/*                                                                             */
/*  8. Term - The license is effective until terminated.   You may terminate   */
/*  it at any other time by destroying the program together with all copies,   */
/*  modifications and merged portions in any form. It also will terminate if   */
/*  you fail to comply with any term or condition of this Agreement.           */
/*                                                                             */
/*  9. Export Control - The re-export of United States origin software and     */
/*  documentation is subject to the U.S. Export Administration Regulations or  */
/*  your equivalent local regulations. Compliance with such regulations is     */
/*  your responsibility.                                                       */
/*                                                                             */
/*                         *** IMPORTANT NOTICE ***                            */
/*                                                                             */
/*  Texas Instruments (TI) reserves the right to make changes to or to         */
/*  discontinue any semiconductor product or service identified in this        */
/*  publication without notice. TI advises its customers to obtain the latest  */
/*  version of the relevant information to verify, before placing orders,      */
/*  that the information being relied upon is current.                         */
/*                                                                             */
/*  TI warrants performance of its semiconductor products and related          */
/*  software to current specifications in accordance with TI's standard        */
/*  warranty. Testing and other quality control techniques are utilized to     */
/*  the extent TI deems necessary to support this warranty. Unless mandated    */
/*  by government requirements, specific testing of all parameters of each     */
/*  device is not necessarily performed.                                       */
/*                                                                             */
/*  Please be aware that Texas Instruments products are not intended for use   */
/*  in life-support appliances, devices, or systems. Use of a TI product in    */
/*  such applications without the written approval of the appropriate TI       */
/*  officer is prohibited. Certain applications using semiconductor devices    */
/*  may involve potential risks of injury, property damage, or loss of life.   */
/*  In order to minimize these risks, adequate design and operating            */
/*  safeguards should be provided by the customer to minimize inherent or      */
/*  procedural hazards. Inclusion of TI products in such applications is       */
/*  understood to be fully at the risk of the customer using TI devices or     */
/*  systems.                                                                   */
/*                                                                             */
/*  TI assumes no liability for TI applications assistance, customer product   */
/*  design, software performance, or infringement of patents or services       */
/*  described herein. Nor does TI warrant or represent that license, either    */
/*  expressed or implied, is granted under any patent right, copyright, mask   */
/*  work right, or other intellectual property right of TI covering or         */
/*  relating to any combination, machine, or process in which such             */
/*  semiconductor products or services might be or are used.                   */
/*                                                                             */
/*  All company and/or product names are trademarks and/or registered          */
/*  trademarks of their respective manaufacturers.                             */
/*                                                                             */
/*-----------------------------------------------------------------------------*/

#include "_stdio.h"
#include "support.h"
#include "sio.h"

#define getchar SioInChar             
#define outchar SioOutChar

void SkipSpaces(char **ptr)
  {
  while((**ptr==' ')||(**ptr=='\t')) (*ptr)++;
  }


int IsCharMember(char achar,char *member)
  {
   
  while(*member)
    {
    if (achar==*member++)
      return(TRUE);
    }
  return(FALSE);
  }

void GetStringField(char **cpp,char *cstr,int clen,char *leagals)
  {
  int orig_clen;

  orig_clen=clen;
  SkipSpaces(cpp);
  while ((isalnum(**cpp))||(IsCharMember(**cpp,leagals)))
    {
    if (clen)
      {
      clen--;
      *cstr++=**cpp;
      }
    (*cpp)++;
    }
  if (!orig_clen) return;
  if (!clen) clen--;
  *cstr=0;
  }

void GetInputLine(char *str,int len,char *leagals)
  {
  char achar;
  int index;

  index=0;
  while(TRUE)
    {
    achar=getchar(); 
    achar&=0x7f;
    switch(achar)
      {             
      case 13:
      case '\n':   if (len) 
                     str[index]=0;   
                   outchar('\015');
                   outchar('\n');
                   return;
      case '\010': if (index)
                     {
                     index--;  
                     outchar('\010');
                     outchar(' ');
                     outchar('\010');
                     }
                   break;
      default:     if ((isalnum(achar))||(IsCharMember(achar,leagals)))
                     {
                     if ((index+1)<len)
                       {
                       str[index++]=achar; 
                       outchar(achar);
                       }                       
                     }
                    else
                     sys_printf("\nChar '%c'(%02x) Ignored!",achar,achar&0x0ff);
                   break;
      }
    }
  }

char *strcat(char *s1, const char *s2)  
  {     
  char *cp;
  cp=s1;  
  while(*cp) cp++;
  while(*s2) *cp++=*s2++;
  *cp=*s2;
  return(s1);
  }
  
char *strcpy(char *s1, const char *s2) 
  {           
  char *cp;
  
  cp=s1;
  while(*s2)
    *cp++=*s2++;
  *cp=*s2; 
  return(s1);
  }

char *strncpy(char *s1, const char *s2, int len) 
  {           
  char *cp;
  
  cp=s1;
  while(*s2 && len) {
    *cp++=*s2++;
	len--;
  }
  *cp=*s2; 
  return(s1);
  }
  
size_t strlen(const char *s)
  {                            
  register int len=0;
  
  while(*s)
    {
    s++;
    len++;
    }
  return(len);  
  }

int isupper(int c)
  {
  return((c>='A')&&(c<='Z'));
  }      

int isalpha(int c)
  {
  return(isupper(c)||islower(c));
  }

int toupper(int c)
{
	if (islower(c))
		return c - ('a' - 'A');
	else
		return c;
}        

int islower(int c)
{
  return((c>='a')&&(c<='z'));
}        
  
int isalnum(int c)
  {
  return(isalpha(c)||isdigit(c));
  }
  
int isxdigit(int c)
  {    
  if (((c>='0')&&(c<='9'))||
      ((c>='a')&&(c<='f'))||
      ((c>='A')&&(c<='F'))  )  
    return(TRUE);
   else
    return(FALSE);   
  }    
                        
int isdigit(int c)
  {
  return((c>='0')&&(c<='9'));
  }    

int strcmp(const char *s1,const char *s2)
{
	int len1, len2;
	
	len1 = strlen(s1);
	len2 = strlen(s2);
	if (len1 != len2)
		return (len1 - len2);

	while (*s1 || *s2)
	    if (*s1++ != *s2++)
    		return (*--s1 - *--s2);
    return 0;
}

char *strchr(const char *s, int c)
  {

  while(*s)
    {
    if (*s==(char)c)
      {
      return((char *)s);
      }
    s++;
    }
  return(0);
  }

char *strrchr(char *s, int	c)
{
	char	*fs;

	for (fs = 0;; ++s) 
	{
	    if (*s == c) 
			fs = s;
	    if (!*s) 
			return fs;
	}
}

char *strtok(char *s, int c)
{
	char *fs = "";
	
  	while(*s)
    {
    	if (*s==(char)c)
      	{
			fs = (char *)(s + 1);
			*s = 0;
      		return(fs);
      	}
    	s++;
    }
  	return(fs);
}

int strncmp(const char * cs,const char * ct,size_t count)
  {
  register signed char result = 0;

  while (count) 
    {
    if (( result = (*cs - *ct++)) != 0 || !*cs++)
      break;
    count--;
    }

  return(result);
  }

unsigned int atoui(char *cp)
  {
  unsigned int itmp,base;
  char c;

  /* Eliminate leading and trailing white space */

  while((*cp==' ')||(*cp=='\t')) cp++;
  while((strlen(cp))&&((cp[strlen(cp)-1]==' ')||(cp[strlen(cp)-1]=='\t')))
    cp[strlen(cp)-1]=0;
  if ((cp[0]=='0')&&((cp[1]&0x5f)=='X'))
    {
    base=16; 
    cp+=2;
    }
   else
    base=(cp[0]=='0')?8:10;
  itmp=0;
  while(*cp)
    {
    c=*cp++;
    if ((c>='a')&&(c<='f')&&(base==16)) 
      c&=0x5f;
    if ((c>='0')&&(c<='9'))
      {
      if ((base==8)&&(c>'7')) 
        return(0);
      itmp=itmp*(unsigned int)base;
      itmp+=(unsigned int)(c-'0');
      }
     else
      {
      if ((base!=16)||(!((c>='A')&&(c<='F'))) )
        return(0);
       else
        {
        itmp<<=4;
        itmp+=(c>='A')?((unsigned int)(c-0x37)):((unsigned int)(c-'0'));
        }
      }
    }
  return(itmp);
  }


#define isspace(c)	((c == ' ') ? 1 : 0)

unsigned long
strtoul(
	const 	char 	*str,
		char 	**endptr,
		int 	base)
{
	const char *s;
	unsigned long acc, cutoff;
	int c;
	int neg, any, cutlim;

    /*
	 * See strtol for comments as to the logic used.
	 */
	s = str;
	do {
		c = (unsigned char) *s++;
	} while (isspace(c));
	if (c == '-') {
		neg = 1;
		c = *s++;
	} else {
		neg = 0;
		if (c == '+')
			c = *s++;
	}
	if ((base == 0 || base == 16) &&
	    c == '0' && (*s == 'x' || *s == 'X')) {
		c = s[1];
		s += 2;
		base = 16;
	}
	if (base == 0)
		base = c == '0' ? 8 : 10;

	cutoff = MAXUINT(sizeof(UINT32)) / (unsigned long)base;
	cutlim = MAXUINT(sizeof(UINT32)) % (unsigned long)base;
	for (acc = 0, any = 0;; c = (unsigned char) *s++) {
		if (isdigit(c))
			c -= '0';
		else if (isalpha(c))
			c -= isupper(c) ? 'A' - 10 : 'a' - 10;
		else
			break;
		if (c >= base)
			break;
		if (any < 0)
			continue;
		if ((acc > cutoff) || ((acc == cutoff) && (c > cutlim))) {
			any = -1;
			acc = MAXUINT(sizeof(UINT32));			
		} else {
			any = 1;
			acc *= (unsigned long)base;
			acc += c;
		}
	}
	if (neg && any > 0)
		acc = -acc;
	if (endptr != 0)
		*endptr = (char *) (any ? s - 1 : (char *) str);
	return (acc);
}

unsigned long atoul(const char *str)
  {
  return(strtoul (str, (char **) 0, 0));
  } 

#define	 max_allowable(A) 	 (MAXINT(sizeof(INT32))/A - 1)

long strtol(const char *str, char **endptr, int base)
{
	long  	i = 0;
	int   	s = 1;
	int 	c;
	
	while(isspace(*str)) { // skip white space
		str++;
	}
	
	if (*str == '+') // sign flag check
		str++;
	else if (*str == '-') 
	{
		s = -1;
		str++;
	}

	if (*str == '0') 
	{
		if (toupper(*++str) == 'X')	
			base = 16,str++;
		else if (base == 0)	
			base = 8;
	}
	if (base == 0) 
		base = 10;
	
	if (base <= 10)

		for (; isdigit(*str); str++) // digit str to number
		{
			if (i < max_allowable(base))
				i = i * base + (*str - '0');
			else 
				i = MAXINT(sizeof(INT32));
		}
	else if (base > 10) 
	{
		for (; (c = *str); str++) 
		{
			if (isdigit(c))
			 	c = c - '0';
			else 
			{
				c = toupper(c);
				if (c >= 'A' && c < ('A' - 10 + base))
				 	c = c - 'A' + 10;
				else
				 	break;
			}
			if (i < max_allowable(base))
			 	i = i * base + c;
			else 
			 	i = MAXINT(sizeof(INT32));
		}
	}	
 	else
	 	return 0; // negative base is not allowed
	
	if (endptr) *endptr = (char *) str;

	if (s == -1)
		i = -i;

	return i;
}

unsigned long atol(const char *s)
{
  return (long) strtol (s, (char **) 0, 10);
}

