/*-----------------------------------------------------------------------------*/
/*                                                                             */
/*   Copyright (C) 2002-2003 by Texas Instruments, Inc.  All rights reserved.  */
/*   Copyright (C) 2002-2003 Telogy Networks.	    						   */
/*                                                                             */
/*   NOTE: THIS VERSION OF CODE IS MAINTAINED BY TELOGY NETWORKS AND NOT TI!   */
/*                                                                             */
/*-----------------------------------------------------------------------------*/

#ifndef _TINYIP_H_
#define _TINYIP_H_

#include "_stdio.h"
#include "mms.h"

extern void t_clear(void);
extern int t_get(void);

/* **************************** MACRO Definitions *************************** */

#define ETH_MSS 1400  /* MSS for Ethernet */

#define tcp_MaxData 	2048   	/* maximum bytes to buffer on output */
#define ftp_MaxData 	1024   	/* maximum bytes to buffer on output */

#define udp_MaxBufSize 	2048	/* maximum UINT8s to buffer on input */
#define icmp_MaxBufSize 2048	/* maximum UINT8s to buffer on input */


#define in_GetHdrlen(ip)  ((wfix((ip)->vht) >> 8) & 0xf)
#define in_GetHdrlenBytes(ip)  ((wfix((ip)->vht) >> 6) & 0x3c)

#define in_GetTTL(ip)      (wfix((ip)->ttlProtocol) >> 8)
#define in_GetProtocol(ip) (wfix((ip)->ttlProtocol) & 0xff)

#define clock_ValueRough() (t_get()/ticdiv)

#define MoveW(s,d,l)  (sys_memcpy(d,s,l))

#ifdef EB
#define wfix(a)    (a)
#define lfix(a)    (a)
#else
#define wfix(a)    ((((a)>>8)&0x0ff)|(((a)<<8)&0x0ff00))
#define lfix(a)    ((((a)>>24)&0x0ff)|(((a)>>8)&0x0ff00)|(((a)<<8)&0x0ff0000)|(((a)<<24)&0xff000000))
#endif

/* ARP definitions */
#define arp_TypeEther  1        /* ARP type of Ethernet address */

/* harp op codes */
#define ARP_REQUEST 1
#define ARP_REPLY   2

#define INADDR_ANY			((unsigned long)0x00000000)
#define INADDR_BROADCAST	((unsigned long)0xFFFFFFFF)
#define INADDR_NONE			((unsigned long)0x00000000)

/* These are Ethernet protocol numbers. */
#define UDP_PROTO  0x11
#define TCP_PROTO  0x06
#define ICMP_PROTO 0x01

#define tcp_MaxBufSize 2048		/* maximum UINT8s to buffer on input */

/* TCP Flags */
#define tcp_FlagFIN     0x0001
#define tcp_FlagSYN     0x0002
#define tcp_FlagRST     0x0004
#define tcp_FlagPUSH    0x0008
#define tcp_FlagACK     0x0010
#define tcp_FlagURG     0x0020
#define tcp_FlagDO      0xF000
#define tcp_GetDataOffset(tp) (wfix((tp)->flags) >> 12)

/* TCP states
 * Note: close-wait state is bypassed by automatically closing a connection
 *       when a FIN is received.  This is easy to undo.*/
#define tcp_StateLISTEN  0      /* listening for connection */
#define tcp_StateSYNSENT 1      /* syn sent, active open */
#define tcp_StateSYNREC  2      /* syn received, synack+syn sent. */
#define tcp_StateESTAB   3      /* established */
#define tcp_StateFINWT1  4      /* sent FIN */
#define tcp_StateFINWT2  5      /* sent FIN, received FINACK */
#define tcp_StateCLOSING 6      /* sent FIN, received FIN (waiting for FINACK) */
#define tcp_StateLASTACK 7      /* fin received, finack+fin sent */
#define tcp_StateTIMEWT  8      /* dally after sending final FINACK */
#define tcp_StateCLOSED  9      /* finack received */

#define SOPEN  1
#define SDATA  2
#define SCLOSE 3
#define SABORT 4

#define UDP_LENGTH ( sizeof( udp_Header ))

/* DHCP */
/* DHCP protocol -- see RFC 2131 */
#define SERVER_PORT     67
#define CLIENT_PORT     68

#define DHCP_MAGIC      0x63825363

/* DHCP option codes (partial list) */
#define DHCP_PADDING        0x00
#define DHCP_SUBNET     	0x01
#define DHCP_TIME_OFFSET    0x02
#define DHCP_ROUTER     	0x03
#define DHCP_TIME_SERVER    0x04
#define DHCP_NAME_SERVER    0x05
#define DHCP_DNS_SERVER     0x06
#define DHCP_LOG_SERVER     0x07
#define DHCP_COOKIE_SERVER  0x08
#define DHCP_LPR_SERVER     0x09
#define DHCP_HOST_NAME      0x0c
#define DHCP_BOOT_SIZE      0x0d
#define DHCP_DOMAIN_NAME    0x0f
#define DHCP_SWAP_SERVER    0x10
#define DHCP_ROOT_PATH      0x11
#define DHCP_IP_TTL     	0x17
#define DHCP_MTU        	0x1a
#define DHCP_BROADCAST      0x1c
#define DHCP_NTP_SERVER     0x2a
#define DHCP_NTP_SERVER     0x2a
#define DHCP_WINS_SERVER    0x2c
#define DHCP_REQUESTED_IP   0x32
#define DHCP_LEASE_TIME     0x33
#define DHCP_OPTION_OVER    0x34
#define DHCP_MESSAGE_TYPE   0x35
#define DHCP_SERVER_ID      0x36
#define DHCP_PARAM_REQ      0x37
#define DHCP_MESSAGE        0x38
#define DHCP_MAX_SIZE       0x39
#define DHCP_T1         	0x3a
#define DHCP_T2         	0x3b
#define DHCP_VENDOR     	0x3c
#define DHCP_CLIENT_ID      0x3d

#define DHCP_END        0xFF


#define BOOTREQUEST     1
#define BOOTREPLY       2

#define ETH_10MB        1
#define ETH_10MB_LEN   	6

#define DHCPDISCOVER    1
#define DHCPOFFER       2
#define DHCPREQUEST     3
#define DHCPDECLINE     4
#define DHCPACK         5
#define DHCPNAK         6
#define DHCPRELEASE     7
#define DHCPINFORM      8

#define BROADCAST_FLAG  0x8000

#define OPTION_FIELD    0
#define FILE_FIELD      1
#define SNAME_FIELD     2

/* miscellaneous defines */
#define MAC_BCAST_ADDR      (unsigned char *) "\xff\xff\xff\xff\xff\xff"
#define OPT_CODE 0
#define OPT_LEN 1
#define OPT_DATA 2

#define TYPE_MASK   0x0F

#define OPTION_REQ  0x10 /* have the client request this option */
#define OPTION_LIST 0x20 /* There can be a list of 1 or more of these */

/* ***************************** Data Variables **************************** */

/* Useful type definitions */
typedef void (*procref)();

/* protocol address definitions */
extern bit32u emacbase;

typedef longword in_HwAddress;
typedef word eth_HwAddress[3];

extern eth_HwAddress sed_lclEthAddr;
extern eth_HwAddress sed_ethBcastAddr;
extern in_HwAddress  sin_lclINAddr;
extern in_HwAddress  net_Gateway;
extern in_HwAddress  net_IpMask;

extern unsigned int av_cpufreq;
extern unsigned int ticdiv;

extern bit32u rtim;

extern int ip_initialized;

extern int rebootFlag;
extern int ftpServerStatus;

#define INDICATE_WRITE 		(64*1024)

/* ***************************** Data Structures **************************** */

/* The Ethernet header */
typedef struct {
    eth_HwAddress   destination __attribute__ ((packed));
    eth_HwAddress   source __attribute__ ((packed));
    word          	type;
} eth_Header;

/* Arp header */
typedef struct {
    word          	hwType;
    word          	protType;
    word          	hwProtAddrLen;  /* hw and prot addr len */
    word          	opcode;
    eth_HwAddress   srcEthAddr __attribute__ ((packed));
    in_HwAddress    srcIPAddr __attribute__ ((packed));
    eth_HwAddress   dstEthAddr __attribute__ ((packed));
    in_HwAddress    dstIPAddr __attribute__ ((packed));
} arp_Header;

/* The IP Header */
typedef struct {
    word          	vht;    /* version, hdrlen, tos */
    word   			length;
    word          	identification;
    word          	frag;
    word          	ttlProtocol; /* ttl, protocol - UDP / TCP */
    word          	checksum;
    in_HwAddress    source __attribute__ ((packed));
    in_HwAddress    destination __attribute__ ((packed));
} in_Header;

/* TCP Header */
typedef struct {
    word     	srcPort;
    word      	dstPort;
    longword    seqnum;
    longword    acknum;
    word      	flags;
    word      	window;
    word      	checksum;
    word      	urgentPointer;
} tcp_Header;

/* UDP Header */
typedef struct {
    word  		srcPort;
    word      	dstPort;
    word      	length;
    word      	checksum;
} udp_Header;


/* The TCP/UDP Pseudo Header */
typedef struct {
    in_HwAddress    src __attribute__ ((packed));
    in_HwAddress    dst __attribute__ ((packed));
    octet           mbz;
    octet           protocol;
    word          	length;
    word          	checksum;
} tcp_PseudoHeader;

/* TCP Socket definition */
typedef struct _tcp_socket {
    struct _tcp_socket *next;
    word          	ip_type;        /* always set to TCP_PROTO */
    short           state;          /* connection state */
    procref         dataHandler;    /* called with incoming data */
    eth_HwAddress   hisethaddr;     /* ethernet address of peer */
    in_HwAddress    hisaddr;        /* internet address of peer */
    word          	myport, hisport;/* tcp ports for this connection */
    longword       	acknum, seqnum; /* data ack'd and sequence num */
    int             timeout;        /* timeout, in milliseconds */
    BOOL            unhappy;        /* flag, indicates retransmitting segt's */
    word          	flags;          /* tcp flags word for last packet sent */
    short           dataSize;       /* number of bytes of data to send */
    byte            data[tcp_MaxData]; /* data to send */
} tcp_Socket;

/* UDP socket definition */
typedef struct _udp_socket 
{
    struct _udp_socket 	*next;
    word          	ip_type;            /* always set to UDP_PROTO */
    procref         dataHandler;
	procref         appHandler;
    eth_HwAddress   hisethaddr;         /* peer's ethernet address */
    in_HwAddress   	hisaddr;            /* peer's internet address */
    word          	myport, hisport;    /* peer's UDP port */
    word          	locflags;

    int             rdatalen;           /* must be signed */
    word          	maxrdatalen;
    byte           	*rdata;
    byte           	rddata[udp_MaxBufSize + 1];	/* if dataHandler = 0, len == 512 */    
} udp_Socket;

#ifdef FTP_SERVER_SUPPORT
typedef struct _FTPCommand
{
	int tokenId;
	char *commandName;
	byte argFlag;
	//char *commandDescr;
} FTPCommand;

enum {
	TOK_ABOR, /* TOK_BYE, */ TOK_QUIT, 
	TOK_PORT, TOK_USER, TOK_PASS,
	TOK_HELP, /* TOK_SYST, */ TOK_PASV, 
/*	TOK_PASW, TOK_NLST, TOK_LIST, */
	TOK_STOR, TOK_TYPE, TOK_RETR, 
	TOK_MEDIA, TOK_GETENV, TOK_SETENV, 
	TOK_UNSETENV, TOK_FIXENV, TOK_PRINTENV, TOK_REBOOT, TOK_ERROR
};

enum {
	STATUS_NONE, STATUS_WELCOME, 
	STATUS_IDLE, STATUS_LOGIN, 
	STATUS_PASSIVE, STATUS_ACTIVE,
	STATUS_LIST, STATUS_UPLOAD,
	STATUS_DOWNLOAD
};

enum {
//	MEDIA_NONE, 
	MEDIA_FLASH, 
	MEDIA_SDRAM
};

enum {
	TYPE_NONE, 
	TYPE_BINARY, 
	TYPE_ASCII
};
#endif /* FTP_SERVER_SUPPORT */

typedef struct icmp_unused 
{
    UINT8       type;
    UINT8       code;
    word      	checksum;
    longword    unused;
    in_Header   ip;
    UINT8       spares[8];
} icmp_unused;

typedef struct icmp_pointer 
{
    UINT8       type;
    UINT8       code;
    word      	checksum;
    UINT8       pointer;
    UINT8       unused[3];
    in_Header   ip;
} icmp_pointer;

typedef struct icmp_ip 
{
    UINT8       type;
    UINT8       code;
    word      	checksum;
    longword    ipaddr;
    in_Header   ip;
} icmp_ip ;

typedef struct icmp_echo 
{
    UINT8       type;
    UINT8       code;
    word      	checksum;
    word      	identifier;
    word      	sequence;
} icmp_echo;

typedef struct icmp_timestamp 
{
    UINT8       type;
    UINT8       code;
    word      	checksum;
    word      	identifier;
    word      	sequence;
    longword    original;       /* original timestamp */
    longword    receive;        /* receive timestamp */
    longword    transmit;       /* transmit timestamp */
} icmp_timestamp;

typedef struct icmp_info 
{
    UINT8       type;
    UINT8       code;
    word      	checksum;
    word      	identifier;
    word      	sequence;
} icmp_info;

typedef union  
{
	struct icmp_unused      unused;
	struct icmp_pointer     pointer;
	struct icmp_ip          ip;
	struct icmp_echo        echo;
	struct icmp_timestamp   timestamp;
	struct icmp_info        info;
} icmp_pkt;

typedef struct _pkt 
{
    in_Header   in;
    icmp_pkt    icmp;
    byte   		data[icmp_MaxBufSize];
} _pkt;

#define ICMPTYPE_ECHOREPLY       0
#define ICMPTYPE_UNREACHABLE     3
#define ICMPTYPE_TIMEEXCEEDED    11

typedef enum ICMP_UnreachableCodes
{
   ICMP_UNREACH_NET = 0,
   ICMP_UNREACH_HOST = 1,
   ICMP_UNREACH_PROTO = 2,
   ICMP_UNREACH_PORT = 3,
   ICMP_UNREACH_FRAGNEEDED = 4,
   ICMP_UNREACH_SRCROUTEFAILED = 5
} ICMP_UnreachableCodes;

typedef enum ICMP_TimeExceededCodes
{
   ICMP_EXCEEDED_TTL = 0,
   ICMP_EXCEEDED_FRAGREASM = 1
} ICMP_TimeExceededCodes;


typedef struct _dhcpMessage
{
	UINT8 	op;
	UINT8 	htype;
	UINT8	hlen;
	UINT8	hops;
	UINT32	xid;
	UINT16	secs;
	UINT16	flags;
	UINT32	ciaddr;
	UINT32	yiaddr;
	UINT32	siaddr;
	UINT32	giaddr;
	UINT8	chaddr[16];
	UINT8	sname[64];
	UINT8	file[128];
	UINT32 	cookie;
	UINT8	options[308];
		
} dhcpMessage;

typedef struct _dhcpPacket
{
	in_Header   in;	
	udp_Header	udp;
	dhcpMessage data;
}dhcpPacket;

enum {
    OPTION_IP=1,
    OPTION_IP_PAIR,
    OPTION_STRING,
    OPTION_BOOLEAN,
    OPTION_U8,
    OPTION_U16,
    OPTION_S16,
    OPTION_U32,
    OPTION_S32
};

struct dhcp_option 
{
    char name[10];
    char flags;
    unsigned char code;
};

typedef struct _autodetectPacket
{
	/* ((MonitorMajorRev & 0xFF) << 16) + ((MonitorMinorRev & 0xFF) << 8) + 
	 * (TelogyMonitorRev & 0xFF) 
	 * (2nd Byte, 1st Byte and 0th Byte) */
	UINT32 version; 
	int type; /* REQUEST = 1, RESPONSE = 2 */
	UINT32 data;
	UINT32 reserved;
} autodetectPacket;

enum
{
	TYPE_REQUEST = 1,
	TYPE_RESPONSE
};

enum
{
	CRASH_NONE = 0,
	CRASH_KERNEL,
	CRASH_FS
};

/* *************************** Function Prototypes ************************** */
extern void reboot(void);

/* sed.c */
/* Ethernet interface:
 *   sed_WaitPacket(0) => ptr to packet (beyond eth header)
 *                          or NIL if no packet ready.
 *   sed_Receive(ptr) - reenables receive on input buffer
 *   sed_FormatPacket(&ethdest, ethtype) => ptr to packet buffer
 *   sed_Send(packet_length) - send the buffer last formatted.
 */
int sed_Init(int diag);
byte *sed_IsPacket(void), 
*sed_FormatPacket();
int sed_Send(int), sed_CheckPacket();
void sed_shutdown(void);
int demac(void);

/* arp.c */
int sar_CheckPacket(arp_Header *ap);
int sar_MapIn2Eth(longword ina, eth_HwAddress *ethap);
void sar_initTable(void);
int sar_addEntry(in_HwAddress ip, eth_HwAddress	eth);
int sar_deleteEntry(in_HwAddress ip);
int sar_FindEntry(in_HwAddress ip, eth_HwAddress *eth);

int checksum(void *dp, int length);
void Move( void *src, void *dest, int numbytes );

/* tinyip.c */
int ip_init(void);
int ip_deinit(void);
int ip_Handler(void);
void leds_init(void);
void toggle_leds(int bitFlag);
#if defined(AR7DB) || defined(AR7RD) || defined(AR7WRD)
void red_led(void);	//By Charles addition For compile 08-13-2004 
void green_led(void);	//By Charles addition For compile 08-13-2004
#endif


/* tinytcp.c */
int tcp_Init(void);
void tcp_Open(tcp_Socket *s, word lport, in_HwAddress ina, word port, procref datahandler);
void tcp_Listen(tcp_Socket *s, word port, procref datahandler, int timeout);
void tcp_Close(tcp_Socket *s);
void tcp_Abort(tcp_Socket *s);
void tcp_Retransmitter(void);
void tcp_Unthread(tcp_Socket *ds);
#ifndef DHCP_SUPPORT
int tcp(procref application);
#else
int tcp_receive(procref application);
#endif
int tcp_Write(tcp_Socket *s, byte *dp, int len);
void tcp_Flush(tcp_Socket *s);
void tcp_Handler(in_Header *ip);
void tcp_ProcessData(tcp_Socket *s, tcp_Header *tp, int len);
void tcp_Send(tcp_Socket *s);

/* tinyudp.c */
int udplib_init(in_HwAddress my_ip);
int udplib_deinit(void);
int udplib_open(word srcport, word dstport, procref application);
int udplib_close(void);
int udp_open(udp_Socket *s, word srcport, longword ina, word dstport, procref dataHandler, procref application);
int udp_close(udp_Socket *ds);
int udp_receive(unsigned int *ipaddress, void *data, int len, int Client);
void udp_Handler(in_Header *ip);
void udp_dataHandler (udp_Socket *s, byte *dp, int len, void *ph, void *up);
int udp_send(unsigned int ipaddr, int len, void * data);
int udp_write(udp_Socket *s, byte *datap, int len, word offset);

/* tinyftp.c */
#ifdef FTP_CLIENT_SUPPORT
void ftp_ctlHandler(tcp_Socket *s, byte *dp, int len, int state);
void ftp_commandLine(void);
void ftp_Abort(void);
void ftp_application(void);
void ftp(in_HwAddress host, in_HwAddress myip, char *user, char *pass, char *cwd, char *fn, procref dataHandler);
void GotData(tcp_Socket *s, byte *dp, int len, int state);
void getpass(char *str,char *rpass,int len);
int encrypt(char *inp,char *outp);
int decrypt(char *inp,char *outp);
int newpass(void);
#endif /* FTP_CLIENT_SUPPORT */
#ifdef FTP_SERVER_SUPPORT
int FTPServer(void);
int adam2Autodetect(void);
#endif

/* tinyicmp.c */
void icmp_Handler(in_Header *ip);
void icmp_Reply (struct _pkt *p, longword src, longword dest, int icmp_length);
int send_ping(longword host, longword count, longword size);

/* tinydhcp.c */
int dhcpclient(void);

/* options.c */
int add_simple_option(unsigned char *optionptr, unsigned char code, UINT32 data);
int add_option_string(unsigned char *optionptr, unsigned char *string);
unsigned char *get_option(dhcpMessage *packet, int code);
void add_requests(dhcpMessage *packet);

#endif /* _TINYIP_H_ */
