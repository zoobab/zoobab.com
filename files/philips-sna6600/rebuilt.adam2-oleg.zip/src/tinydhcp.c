/*-----------------------------------------------------------------------------*/
/*                                                                             */
/*   Copyright (C) 2002-2003 by Texas Instruments, Inc.  All rights reserved.  */
/*   Copyright (C) 2002-2003 Telogy Networks, Inc.							   */
/*                                                                             */
/*   NOTE: THIS VERSION OF CODE IS MAINTAINED BY TELOGY NETWORKS AND NOT TI!   */
/*                                                                             */
/*     IMPORTANT - READ CAREFULLY BEFORE PROCEEDING TO USE SOFTWARE.           */
/*                                                                             */
/*  This document is displayed for you to read prior to using the software     */
/*  and documentation.  By using the software and documentation, or opening    */
/*  the sealed packet containing the software, or proceeding to download the   */
/*  software from a Bulletin Board System(BBS) or a WEB Server, you agree to   */
/*  abide by the following Texas Instruments License Agreement. If you choose  */
/*  not to agree with these provisions, promptly discontinue use of the        */
/*  software and documentation and return the material to the place you        */
/*  obtained it.                                                               */
/*                                                                             */
/*                               *** NOTE ***                                  */
/*                                                                             */
/*  The licensed materials contain MIPS Technologies, Inc. confidential        */
/*  information which is protected by the appropriate MIPS Technologies, Inc.  */
/*  license agreement.  It is your responsibility to comply with these         */
/*  licenses.                                                                  */
/*                                                                             */
/*                   Texas Instruments License Agreement                       */
/*                                                                             */
/*  1. License - Texas Instruments (hereinafter "TI"), grants you a license    */
/*  to use the software program and documentation in this package ("Licensed   */
/*  Materials") for Texas Instruments broadband products.                      */
/*                                                                             */
/*  2. Restrictions - You may not reverse-assemble or reverse-compile the      */
/*  Licensed Materials provided in object code or executable format.  You may  */
/*  not sublicense, transfer, assign, rent, or lease the Licensed Materials    */
/*  or this Agreement without written permission from TI.                      */
/*                                                                             */
/*  3. Copyright - The Licensed Materials are copyrighted. Accordingly, you    */
/*  may either make one copy of the Licensed Materials for backup and/or       */
/*  archival purposes or copy the Licensed Materials to another medium and     */
/*  keep the original Licensed Materials for backup and/or archival purposes.  */
/*                                                                             */
/*  4. Runtime and Applications Software - You may create modified or          */
/*  derivative programs of software identified as Runtime Libraries or         */
/*  Applications Software, which, in source code form, remain subject to this  */
/*  Agreement, but object code versions of such derivative programs are not    */
/*  subject to this Agreement.                                                 */
/*                                                                             */
/*  5. Warranty - TI warrants the media to be free from defects in material    */
/*  and workmanship and that the software will substantially conform to the    */
/*  related documentation for a period of ninety (90) days after the date of   */
/*  your purchase. TI does not warrant that the Licensed Materials will be     */
/*  free from error or will meet your specific requirements.                   */
/*                                                                             */
/*  6. Remedies - If you find defects in the media or that the software does   */
/*  not conform to the enclosed documentation, you may return the Licensed     */
/*  Materials along with the purchase receipt, postage prepaid, to the         */
/*  following address within the warranty period and receive a refund.         */
/*                                                                             */
/*  TEXAS INSTRUMENTS                                                          */
/*  Application Specific Products, MS 8650                                     */
/*  c/o ADAM2 Application Manager                                              */
/*  12500 TI Boulevard                                                         */
/*  Dallas, TX 75243  - U.S.A.                                                 */
/*                                                                             */
/*  7. Limitations - TI makes no warranty or condition, either expressed or    */
/*  implied, including, but not limited to, any implied warranties of          */
/*  merchantability and fitness for a particular purpose, regarding the        */
/*  licensed materials.                                                        */
/*                                                                             */
/*  Neither TI nor any applicable licensor will be liable for any indirect,    */
/*  incidental or consequential damages, including but not limited to loss of  */
/*  profits.                                                                   */
/*                                                                             */
/*  8. Term - The license is effective until terminated.   You may terminate   */
/*  it at any other time by destroying the program together with all copies,   */
/*  modifications and merged portions in any form. It also will terminate if   */
/*  you fail to comply with any term or condition of this Agreement.           */
/*                                                                             */
/*  9. Export Control - The re-export of United States origin software and     */
/*  documentation is subject to the U.S. Export Administration Regulations or  */
/*  your equivalent local regulations. Compliance with such regulations is     */
/*  your responsibility.                                                       */
/*                                                                             */
/*                         *** IMPORTANT NOTICE ***                            */
/*                                                                             */
/*  Texas Instruments (TI) reserves the right to make changes to or to         */
/*  discontinue any semiconductor product or service identified in this        */
/*  publication without notice. TI advises its customers to obtain the latest  */
/*  version of the relevant information to verify, before placing orders,      */
/*  that the information being relied upon is current.                         */
/*                                                                             */
/*  TI warrants performance of its semiconductor products and related          */
/*  software to current specifications in accordance with TI's standard        */
/*  warranty. Testing and other quality control techniques are utilized to     */
/*  the extent TI deems necessary to support this warranty. Unless mandated    */
/*  by government requirements, specific testing of all parameters of each     */
/*  device is not necessarily performed.                                       */
/*                                                                             */
/*  Please be aware that Texas Instruments products are not intended for use   */
/*  in life-support appliances, devices, or systems. Use of a TI product in    */
/*  such applications without the written approval of the appropriate TI       */
/*  officer is prohibited. Certain applications using semiconductor devices    */
/*  may involve potential risks of injury, property damage, or loss of life.   */
/*  In order to minimize these risks, adequate design and operating            */
/*  safeguards should be provided by the customer to minimize inherent or      */
/*  procedural hazards. Inclusion of TI products in such applications is       */
/*  understood to be fully at the risk of the customer using TI devices or     */
/*  systems.                                                                   */
/*                                                                             */
/*  TI assumes no liability for TI applications assistance, customer product   */
/*  design, software performance, or infringement of patents or services       */
/*  described herein. Nor does TI warrant or represent that license, either    */
/*  expressed or implied, is granted under any patent right, copyright, mask   */
/*  work right, or other intellectual property right of TI covering or         */
/*  relating to any combination, machine, or process in which such             */
/*  semiconductor products or services might be or are used.                   */
/*                                                                             */
/*  All company and/or product names are trademarks and/or registered          */
/*  trademarks of their respective manaufacturers.                             */
/*                                                                             */
/*-----------------------------------------------------------------------------*/

#include "tinyip.h"
#include "env.h"
#include "main.h"

#define DHCP_TIMEOUT			5
#define INIT					1
#define REQUEST					2
#define BOUND					3
#define RENEW					4
#define DHCP_RETRANSMISSIONS 	2

static int rand_xid;
static int s_xid;

static unsigned long server_addr;
static unsigned long router_addr;
static unsigned long subnet_addr;
static unsigned long requested_ip;

unsigned long random_xid(void);
void send_discover(void);
void send_selecting(void);
void send_renew(void);

int dhcpclient(void)
{
	static int state;
	static unsigned long lease;
	dhcpMessage rxpacket;
	unsigned char *temp, *message;
	char cp[20];
	unsigned long dhcp_timeout, ticks;
	int ret, ack_received = 0;
	int packetnums, dhcpflag;
	unsigned int rcv_ipaddress;

	sin_lclINAddr = 0;
	sys_unsetenv("my_ipaddress");
	sys_unsetenv("gateway");
	sys_unsetenv("ipmask");
	
	if (!udplib_init(sin_lclINAddr)) {
		/*sys_printf("udplib_init: failed\n");*/
		return 0;
	}

	if (!udplib_open(CLIENT_PORT, SERVER_PORT, NULL))	{
		/*sys_printf("udplib_open: failed\n");*/
		return 0;
	}

	ticks = 0;
	state = INIT;
	packetnums = 0;
	dhcpflag = 1;
	s_xid = rand_xid = 0;

	server_addr = requested_ip = 0x0;
	router_addr = subnet_addr = 0x0;

	while (dhcpflag)
	{
		t_clear();
		dhcp_timeout = t_get() + ticks;
		
		ret = udp_receive(&rcv_ipaddress, &rxpacket, sizeof(dhcpMessage), TRUE);
   	
		while ( (ret == 0) && (t_get() < dhcp_timeout) ) {
			ret = udp_receive(&rcv_ipaddress, &rxpacket, sizeof(dhcpMessage), TRUE);
		}

		if (ret == 0) {
			switch (state)
			{
				case INIT :
					if (packetnums < DHCP_RETRANSMISSIONS) {
						send_discover();
						ticks = GetTicks(DHCP_TIMEOUT);
						packetnums++;
					}
					else
						dhcpflag = 0;
					break;
				
				case REQUEST :
					if (packetnums < DHCP_RETRANSMISSIONS) {
						send_selecting();
						ticks = GetTicks(DHCP_TIMEOUT);
						packetnums++;
					}
					else
						dhcpflag = 0;
					break;

			#ifdef DHCP_RENEW
				case BOUND :
					state = RENEW;
					ticks = GetTicks((DHCP_TIMEOUT - 4));
					break;

				case RENEW :
				{
					unsigned long templease;
					templease = GetSecs(ticks);	
					if (templease < lease)
					{
						send_renew();
						ticks = GetTicks(lease);
					}
					else
					{
						/*sys_printf("Lease lost, entering init state.\n");*/
						requested_ip = 0;
						state = INIT;
						ticks = GetTicks((DHCP_TIMEOUT - 4));
					}
				}
				break;
			#endif /* DHCP_RENEW */
			}
		}
		else
		{
			if (lfix(rxpacket.xid) != rand_xid) {
				/*sys_printf("Error: Received different XID.\n");*/
				continue;			
			}

			if ((message = get_option(&rxpacket, DHCP_MESSAGE_TYPE)) == NULL) {
				/*sys_printf("Error: couldn't get option from packet.\n");*/
				continue;
			}
			switch (state)
			{
				case INIT :
					if (*message == DHCPOFFER) {
						if ((temp = get_option(&rxpacket, DHCP_SERVER_ID)) != NULL) {
							sys_memcpy(&server_addr, temp, 4);
							server_addr = lfix(server_addr);
							s_xid = lfix(rxpacket.xid);
							requested_ip = lfix(rxpacket.yiaddr);
							sys_printf("Received DHCPOFFER...\n");
						   	sys_printf("Server ID: %d.%d.%d.%d\n", 
								((server_addr>>24) & 0xff), ((server_addr>>16) & 0xff), 
								((server_addr>>8) & 0xff), (server_addr & 0xff));
   							sys_printf("Offered IP: %d.%d.%d.%d\n", 
								((requested_ip>>24) & 0xff), ((requested_ip>>16) & 0xff), 
								((requested_ip>>8) & 0xff), (requested_ip & 0xff));
							
							ticks = GetTicks((DHCP_TIMEOUT - 4));
							state = REQUEST;
							packetnums = 0;
						}
						else
							sys_printf("Error: No Server ID in message.\n");
					}									
					break;
				
				case REQUEST :
			#ifdef DHCP_RENEW
				case RENEW :
			#endif
					if (*message == DHCPACK) {
						sys_printf("Received DHCP ACK\n");

						if ((temp = get_option(&rxpacket, DHCP_LEASE_TIME)) == NULL) {
							/*sys_printf("No Lease time with ACK, using 1 hour lease \n");*/
							lease = 60 * 60;
						}
						else
						{
							sys_memcpy(&lease, temp, 4);
							lease = lfix(lease);
						}
						requested_ip = lfix(rxpacket.yiaddr);						
						sys_printf("Lease of %d.%d.%d.%d obtained, lease time %d.\n",
							((requested_ip>>24) & 0xff), ((requested_ip>>16) & 0xff), 
							((requested_ip>>8) & 0xff), (requested_ip & 0xff), lease);
					
						if ((temp = get_option(&rxpacket, DHCP_ROUTER)) != NULL) {
							sys_memcpy(&router_addr, temp, 4);
							router_addr = lfix(router_addr);
						}
						if ((temp = get_option(&rxpacket, DHCP_SUBNET)) != NULL) {
							sys_memcpy(&subnet_addr, temp, 4);
							subnet_addr = lfix(subnet_addr);
						}
					#ifdef DHCP_RENEW
						packetnums = 0;
						state = BOUND;
						ticks = GetTicks((lease/2)); /* Renew time */
					#else						
						/* We just need the address, 
						 * no need to take care of renew/release.
						 * So set this flag to 0 to exit from this while loop. */
						dhcpflag = 0;
						ack_received = 1;
					#endif
					}	
					else if (*message == DHCPNAK)
					{
						sys_printf("Received DHCP NAK\n");
						requested_ip = 0;
						packetnums = 0;
						state = INIT;
						ticks = GetTicks((DHCP_TIMEOUT - 4));
					}
					break;		
			}
		}			
	}

	if (ack_received) {
		if (requested_ip != 0) {
			sin_lclINAddr = requested_ip;
			sys_memset(cp, 0, sizeof(cp));
			sys_sprintf(cp, "%d.%d.%d.%d", ((requested_ip>>24) & 0xff), 
				((requested_ip>>16) & 0xff), ((requested_ip>>8) & 0xff), 
				(requested_ip & 0xff));
			sys_setenv("my_ipaddress", cp);
		}

		if (router_addr != 0) {
			net_Gateway = router_addr;
			sys_memset(cp, 0, sizeof(cp));
			sys_sprintf(cp, "%d.%d.%d.%d", ((router_addr>>24) & 0xff), 
				((router_addr>>16) & 0xff), ((router_addr>>8) & 0xff), 
				(router_addr & 0xff));
			sys_setenv("gateway", cp);
		}

		if (router_addr != 0) {
			net_IpMask = subnet_addr;
			sys_memset(cp, 0, sizeof(cp));
			sys_sprintf(cp, "%d.%d.%d.%d", ((subnet_addr>>24) & 0xff), 
				((subnet_addr>>16) & 0xff), ((subnet_addr>>8) & 0xff), 
				(subnet_addr & 0xff));
			sys_setenv("ipmask", cp);
		}
	}
		
	if (!udplib_deinit()) {
		/*sys_printf("udplib_deinit: failed\n");*/
		return 0;
	}
	
	return 1;
}

void init_header(dhcpMessage *packet, char type)
{
	sys_memset(packet, 0, sizeof(dhcpMessage));
	switch (type) 
	{
		case DHCPDISCOVER:
		case DHCPREQUEST:
		case DHCPRELEASE:
		case DHCPINFORM:
			packet->op = BOOTREQUEST;
			break;
		case DHCPOFFER:
		case DHCPACK:
		case DHCPNAK:
			packet->op = BOOTREPLY;
	}
	packet->htype = ETH_10MB;
	packet->hlen = ETH_10MB_LEN;
	packet->cookie = lfix(DHCP_MAGIC);
	packet->options[0] = DHCP_END;
	add_simple_option(packet->options, DHCP_MESSAGE_TYPE, type);
}

/* initialize a packet with the proper defaults */
void init_packet(dhcpMessage *packet, char type)
{
	static unsigned char clientid[10];
	static unsigned char hostnameoption[256];
	char *hostname = NULL;

	struct vendor  
	{
		char vendor, length;
		char str[sizeof("dhcp 0.0")];
	} vendor_id = { DHCP_VENDOR,  sizeof("dhcp 0.0") - 1, "dhcp 0.0"};
	
	init_header(packet, type);
	
	sys_memcpy(packet->chaddr, sed_lclEthAddr, 6);
	clientid[OPT_CODE] = DHCP_CLIENT_ID;
	clientid[OPT_LEN] = 7;
	clientid[OPT_DATA] = 1;
	sys_memcpy(clientid + 3, sed_lclEthAddr, 6);
	
	add_option_string(packet->options, clientid);
	
	hostname = sys_getenv("hostname");
	if (hostname == NULL)
		hostname = ProductIDStr;
	hostnameoption[OPT_CODE] = DHCP_HOST_NAME;
	hostnameoption[OPT_LEN] = strlen(hostname);
	sys_memcpy((hostnameoption + 2), hostname, strlen(hostname));
	add_option_string(packet->options, hostnameoption);

	add_option_string(packet->options, (unsigned char *) &vendor_id);
}

/* Broadcast a DHCP discover packet to the network, with an optionally requested IP */
void send_discover(void)
{
    dhcpMessage packet;

    init_packet(&packet, DHCPDISCOVER);
    packet.xid = lfix(random_xid());

    add_requests(&packet);
    sys_printf("Sending DISCOVER...\n");

	udp_send(INADDR_BROADCAST, sizeof(dhcpMessage), &packet);
}
	
void send_selecting(void)
{
	dhcpMessage packet;

	init_packet(&packet, DHCPREQUEST);
	packet.xid = lfix(s_xid);

	add_simple_option(packet.options, DHCP_REQUESTED_IP, lfix(requested_ip));
	add_simple_option(packet.options, DHCP_SERVER_ID, lfix(server_addr));

	add_requests(&packet);

	sys_printf("Sending DHCP REQUEST...\n");
	udp_send(INADDR_BROADCAST, sizeof(dhcpMessage), &packet);
}

#ifdef DHCP_RENEW
void send_renew(void)
{
	dhcpMessage packet;

	init_packet(&packet, DHCPREQUEST);
	packet.xid = lfix(s_xid);
	packet.ciaddr = lfix(requested_ip);

	add_requests(&packet);

	/*sys_printf("Sending renew...\n");	*/
	udp_send(server_addr, sizeof(dhcpMessage), &packet);
}
#endif

/* Create a random xid */
unsigned long random_xid(void)
{
    rand_xid++;
    return rand_xid;
}

