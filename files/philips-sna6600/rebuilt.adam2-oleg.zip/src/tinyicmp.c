/*-----------------------------------------------------------------------------*/
/*                                                                             */
/*   Copyright (C) 2002-2003 by Texas Instruments, Inc.  All rights reserved.  */
/*   Copyright (C) 2002-2003 Telogy Networks, Inc.							   */
/*                                                                             */
/*   NOTE: THIS VERSION OF CODE IS MAINTAINED BY TELOGY NETWORKS AND NOT TI!   */
/*                                                                             */
/*     IMPORTANT - READ CAREFULLY BEFORE PROCEEDING TO USE SOFTWARE.           */
/*                                                                             */
/*  This document is displayed for you to read prior to using the software     */
/*  and documentation.  By using the software and documentation, or opening    */
/*  the sealed packet containing the software, or proceeding to download the   */
/*  software from a Bulletin Board System(BBS) or a WEB Server, you agree to   */
/*  abide by the following Texas Instruments License Agreement. If you choose  */
/*  not to agree with these provisions, promptly discontinue use of the        */
/*  software and documentation and return the material to the place you        */
/*  obtained it.                                                               */
/*                                                                             */
/*                               *** NOTE ***                                  */
/*                                                                             */
/*  The licensed materials contain MIPS Technologies, Inc. confidential        */
/*  information which is protected by the appropriate MIPS Technologies, Inc.  */
/*  license agreement.  It is your responsibility to comply with these         */
/*  licenses.                                                                  */
/*                                                                             */
/*                   Texas Instruments License Agreement                       */
/*                                                                             */
/*  1. License - Texas Instruments (hereinafter "TI"), grants you a license    */
/*  to use the software program and documentation in this package ("Licensed   */
/*  Materials") for Texas Instruments broadband products.                      */
/*                                                                             */
/*  2. Restrictions - You may not reverse-assemble or reverse-compile the      */
/*  Licensed Materials provided in object code or executable format.  You may  */
/*  not sublicense, transfer, assign, rent, or lease the Licensed Materials    */
/*  or this Agreement without written permission from TI.                      */
/*                                                                             */
/*  3. Copyright - The Licensed Materials are copyrighted. Accordingly, you    */
/*  may either make one copy of the Licensed Materials for backup and/or       */
/*  archival purposes or copy the Licensed Materials to another medium and     */
/*  keep the original Licensed Materials for backup and/or archival purposes.  */
/*                                                                             */
/*  4. Runtime and Applications Software - You may create modified or          */
/*  derivative programs of software identified as Runtime Libraries or         */
/*  Applications Software, which, in source code form, remain subject to this  */
/*  Agreement, but object code versions of such derivative programs are not    */
/*  subject to this Agreement.                                                 */
/*                                                                             */
/*  5. Warranty - TI warrants the media to be free from defects in material    */
/*  and workmanship and that the software will substantially conform to the    */
/*  related documentation for a period of ninety (90) days after the date of   */
/*  your purchase. TI does not warrant that the Licensed Materials will be     */
/*  free from error or will meet your specific requirements.                   */
/*                                                                             */
/*  6. Remedies - If you find defects in the media or that the software does   */
/*  not conform to the enclosed documentation, you may return the Licensed     */
/*  Materials along with the purchase receipt, postage prepaid, to the         */
/*  following address within the warranty period and receive a refund.         */
/*                                                                             */
/*  TEXAS INSTRUMENTS                                                          */
/*  Application Specific Products, MS 8650                                     */
/*  c/o ADAM2 Application Manager                                              */
/*  12500 TI Boulevard                                                         */
/*  Dallas, TX 75243  - U.S.A.                                                 */
/*                                                                             */
/*  7. Limitations - TI makes no warranty or condition, either expressed or    */
/*  implied, including, but not limited to, any implied warranties of          */
/*  merchantability and fitness for a particular purpose, regarding the        */
/*  licensed materials.                                                        */
/*                                                                             */
/*  Neither TI nor any applicable licensor will be liable for any indirect,    */
/*  incidental or consequential damages, including but not limited to loss of  */
/*  profits.                                                                   */
/*                                                                             */
/*  8. Term - The license is effective until terminated.   You may terminate   */
/*  it at any other time by destroying the program together with all copies,   */
/*  modifications and merged portions in any form. It also will terminate if   */
/*  you fail to comply with any term or condition of this Agreement.           */
/*                                                                             */
/*  9. Export Control - The re-export of United States origin software and     */
/*  documentation is subject to the U.S. Export Administration Regulations or  */
/*  your equivalent local regulations. Compliance with such regulations is     */
/*  your responsibility.                                                       */
/*                                                                             */
/*                         *** IMPORTANT NOTICE ***                            */
/*                                                                             */
/*  Texas Instruments (TI) reserves the right to make changes to or to         */
/*  discontinue any semiconductor product or service identified in this        */
/*  publication without notice. TI advises its customers to obtain the latest  */
/*  version of the relevant information to verify, before placing orders,      */
/*  that the information being relied upon is current.                         */
/*                                                                             */
/*  TI warrants performance of its semiconductor products and related          */
/*  software to current specifications in accordance with TI's standard        */
/*  warranty. Testing and other quality control techniques are utilized to     */
/*  the extent TI deems necessary to support this warranty. Unless mandated    */
/*  by government requirements, specific testing of all parameters of each     */
/*  device is not necessarily performed.                                       */
/*                                                                             */
/*  Please be aware that Texas Instruments products are not intended for use   */
/*  in life-support appliances, devices, or systems. Use of a TI product in    */
/*  such applications without the written approval of the appropriate TI       */
/*  officer is prohibited. Certain applications using semiconductor devices    */
/*  may involve potential risks of injury, property damage, or loss of life.   */
/*  In order to minimize these risks, adequate design and operating            */
/*  safeguards should be provided by the customer to minimize inherent or      */
/*  procedural hazards. Inclusion of TI products in such applications is       */
/*  understood to be fully at the risk of the customer using TI devices or     */
/*  systems.                                                                   */
/*                                                                             */
/*  TI assumes no liability for TI applications assistance, customer product   */
/*  design, software performance, or infringement of patents or services       */
/*  described herein. Nor does TI warrant or represent that license, either    */
/*  expressed or implied, is granted under any patent right, copyright, mask   */
/*  work right, or other intellectual property right of TI covering or         */
/*  relating to any combination, machine, or process in which such             */
/*  semiconductor products or services might be or are used.                   */
/*                                                                             */
/*  All company and/or product names are trademarks and/or registered          */
/*  trademarks of their respective manaufacturers.                             */
/*                                                                             */
/*-----------------------------------------------------------------------------*/

#include "tinyip.h"

/* constants */
#define ICMP_TIMEOUT		2
#define PING_DELAY			1

static struct _pkt rxpkt;

/* IP identification numbers */
static word icmp_id = 0;

static longword ping_tcache_start = 0;	/* start time in ticks */
static longword ping_tcache_end = 0;	/* end time in ticks */
static longword ping_tcache = 0;		/* time in usecs */
static longword ping_number = 0;

/* icmp_Reply - format a reply packet
 *		      - note that src and dest are NETWORK order not host!!!!*/
void icmp_Reply (struct _pkt *p, longword src, longword dest, int icmp_length)
{
    struct icmp_echo *newicmp;
	in_Header *newip;

    newip = &(p->in);
    sys_memset(newip, 0, sizeof(in_Header));
    newicmp = &(p->icmp.echo);

	/* finish the icmp checksum portion */
	newicmp->checksum = 0;
	newicmp->checksum = wfix(~checksum(newicmp, icmp_length));

	/* encapsulate into a nice ip packet */
	newip->vht = wfix(0x4500); /* Version 4, hdrlen = 5 tos 0 */
	newip->length = wfix(sizeof(in_Header) + icmp_length);
	newip->identification = wfix(icmp_id);
	newip->ttlProtocol = wfix((250<<8) + ICMP_PROTO);
	newip->checksum = 0;
	newip->source = lfix(src);
	newip->destination = lfix(dest);
	newip->checksum = wfix(~checksum(newip, sizeof(in_Header)));

	icmp_id++;
	sed_Send(wfix(newip->length));
}

/* Handler for incoming packets. */
void icmp_Handler(in_Header *ip)
{
	icmp_pkt *icmp, *newicmp;
	struct _pkt *pkt;
	int len, code;
	in_Header *ret;
	eth_HwAddress dest;
	char sip_address[16];
	longword ipaddr;

	sys_memset(&rxpkt, 0, sizeof(struct _pkt));
	
	len = in_GetHdrlenBytes(ip);
	Move(ip, &rxpkt, (len + ip->length));
	
	icmp = (icmp_pkt*)(&(rxpkt.icmp));
	len = wfix(rxpkt.in.length) - len;
	if (checksum(icmp, len) != 0xffff ) 
	{
		return;
	}

	code = icmp->unused.code;
	ret = & (icmp->ip.ip);

	switch (icmp->unused.type) 
	{
		case 0 : 
			/* icmp echo reply received */
			ping_tcache_end = t_get() - ping_tcache_start;
			ping_tcache = GetUSecs(ping_tcache_end);
			ping_number = wfix(icmp->echo.identifier);
			ipaddr = lfix(rxpkt.in.source);
			sys_sprintf(sip_address, "%d.%d.%d.%d", ((ipaddr>>24) & 0xff), ((ipaddr>>16) & 0xff), ((ipaddr>>8) & 0xff), (ipaddr & 0xff));
			sys_printf("Reply from %s: icmp_seq=%d time=%d microsecs.\n", sip_address, ping_number, ping_tcache);
			ping_tcache_end = ping_tcache_start = 0;
			break;

		case 8  : 
			/* icmp echo request */
	        /* don't reply if the request was made by ourselves */
            if (rxpkt.in.source == lfix(sin_lclINAddr))
            	return;

			if (rxpkt.in.destination != lfix(sin_lclINAddr))
				return;

		    /* do arp and create packet */
  			if ( !sar_MapIn2Eth(lfix(rxpkt.in.source), &dest)) 
			{
				return;
			}
			
			/* format the packet with the request's hardware address */
            pkt = (struct _pkt *)sed_FormatPacket(dest, 0x800);

			newicmp = &(pkt->icmp);

			MoveW(icmp, newicmp, len);
			
			newicmp->echo.type = 0;
			newicmp->echo.code = code;

			/* use supplied ip values in case we ever multi-home */
			/* note that ip values are still in network order */
			icmp_Reply(pkt, lfix(rxpkt.in.destination), lfix(rxpkt.in.source), len);
			break;

#if 0			
		case 3 : 
			/* destination unreachable message */
		case 4  : 
			/* source quench */
		case 5  : 
			/* redirect */
			break;			
		case 11 :
		   	/* time exceeded message */
		case 12 : 
			/* parameter problem message */
		case 13 : 
			/* timestamp message */
			/* send reply */
		case 14 : 
			/* timestamp reply */
			/* should store */
		case 15 : 
			/* info request */
			/* send reply */
		case 16 : 
			/* info reply */
			break;
#endif
    }
}

int send_ping(longword host, longword count, longword size)
{
	eth_HwAddress dest;
	struct _pkt *p;
	in_Header *ip;
	struct icmp_echo *icmp;
	longword total_length, icmp_timeout, ping_delay;
	byte *buf;
	byte ch;
	int i, ret;

	if ((host & 0xff) == 0xff) {
		sys_printf("Cannot ping a network!\n");
		return -1;
	}
    
  	if ( !sar_MapIn2Eth(host, &dest)) 
	{
		sys_printf("Cannot resolve the ARP\n");
		return -1;
	}
	
	if (size >= icmp_MaxBufSize)
	{
		sys_printf("Size is more than allowed size, defaulting to %d\n", icmp_MaxBufSize);
		size = icmp_MaxBufSize;
	}

	icmp_id = 0;
	do
	{
    	p = (struct _pkt *)sed_FormatPacket(dest, 0x800);

		ip = &p->in;
		sys_memset(ip, 0, sizeof(in_Header));
		icmp = &p->icmp.echo;

		icmp->type = 8;
		icmp->code = 0;
		icmp->identifier = wfix(icmp_id);
		
		buf = &p->data[0];

		for (i = 0, ch = 'a'; i < size; i++, ch++)
		{
			*buf++ = ch;
			if (ch == 'z')
				ch = 'a';
		}	
 
		total_length = sizeof(struct icmp_echo) + size;
	
		/* finish the icmp checksum portion */
		icmp->checksum = 0;
		icmp->checksum = wfix(~checksum(icmp, total_length));

		/* encapsulate into a nice ip packet */
		ip->vht = wfix(0x4500); /* Version 4, hdrlen = 5 tos 0 */
		ip->length = wfix(sizeof(in_Header) + total_length);
		ip->identification = wfix(icmp_id);
		ip->ttlProtocol = wfix((250<<8) + ICMP_PROTO);
		ip->checksum = 0;
		ip->source = lfix(sin_lclINAddr);
		ip->destination = lfix(host);
		ip->checksum = wfix(~checksum(ip, sizeof(in_Header)));

		sed_Send(wfix(ip->length));

		t_clear();
		ping_tcache_start = t_get();
		icmp_timeout = ping_tcache_start + GetTicks(ICMP_TIMEOUT);

		ret = ip_Handler();
		while (( ret == 0) && t_get() < icmp_timeout)
		{
			ret = ip_Handler();
		}

		if (ret == 0)
			sys_printf("icmp_seq=%d: Request timedout.\n", icmp_id);

		t_clear();
		ping_delay = t_get() + GetTicks(PING_DELAY);
		while (t_get() < ping_delay);

		count--;
		icmp_id++;
	}
	while (count);

	icmp_id = 0;

	return(count);
}

