/*------------------------------------------------------------------------------*/
/*                                                                             	*/
/*   Copyright (C) 1999-2003 by Texas Instruments, Inc.  All rights reserved.  	*/
/*   Copyright (C) 2001-2003 Telogy Networks.	    						   	*/
/*                                                                              */
/*   NOTE: THIS VERSION OF CODE IS MAINTAINED BY TELOGY NETWORKS AND NOT TI!    */
/*                                                                             	*/
/*     IMPORTANT - READ CAREFULLY BEFORE PROCEEDING TO USE SOFTWARE.           	*/
/*                                                                             	*/
/*  This document is displayed for you to read prior to using the software     	*/
/*  and documentation.  By using the software and documentation, or opening    	*/
/*  the sealed packet containing the software, or proceeding to download the   	*/
/*  software from a Bulletin Board System(BBS) or a WEB Server, you agree to   	*/
/*  abide by the following Texas Instruments License Agreement. If you choose  	*/
/*  not to agree with these provisions, promptly discontinue use of the        	*/
/*  software and documentation and return the material to the place you        	*/
/*  obtained it.                                                               	*/
/*                                                                             	*/
/*                               *** NOTE ***                                  	*/
/*                                                                             	*/
/*  The licensed materials contain MIPS Technologies, Inc. confidential        	*/
/*  information which is protected by the appropriate MIPS Technologies, Inc.  	*/
/*  license agreement.  It is your responsibility to comply with these         	*/
/*  licenses.                                                                  	*/
/*                                                                             	*/
/*                   Texas Instruments License Agreement                       	*/
/*                                                                             	*/
/*  1. License - Texas Instruments (hereinafter "TI"), grants you a license    	*/
/*  to use the software program and documentation in this package ("Licensed   	*/
/*  Materials") for Texas Instruments broadband products.                      	*/
/*                                                                             	*/
/*  2. Restrictions - You may not reverse-assemble or reverse-compile the      	*/
/*  Licensed Materials provided in object code or executable format.  You may  	*/
/*  not sublicense, transfer, assign, rent, or lease the Licensed Materials    	*/
/*  or this Agreement without written permission from TI.                      	*/
/*                                                                             	*/
/*  3. Copyright - The Licensed Materials are copyrighted. Accordingly, you    	*/
/*  may either make one copy of the Licensed Materials for backup and/or       	*/
/*  archival purposes or copy the Licensed Materials to another medium and     	*/
/*  keep the original Licensed Materials for backup and/or archival purposes.  	*/
/*                                                                             	*/
/*  4. Runtime and Applications Software - You may create modified or          	*/
/*  derivative programs of software identified as Runtime Libraries or         	*/
/*  Applications Software, which, in source code form, remain subject to this  	*/
/*  Agreement, but object code versions of such derivative programs are not    	*/
/*  subject to this Agreement.                                                 	*/
/*                                                                             	*/
/*  5. Warranty - TI warrants the media to be free from defects in material    	*/
/*  and workmanship and that the software will substantially conform to the    	*/
/*  related documentation for a period of ninety (90) days after the date of   	*/
/*  your purchase. TI does not warrant that the Licensed Materials will be     	*/
/*  free from error or will meet your specific requirements.                   	*/
/*                                                                             	*/
/*  6. Remedies - If you find defects in the media or that the software does   	*/
/*  not conform to the enclosed documentation, you may return the Licensed     	*/
/*  Materials along with the purchase receipt, postage prepaid, to the         	*/
/*  following address within the warranty period and receive a refund.         	*/
/*                                                                             	*/
/*  TEXAS INSTRUMENTS                                                          	*/
/*  Application Specific Products, MS 8650                                     	*/
/*  c/o ADAM2 Application Manager                                              	*/
/*  12500 TI Boulevard                                                         	*/
/*  Dallas, TX 75243  - U.S.A.                                                 	*/
/*                                                                             	*/
/*  7. Limitations - TI makes no warranty or condition, either expressed or    	*/
/*  implied, including, but not limited to, any implied warranties of          	*/
/*  merchantability and fitness for a particular purpose, regarding the        	*/
/*  licensed materials.                                                        	*/
/*                                                                             	*/
/*  Neither TI nor any applicable licensor will be liable for any indirect,    	*/
/*  incidental or consequential damages, including but not limited to loss of  	*/
/*  profits.                                                                   	*/
/*                                                                             	*/
/*  8. Term - The license is effective until terminated.   You may terminate   	*/
/*  it at any other time by destroying the program together with all copies,   	*/
/*  modifications and merged portions in any form. It also will terminate if   	*/
/*  you fail to comply with any term or condition of this Agreement.           	*/
/*                                                                             	*/
/*  9. Export Control - The re-export of United States origin software and     	*/
/*  documentation is subject to the U.S. Export Administration Regulations or  	*/
/*  your equivalent local regulations. Compliance with such regulations is     	*/
/*  your responsibility.                                                       	*/
/*                                                                             	*/
/*                         *** IMPORTANT NOTICE ***                            	*/
/*                                                                             	*/
/*  Texas Instruments (TI) reserves the right to make changes to or to         	*/
/*  discontinue any semiconductor product or service identified in this        	*/
/*  publication without notice. TI advises its customers to obtain the latest  	*/
/*  version of the relevant information to verify, before placing orders,      	*/
/*  that the information being relied upon is current.                         	*/
/*                                                                             	*/
/*  TI warrants performance of its semiconductor products and related          	*/
/*  software to current specifications in accordance with TI's standard        	*/
/*  warranty. Testing and other quality control techniques are utilized to     	*/
/*  the extent TI deems necessary to support this warranty. Unless mandated    	*/
/*  by government requirements, specific testing of all parameters of each     	*/
/*  device is not necessarily performed.                                       	*/
/*                                                                             	*/
/*  Please be aware that Texas Instruments products are not intended for use   	*/
/*  in life-support appliances, devices, or systems. Use of a TI product in    	*/
/*  such applications without the written approval of the appropriate TI       	*/
/*  officer is prohibited. Certain applications using semiconductor devices    	*/
/*  may involve potential risks of injury, property damage, or loss of life.   	*/
/*  In order to minimize these risks, adequate design and operating            	*/
/*  safeguards should be provided by the customer to minimize inherent or      	*/
/*  procedural hazards. Inclusion of TI products in such applications is       	*/
/*  understood to be fully at the risk of the customer using TI devices or     	*/
/*  systems.                                                                   	*/
/*                                                                             	*/
/*  TI assumes no liability for TI applications assistance, customer product   	*/
/*  design, software performance, or infringement of patents or services       	*/
/*  described herein. Nor does TI warrant or represent that license, either    	*/
/*  expressed or implied, is granted under any patent right, copyright, mask   	*/
/*  work right, or other intellectual property right of TI covering or         	*/
/*  relating to any combination, machine, or process in which such             	*/
/*  semiconductor products or services might be or are used.                   	*/
/*                                                                             	*/
/*  All company and/or product names are trademarks and/or registered          	*/
/*  trademarks of their respective manaufacturers.                             	*/
/*------------------------------------------------------------------------------*/

#include "emacphy.h"

void _EmacMdioWaitForAccessComplete(int macbase);
#if 0
void _EmacMdioDumpState(int macbase, int state);
void _EmacMdioDumpPhy(int macbase,int p);
#endif
void _EmacMdioResetPhy(int macbase,int PhyNum);
void _EmacMdioDisablePhy(int macbase,int PhyNum);
void _EmacMdioPhyTimeOut(int macbase,int *PhyState);

#define MDIO_GO    	0x80000000
#define MDIO_WRITE 	0x40000000
#define MDIO_ACK 	0x20000000
#define MDIO_READ  	0x00000000

#define	PHY_LED_REG			0x14

/*PhyState breakout*/
#define PHY_DEV_OFFSET      (0)
#define PHY_DEV_SIZE        (5)
#define PHY_DEV_MASK        (0x1f<<PHY_DEV_OFFSET)

#define PHY_STATE_OFFSET    (PHY_DEV_SIZE+PHY_DEV_OFFSET)
#define PHY_STATE_SIZE      (5)
#define PHY_STATE_MASK      (0x1f<<PHY_STATE_OFFSET)
  #define INIT       (1<<PHY_STATE_OFFSET)
  #define FINDING    (2<<PHY_STATE_OFFSET)
  #define FOUND      (3<<PHY_STATE_OFFSET)
  #define NWAY_START (4<<PHY_STATE_OFFSET)
  #define NWAY_WAIT  (5<<PHY_STATE_OFFSET)
  #define LINK_WAIT  (6<<PHY_STATE_OFFSET)
  #define LINKED     (7<<PHY_STATE_OFFSET)

#define PHY_SPEED_OFFSET    (PHY_STATE_OFFSET+PHY_STATE_SIZE)
#define PHY_SPEED_SIZE      (1)
#define PHY_SPEED_MASK      (1<<PHY_SPEED_OFFSET)

#define PHY_DUPLEX_OFFSET   (PHY_SPEED_OFFSET+PHY_SPEED_SIZE)
#define PHY_DUPLEX_SIZE     (1)
#define PHY_DUPLEX_MASK     (1<<PHY_DUPLEX_OFFSET)

#define PHY_TIM_OFFSET      (PHY_DUPLEX_OFFSET+PHY_DUPLEX_SIZE)
#define PHY_TIM_SIZE        (10)
#define PHY_TIM_MASK        (0x3ff<<PHY_TIM_OFFSET)
  #define PHY_FIND_TO (  2<<PHY_TIM_OFFSET)
  #define PHY_RECK_TO (200<<PHY_TIM_OFFSET)
  #define PHY_LINK_TO (500<<PHY_TIM_OFFSET)
  #define PHY_NWST_TO (500<<PHY_TIM_OFFSET)
  #define PHY_NWDN_TO (800<<PHY_TIM_OFFSET)

#define PHY_SMODE_OFFSET    (PHY_TIM_OFFSET+PHY_TIM_SIZE)
#define PHY_SMODE_SIZE      (5)
#define PHY_SMODE_MASK      (0x1f<<PHY_SMODE_OFFSET)
  #define SMODE_LOOP   (0x40<<PHY_SMODE_OFFSET)
  #define SMODE_AUTO   (0x10<<PHY_SMODE_OFFSET)
  #define SMODE_FD100  (0x08<<PHY_SMODE_OFFSET)
  #define SMODE_HD100  (0x04<<PHY_SMODE_OFFSET)
  #define SMODE_FD10   (0x02<<PHY_SMODE_OFFSET)
  #define SMODE_HD10   (0x01<<PHY_SMODE_OFFSET)
  #define SMODE_ALL    (0x1f<<PHY_SMODE_OFFSET)

#define PHY_CHNG_OFFSET    (PHY_SMODE_OFFSET+PHY_SMODE_SIZE)
#define PHY_CHNG_SIZE      (1)
#define PHY_CHNG_MASK      (1<<PHY_CHNG_OFFSET)
#define PHY_CHANGE (1<<PHY_CHNG_OFFSET)

#ifdef WA100
#define MARVELL_EMAC_PHY 	1
#endif

#if 0
static char *lstate[]={"NULL","INIT","FINDING","FOUND","NWAY_START","NWAY_WAIT","LINK_WAIT","LINKED"};

void _EmacMdioDumpState(int macbase, int state)
  {
  sys_printf("Phy: %d, ",(state&PHY_DEV_MASK)>>PHY_DEV_OFFSET);
  sys_printf("State: %d/%s, ",(state&PHY_STATE_MASK)>>PHY_STATE_OFFSET,lstate[(state&PHY_STATE_MASK)>>PHY_STATE_OFFSET]);
  sys_printf("Speed: %d, ",(state&PHY_SPEED_MASK)>>PHY_SPEED_OFFSET);
  sys_printf("Dup: %d, ",(state&PHY_DUPLEX_MASK)>>PHY_DUPLEX_OFFSET);
  sys_printf("Tim: %d, ",(state&PHY_TIM_MASK)>>PHY_TIM_OFFSET);
  sys_printf("SMode: %x, ",(state&PHY_SMODE_MASK)>>PHY_SMODE_OFFSET);
  sys_printf("Chng: %d",(state&PHY_CHNG_MASK)>>PHY_CHNG_OFFSET);
  sys_printf("\n");
  if (((state&PHY_STATE_MASK)!=FINDING)&&((state&PHY_STATE_MASK)!=INIT))  
    _EmacMdioDumpPhy(macbase,(state&PHY_DEV_MASK)>>PHY_DEV_OFFSET);
  }

void _EmacMdioDumpPhy(int macbase,int p)
  {
  int i,j,m,n,PhyAcks;

  PhyAcks=MDIOACK;
  for(i=0,j=1;i<32;i++,j<<=1)
    {
    if (PhyAcks&j)
      {
      sys_printf("%2d%s:",i,(i==p)?">":" ");
      for(m=0;m<6;m++)
        {
        MDIOUSERACCESS=MDIO_GO|MDIO_READ|(m<<21)|(i<<16);
        _EmacMdioWaitForAccessComplete(macbase);
        n=MDIOUSERACCESS;
        sys_printf(" %04x",n&0x0ffff);
        }
      sys_printf("\n");
      }
    }
  }
#endif

void _EmacMdioResetPhy(int macbase,int PhyNum)
  {

  MDIOUSERACCESS = MDIO_GO|MDIO_WRITE|(PHY_CONTROL_REG<<21)|(PhyNum<<16)|PHY_RESET; 
  _EmacMdioWaitForAccessComplete(macbase);
#ifdef ACPEP 
  		MDIOUSERACCESS = MDIO_GO|MDIO_WRITE|(PHY_LED_REG<<21)|(PhyNum<<16)|0X2132;
  		_EmacMdioWaitForAccessComplete(macbase);
#endif
  }

void _EmacMdioDisablePhy(int macbase,int PhyNum)
  {

  MDIOUSERACCESS = MDIO_GO|MDIO_WRITE|(PHY_CONTROL_REG<<21)|(PhyNum<<16)|PHY_ISOLATE|PHY_PDOWN; 
  _EmacMdioWaitForAccessComplete(macbase);
  }

void _EmacInitState(int macbase,int *PhyState)
{
	int CurrentState;
	CurrentState=*PhyState;
	CurrentState=(CurrentState&~PHY_TIM_MASK)|(PHY_FIND_TO);
	CurrentState=(CurrentState&~PHY_STATE_MASK)|(FINDING);
	CurrentState=(CurrentState&~PHY_SPEED_MASK);
	CurrentState=(CurrentState&~PHY_DUPLEX_MASK);
	CurrentState|=PHY_CHANGE;
	*PhyState=CurrentState;
}

void _EmacFindingState(int macbase,int *PhyState)
{
#ifndef WA100
	int PhyNum,i,j,PhyAcks;

	PhyNum=-1;
	if (*PhyState&PHY_TIM_MASK)
    {
    	*PhyState=(*PhyState&~PHY_TIM_MASK)|((*PhyState&PHY_TIM_MASK)-(1<<PHY_TIM_OFFSET));
    }
	else
	{
    	PhyAcks=MDIOACK;
	    for(i=0,j=1;(i<32)&&((j&PhyAcks)==0);i++,j<<=1);
    	if ((PhyAcks)&&(i<32))
		{
#ifdef AR5W01
			if (i == 1)			
				PhyNum=i;
			else
				PhyNum=i+1;
#else
			PhyNum=i;
#endif
		}
	    if (PhyNum==-1)
    	{
			*PhyState|=PHY_RECK_TO;
		}
	    else
    	{
			*PhyState=(*PhyState&~PHY_DEV_MASK)|((PhyNum&PHY_DEV_MASK)<<PHY_DEV_OFFSET);
			*PhyState=(*PhyState&~PHY_STATE_MASK)|(FOUND);
			*PhyState|=PHY_CHANGE;
	    }
    }
#else
      *PhyState=(*PhyState&~PHY_STATE_MASK)|(FOUND);
      *PhyState|=PHY_CHANGE;
#endif
}

void _EmacFoundState(int macbase,int *PhyState)
{
	int PhyNum,PhyStatus,NWAYadvertise,m,i,j,PhyAcks;

  	if ((*PhyState&PHY_SMODE_MASK)==0) return;
	PhyNum=(*PhyState&PHY_DEV_MASK)>>PHY_DEV_OFFSET;

#ifndef WA100

  	PhyAcks=MDIOACK;
	for(i=0,j=1;i<32;i++,j<<=1)
    {
		if (PhyAcks&j)
      	{
			if (i==PhyNum)
		        _EmacMdioResetPhy(macbase,i);
			else
				_EmacMdioDisablePhy(macbase,i);
		}
    }
#endif

	MDIOUSERACCESS=MDIO_GO|MDIO_READ|(PHY_STATUS_REG<<21)|(PhyNum<<16);
	_EmacMdioWaitForAccessComplete(macbase);
	PhyStatus=MDIOUSERACCESS;


	NWAYadvertise=NWAY_SEL;
	if (*PhyState&SMODE_FD100) NWAYadvertise|=NWAY_FD100;
	if (*PhyState&SMODE_HD100) NWAYadvertise|=NWAY_HD100;
	if (*PhyState&SMODE_FD10)  NWAYadvertise|=NWAY_FD10;
	if (*PhyState&SMODE_HD10)  NWAYadvertise|=NWAY_HD10;
	if (*PhyState&SMODE_LOOP)   NWAYadvertise|=PHY_LOOP;

	*PhyState&=~(PHY_TIM_MASK|PHY_STATE_MASK);
	if ((PhyStatus&NWAY_CAPABLE)&&(*PhyState&SMODE_AUTO))   /*NWAY Phy Detected*/
    {
    /*For NWAY compliant Phys                                                */

	    MDIOUSERACCESS=MDIO_GO|MDIO_WRITE|(PHY_CONTROL_REG<<21)|(PhyNum<<16)|AUTO_NEGOTIATE_EN;
    	_EmacMdioWaitForAccessComplete(macbase);

	    MDIOUSERACCESS=MDIO_GO|MDIO_WRITE|(NWAY_ADVERTIZE_REG<<21)|(PhyNum<<16)|NWAYadvertise;

    	_EmacMdioWaitForAccessComplete(macbase);
	    MDIOUSERACCESS=MDIO_GO|MDIO_WRITE|(PHY_CONTROL_REG<<21)|(PhyNum<<16)|AUTO_NEGOTIATE_EN|RENEGOTIATE;
    	_EmacMdioWaitForAccessComplete(macbase);

	    *PhyState|=PHY_CHANGE|PHY_NWST_TO|NWAY_START;
    }
	else
    {
    	*PhyState&=~SMODE_AUTO;   /*The Phy is not capable of auto negotiation!  */
	    m=NWAYadvertise;
		/*
    	for(j=0x8000,i=0;(i<16)&&((j&m)==0);i++,j>>=1);
	    m=j;
		*/
	    j=0;
    	if (m&(NWAY_FD100|NWAY_HD100)) 
	    {
	    	j=PHY_100; 
			/*m&=(NWAY_FD100|NWAY_HD100);*/
		}
		if (m&(NWAY_FD100|NWAY_FD10))  
			j|=PHY_FD;
		if (m&PHY_LOOP)  
			j|=PHY_LOOP;
		MDIOUSERACCESS=MDIO_GO|MDIO_WRITE|(PHY_CONTROL_REG<<21)|(PhyNum<<16)|j; /*Phy Speed and Duplex*/
		*PhyState&=~PHY_SPEED_MASK;
		if (j&PHY_100)
			*PhyState|=(1<<PHY_SPEED_OFFSET);
    	*PhyState&=~PHY_DUPLEX_MASK;
	    if (j&PHY_FD)
    	  *PhyState|=(1<<PHY_DUPLEX_OFFSET);
	    *PhyState|=PHY_CHANGE|PHY_LINK_TO|LINK_WAIT;
    	_EmacMdioWaitForAccessComplete(macbase);
	}
#ifdef ACPEP
  		MDIOUSERACCESS = MDIO_GO|MDIO_WRITE|(PHY_LED_REG<<21)|(PhyNum<<16)|0x2132;
  		_EmacMdioWaitForAccessComplete(macbase);
#endif

}

void _EmacNwayStartState(int macbase,int *PhyState)
  {
  int PhyNum,PhyMode;

  PhyNum=(*PhyState&PHY_DEV_MASK)>>PHY_DEV_OFFSET;
#ifdef ACPEP 
  		MDIOUSERACCESS = MDIO_GO|MDIO_WRITE|(PHY_LED_REG<<21)|(PhyNum<<16)|0x2132;
  		_EmacMdioWaitForAccessComplete(macbase);
#endif

  /*Wait for Negotiation to start                                            */

  MDIOUSERACCESS=MDIO_GO|MDIO_READ|(PHY_CONTROL_REG<<21)|(PhyNum<<16);
  _EmacMdioWaitForAccessComplete(macbase);
  PhyMode=MDIOUSERACCESS;
  if((PhyMode&RENEGOTIATE)==0)
    {
    MDIOUSERACCESS=MDIO_GO|MDIO_READ|(PHY_STATUS_REG<<21)|(PhyNum<<16); /*Flush pending latch bits*/
    *PhyState&=~(PHY_STATE_MASK|PHY_TIM_MASK);
    *PhyState|=PHY_CHANGE|NWAY_WAIT|PHY_NWDN_TO;
    _EmacMdioWaitForAccessComplete(macbase);
    }
   else
    {  
    if (*PhyState&PHY_TIM_MASK)
      *PhyState=(*PhyState&~PHY_TIM_MASK)|((*PhyState&PHY_TIM_MASK)-(1<<PHY_TIM_OFFSET));
     else
      _EmacMdioPhyTimeOut(macbase, PhyState);
    }
  }

void _EmacNwayWaitState(int macbase,int *PhyState)
  {
  int PhyNum,PhyStatus,NWAYadvertise,NegMode,i,j;

  PhyNum=(*PhyState&PHY_DEV_MASK)>>PHY_DEV_OFFSET;

  MDIOUSERACCESS=MDIO_GO|MDIO_READ|(PHY_STATUS_REG<<21)|(PhyNum<<16);
  _EmacMdioWaitForAccessComplete(macbase);
  PhyStatus=MDIOUSERACCESS;
  if (PhyStatus&NWAY_COMPLETE)
    {      
    *PhyState|=PHY_CHANGE;
    *PhyState&=~PHY_SPEED_MASK;
    *PhyState&=~PHY_DUPLEX_MASK;
    MDIOUSERACCESS=MDIO_GO|MDIO_READ|(NWAY_ADVERTIZE_REG<<21)|(PhyNum<<16);
    _EmacMdioWaitForAccessComplete(macbase);
    NWAYadvertise=MDIOUSERACCESS;
    MDIOUSERACCESS=MDIO_GO|MDIO_READ|(NWAY_REMADVERTISE_REG<<21)|(PhyNum<<16);
    _EmacMdioWaitForAccessComplete(macbase);
    NegMode=MDIOUSERACCESS&NWAYadvertise;
    NegMode&=(NWAY_FD100|NWAY_HD100|NWAY_FD10|NWAY_HD10);
    if (NegMode==0)
      {
      NegMode=(NWAY_HD100|NWAY_HD10)&NWAYadvertise; /*or 10 ?? who knows, Phy is not MII compliant*/
      }
    for(j=0x8000,i=0;(i<16)&&((j&NegMode)==0);i++,j>>=1);
    NegMode=j;
    if (NegMode!=0)
      {
      if (PhyStatus&PHY_LINKED)
        *PhyState=(*PhyState&~PHY_STATE_MASK)|LINKED;
       else
        *PhyState=(*PhyState&~PHY_STATE_MASK)|LINK_WAIT;
      if (NegMode&(NWAY_FD100|NWAY_HD100))
        *PhyState=(*PhyState&~PHY_SPEED_MASK)|(1<<PHY_SPEED_OFFSET);
      if (NegMode&(NWAY_FD100|NWAY_FD10))
        *PhyState=(*PhyState&~PHY_DUPLEX_MASK)|(1<<PHY_DUPLEX_OFFSET);
      }
    }
   else
    {
    if (*PhyState&PHY_TIM_MASK)
      *PhyState=(*PhyState&~PHY_TIM_MASK)|((*PhyState&PHY_TIM_MASK)-(1<<PHY_TIM_OFFSET));
     else
      _EmacMdioPhyTimeOut(macbase, PhyState);
    }
  }

void _EmacLinkWaitState(int macbase,int *PhyState)
  {
  int PhyStatus;
  int PhyNum;

  PhyNum=(*PhyState&PHY_DEV_MASK)>>PHY_DEV_OFFSET;
#ifdef ACPEP 
  		MDIOUSERACCESS = MDIO_GO|MDIO_WRITE|(PHY_LED_REG<<21)|(PhyNum<<16)|0x2132;
  		_EmacMdioWaitForAccessComplete(macbase);
#endif

  MDIOUSERACCESS=MDIO_GO|MDIO_READ|(PHY_STATUS_REG<<21)|(PhyNum<<16);
  _EmacMdioWaitForAccessComplete(macbase);
  PhyStatus=MDIOUSERACCESS;
  if (PhyStatus&PHY_LINKED)
    {
    *PhyState=(*PhyState&~PHY_STATE_MASK)|LINKED;
    *PhyState|=PHY_CHANGE;
    }
   else
    {
    if (*PhyState&PHY_TIM_MASK)
      *PhyState=(*PhyState&~PHY_TIM_MASK)|((*PhyState&PHY_TIM_MASK)-(1<<PHY_TIM_OFFSET));
     else
      _EmacMdioPhyTimeOut(macbase, PhyState);
    }
  }

void _EmacMdioPhyTimeOut(int macbase,int *PhyState)
  {
  /*Things you may want to do if we cannot establish link, like look for another Phy*/
  /* and try it.                                                             */
  }

void _EmacLinkedState(int macbase,int *PhyState)
  {
  int PhyNum;

  PhyNum=(*PhyState&PHY_DEV_MASK)>>PHY_DEV_OFFSET;
  if (MDIOLINK&(1<<PhyNum)) return;
  *PhyState&=~(PHY_STATE_MASK|PHY_TIM_MASK);
  *PhyState|=PHY_CHANGE|NWAY_WAIT|PHY_NWDN_TO;
  }

void _EmacDefaultState(int macbase,int *PhyState)
  {
  /*Awaiting a EmacMdioInit call                                             */
  *PhyState|=PHY_CHANGE;
  }

void _EmacMdioWaitForAccessComplete(int macbase)
  {
  while((MDIOUSERACCESS&MDIO_GO)!=0)
    {
    }
  }

/*User Calles*********************************************************       */

void EmacMdioInit(int macbase, int *PhyState, int cpufreq)
  {

  /*Setup MII MDIO access regs                                               */

  MDIOCONTROL    = 0x40008000|(cpufreq/1000000);  /* Enable MDIO            */
  *PhyState=INIT;

#ifdef WA100
  *PhyState |= ((MARVELL_EMAC_PHY & PHY_DEV_MASK) << PHY_DEV_OFFSET);
#endif

  /*_EmacMdioDumpState(macbase,*PhyState);	*/
  }

void EmacMdioSetPhyMode(int macbase,int *PhyState,int PhyMode)
  {
  int CurrentState;

  *PhyState&=~PHY_SMODE_MASK;
  if (PhyMode&PHY_LOOP) *PhyState|=SMODE_LOOP;
  if (PhyMode&NWAY_AUTO)  *PhyState|=SMODE_AUTO;
  if (PhyMode&NWAY_FD100) *PhyState|=SMODE_FD100;
  if (PhyMode&NWAY_HD100) *PhyState|=SMODE_HD100;
  if (PhyMode&NWAY_FD10) *PhyState|=SMODE_FD10;
  if (PhyMode&NWAY_HD10) *PhyState|=SMODE_HD10;
  CurrentState=*PhyState&PHY_STATE_MASK;
  if ((CurrentState==NWAY_START)||
      (CurrentState==NWAY_WAIT) ||
      (CurrentState==LINK_WAIT) ||
      (CurrentState==LINKED)      )
    *PhyState=(*PhyState&~PHY_STATE_MASK)|FOUND|PHY_CHANGE;
  /*_EmacMdioDumpState(macbase,*PhyState);*/
  }

/* EmacMdioTic is called every 10 mili seconds to process Phy states         */

int EmacMdioTic(int macbase,int *PhyState)
  {
  int CurrentState;

  /*Act on current state of the Phy                                          */

  CurrentState=*PhyState;
  switch(CurrentState&PHY_STATE_MASK)
    {
    case INIT:       _EmacInitState(macbase,PhyState);      break;
    case FINDING:    _EmacFindingState(macbase,PhyState);   break;
    case FOUND:      _EmacFoundState(macbase,PhyState);     break;
    case NWAY_START: _EmacNwayStartState(macbase,PhyState); break;
    case NWAY_WAIT:  _EmacNwayWaitState(macbase,PhyState);  break;
    case LINK_WAIT:  _EmacLinkWaitState(macbase,PhyState);  break;
    case LINKED:     _EmacLinkedState(macbase,PhyState);    break;
    default:         _EmacDefaultState(macbase,PhyState);   break;
    }

  /*Dump state info if a change has been detected                            */
#if 0
  if ((CurrentState&~PHY_TIM_MASK)!=(*PhyState&~PHY_TIM_MASK))
    _EmacMdioDumpState(macbase,*PhyState);
#endif

  /*Return state change to user                                              */

  if (*PhyState&PHY_CHNG_MASK)
    {
    *PhyState&=~PHY_CHNG_MASK;
    return(TRUE);
    }
   else
    return(FALSE);
  }

/* EmacMdioGetDuplex is called to retreive the Duplex info                   */

int EmacMdioGetDuplex(int macbase,int *PhyState)
  {
  return(*PhyState&PHY_DUPLEX_MASK);
  }

/* EmacMdioGetSpeed is called to retreive the Speed info                     */

int EmacMdioGetSpeed(int macbase,int *PhyState)
  {
  return(*PhyState&PHY_SPEED_MASK);
  }

/* EmacMdioGetPhyNum is called to retreive the Phy Device Adr info           */

int EmacMdioGetPhyNum(int macbase,int *PhyState)
  {
  return((*PhyState&PHY_DEV_MASK)>>PHY_DEV_OFFSET);
  }

/* EmacMdioGetLinked is called to Determine if the LINKED state has been reached*/

int EmacMdioGetLinked(int macbase,int *PhyState)
  {
  return((*PhyState&PHY_STATE_MASK)==LINKED);
  }

void EmacMdioLinkChange(int macbase,int *PhyState)
  {
  int PhyNum,PhyStatus;

  PhyNum=(*PhyState&PHY_DEV_MASK)>>PHY_DEV_OFFSET;

  if (EmacMdioGetLinked(macbase,PhyState))
    {
    MDIOUSERACCESS=MDIO_GO|MDIO_READ|(PHY_STATUS_REG<<21)|(PhyNum<<16);
    _EmacMdioWaitForAccessComplete(macbase);
    PhyStatus=MDIOUSERACCESS;
    if ((PhyStatus&PHY_LINKED)==0)
      {
      *PhyState&=~(PHY_TIM_MASK|PHY_STATE_MASK);
      if (*PhyState&SMODE_AUTO)
        {
        MDIOUSERACCESS=MDIO_GO|MDIO_WRITE|(PHY_CONTROL_REG<<21)|(PhyNum<<16)|AUTO_NEGOTIATE_EN|RENEGOTIATE;
        _EmacMdioWaitForAccessComplete(macbase);

        *PhyState|=PHY_CHANGE|PHY_NWST_TO|NWAY_START;
        }
       else
        {
        *PhyState|=PHY_CHANGE|PHY_LINK_TO|LINK_WAIT;
        }
      }
    }
  }
