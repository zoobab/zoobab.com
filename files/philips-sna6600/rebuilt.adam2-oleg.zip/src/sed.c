/*-----------------------------------------------------------------------------*/
/*                                                                             */
/*   Copyright (C) 1996-2003 by Texas Instruments, Inc.  All rights reserved.  */
/*   Copyright (C) 2001-2003 Telogy Networks, Inc.							   */
/*                                                                             */
/*   NOTE: THIS VERSION OF CODE IS MAINTAINED BY TELOGY NETWORKS AND NOT TI!   */
/*                                                                             */
/*     IMPORTANT - READ CAREFULLY BEFORE PROCEEDING TO USE SOFTWARE.           */
/*                                                                             */
/*  This document is displayed for you to read prior to using the software     */
/*  and documentation.  By using the software and documentation, or opening    */
/*  the sealed packet containing the software, or proceeding to download the   */
/*  software from a Bulletin Board System(BBS) or a WEB Server, you agree to   */
/*  abide by the following Texas Instruments License Agreement. If you choose  */
/*  not to agree with these provisions, promptly discontinue use of the        */
/*  software and documentation and return the material to the place you        */
/*  obtained it.                                                               */
/*                                                                             */
/*                               *** NOTE ***                                  */
/*                                                                             */
/*  The licensed materials contain MIPS Technologies, Inc. confidential        */
/*  information which is protected by the appropriate MIPS Technologies, Inc.  */
/*  license agreement.  It is your responsibility to comply with these         */
/*  licenses.                                                                  */
/*                                                                             */
/*                   Texas Instruments License Agreement                       */
/*                                                                             */
/*  1. License - Texas Instruments (hereinafter "TI"), grants you a license    */
/*  to use the software program and documentation in this package ("Licensed   */
/*  Materials") for Texas Instruments broadband products.                      */
/*                                                                             */
/*  2. Restrictions - You may not reverse-assemble or reverse-compile the      */
/*  Licensed Materials provided in object code or executable format.  You may  */
/*  not sublicense, transfer, assign, rent, or lease the Licensed Materials    */
/*  or this Agreement without written permission from TI.                      */
/*                                                                             */
/*  3. Copyright - The Licensed Materials are copyrighted. Accordingly, you    */
/*  may either make one copy of the Licensed Materials for backup and/or       */
/*  archival purposes or copy the Licensed Materials to another medium and     */
/*  keep the original Licensed Materials for backup and/or archival purposes.  */
/*                                                                             */
/*  4. Runtime and Applications Software - You may create modified or          */
/*  derivative programs of software identified as Runtime Libraries or         */
/*  Applications Software, which, in source code form, remain subject to this  */
/*  Agreement, but object code versions of such derivative programs are not    */
/*  subject to this Agreement.                                                 */
/*                                                                             */
/*  5. Warranty - TI warrants the media to be free from defects in material    */
/*  and workmanship and that the software will substantially conform to the    */
/*  related documentation for a period of ninety (90) days after the date of   */
/*  your purchase. TI does not warrant that the Licensed Materials will be     */
/*  free from error or will meet your specific requirements.                   */
/*                                                                             */
/*  6. Remedies - If you find defects in the media or that the software does   */
/*  not conform to the enclosed documentation, you may return the Licensed     */
/*  Materials along with the purchase receipt, postage prepaid, to the         */
/*  following address within the warranty period and receive a refund.         */
/*                                                                             */
/*  TEXAS INSTRUMENTS                                                          */
/*  Application Specific Products, MS 8650                                     */
/*  c/o ADAM2 Application Manager                                              */
/*  12500 TI Boulevard                                                         */
/*  Dallas, TX 75243  - U.S.A.                                                 */
/*                                                                             */
/*  7. Limitations - TI makes no warranty or condition, either expressed or    */
/*  implied, including, but not limited to, any implied warranties of          */
/*  merchantability and fitness for a particular purpose, regarding the        */
/*  licensed materials.                                                        */
/*                                                                             */
/*  Neither TI nor any applicable licensor will be liable for any indirect,    */
/*  incidental or consequential damages, including but not limited to loss of  */
/*  profits.                                                                   */
/*                                                                             */
/*  8. Term - The license is effective until terminated.   You may terminate   */
/*  it at any other time by destroying the program together with all copies,   */
/*  modifications and merged portions in any form. It also will terminate if   */
/*  you fail to comply with any term or condition of this Agreement.           */
/*                                                                             */
/*  9. Export Control - The re-export of United States origin software and     */
/*  documentation is subject to the U.S. Export Administration Regulations or  */
/*  your equivalent local regulations. Compliance with such regulations is     */
/*  your responsibility.                                                       */
/*                                                                             */
/*                         *** IMPORTANT NOTICE ***                            */
/*                                                                             */
/*  Texas Instruments (TI) reserves the right to make changes to or to         */
/*  discontinue any semiconductor product or service identified in this        */
/*  publication without notice. TI advises its customers to obtain the latest  */
/*  version of the relevant information to verify, before placing orders,      */
/*  that the information being relied upon is current.                         */
/*                                                                             */
/*  TI warrants performance of its semiconductor products and related          */
/*  software to current specifications in accordance with TI's standard        */
/*  warranty. Testing and other quality control techniques are utilized to     */
/*  the extent TI deems necessary to support this warranty. Unless mandated    */
/*  by government requirements, specific testing of all parameters of each     */
/*  device is not necessarily performed.                                       */
/*                                                                             */
/*  Please be aware that Texas Instruments products are not intended for use   */
/*  in life-support appliances, devices, or systems. Use of a TI product in    */
/*  such applications without the written approval of the appropriate TI       */
/*  officer is prohibited. Certain applications using semiconductor devices    */
/*  may involve potential risks of injury, property damage, or loss of life.   */
/*  In order to minimize these risks, adequate design and operating            */
/*  safeguards should be provided by the customer to minimize inherent or      */
/*  procedural hazards. Inclusion of TI products in such applications is       */
/*  understood to be fully at the risk of the customer using TI devices or     */
/*  systems.                                                                   */
/*                                                                             */
/*  TI assumes no liability for TI applications assistance, customer product   */
/*  design, software performance, or infringement of patents or services       */
/*  described herein. Nor does TI warrant or represent that license, either    */
/*  expressed or implied, is granted under any patent right, copyright, mask   */
/*  work right, or other intellectual property right of TI covering or         */
/*  relating to any combination, machine, or process in which such             */
/*  semiconductor products or services might be or are used.                   */
/*                                                                             */
/*  All company and/or product names are trademarks and/or registered          */
/*  trademarks of their respective manaufacturers.                             */
/*                                                                             */
/*-----------------------------------------------------------------------------*/
/* 																			   */
/* Ethernet Driver. 														   */
/* A Very Simple set of ethernet driver primitives.  The ethernet (3com Mbus)  */
/* interface is controlled by busy-waiting, the application is handed the      */
/* location of on-board packet buffers, and allowed to fill in the             */
/* transmit buffer directly.  The interface is entirely blocking.              */
/*  																		   */
/* Written March, 1986 by Geoffrey Cooper 									   */
/* 																			   */
/* Copyright (C) 1986, IMAGEN Corporation 									   */
/*  "This code may be duplicated in whole or in part provided that [1] there   */
/*   is no commercial gain involved in the duplication, and [2] that this      */
/*   copyright notice is preserved on all copies.  Any other duplication       */
/*   requires written notice of the author."                                   */
/*  																		   */
/* Primitives: 																   */
/*  sed_Init()  -- Initialize the package 									   */
/*  sed_FormatPacket( destEAddr ) => location of transmit buffer               */
/*  sed_Send( pkLength ) -- send the packet that is in the transmit buffer     */ 
/*  sed_Receive( recBufLocation ) -- enable receiving packets.                 */
/*  sed_IsPacket() => location of packet in receive buffer                     */
/*  sed_CheckPacket( recBufLocation, expectedType )                            */
/*  sed_shutdown(); 														   */
/* 																			   */
/* Global Variables: 														   */
/*  sed_lclEthAddr -- Ethernet address of this host. 						   */
/*  sed_ethBcastAddr -- Ethernet broadcast address.                            */    
/*-----------------------------------------------------------------------------*/

#include "_stdio.h"
#include "tinyip.h"
#include "emacphy.h"
#include "hw.h"
#include "env.h"
#include "support.h"

#define E10P_MIN        60              /* Minimum Ethernet packet size */

#define TCB_ENTRIES      16
#define RCB_ENTRIES      32
#define BUFFER_SIZE    1518
#define TX_COMP_ENTRIES  16
#define RX_COMP_ENTRIES  32

#define DISABLE     0x80000000
#define CLRP        0x20000000
#define TXPACE      0x00000100
#define NO_LOOP     0x08000000
#define FULL_DUPLEX 0x00000001
#define SPEED_100   0x00000002
#define CAF         0x00000400
#define CMF         0x00002000
#define PEFCE       0x00080000

#define DMACONFIG      	(*(volatile unsigned *)(emacbase+0x000))
#define INTSTS         	(*(volatile unsigned *)(emacbase+0x004))
#define INTMASK        	(*(volatile unsigned *)(emacbase+0x008))

#define WRAPCLK        	(*(volatile unsigned *)(emacbase+0x340))
#define STATSBASE      	(*(volatile unsigned *)(emacbase+0x400))
 
#define TCRPTR         	(*(volatile unsigned *)(emacbase+0x100))
#define TCRSIZE        	(*(volatile unsigned *)(emacbase+0x104))
#define TCRINTTHRESH   	(*(volatile unsigned *)(emacbase+0x108))
#define TCRTOTENT      	(*(volatile unsigned *)(emacbase+0x10C))
#define TCRFREEENT     	(*(volatile unsigned *)(emacbase+0x110))
#define TCRPENDENT     	(*(volatile unsigned *)(emacbase+0x114))
#define TCRENTINC      	(*(volatile unsigned *)(emacbase+0x118))
#define TXISRPACE      	(*(volatile unsigned *)(emacbase+0x11c))

#define TDMASTATE0     	(*(volatile unsigned *)(emacbase+0x120))
#define TDMASTATE1     	(*(volatile unsigned *)(emacbase+0x124))
#define TDMASTATE2     	(*(volatile unsigned *)(emacbase+0x128))
#define TDMASTATE3     	(*(volatile unsigned *)(emacbase+0x12C))
#define TDMASTATE4     	(*(volatile unsigned *)(emacbase+0x130))
#define TDMASTATE5     	(*(volatile unsigned *)(emacbase+0x134))
#define TDMASTATE6     	(*(volatile unsigned *)(emacbase+0x138))
#define TDMASTATE7     	(*(volatile unsigned *)(emacbase+0x13C))
#define TXPADDCNT      	(*(volatile unsigned *)(emacbase+0x140))
#define TXPADDSTART    	(*(volatile unsigned *)(emacbase+0x144))
#define TXPADDEND      	(*(volatile unsigned *)(emacbase+0x148))
#define TXQFLUSH       	(*(volatile unsigned *)(emacbase+0x14C))
 
#define RCRPTR         	(*(volatile unsigned *)(emacbase+0x200))
#define RCRSIZE        	(*(volatile unsigned *)(emacbase+0x204))
#define RCRINTTHRESH   	(*(volatile unsigned *)(emacbase+0x208))
#define RCRTOTENT      	(*(volatile unsigned *)(emacbase+0x20C))
#define RCRFREEENT     	(*(volatile unsigned *)(emacbase+0x210))
#define RCRPENDENT     	(*(volatile unsigned *)(emacbase+0x214))
#define RCRENTINC      	(*(volatile unsigned *)(emacbase+0x218))
#define RXISRPACE      	(*(volatile unsigned *)(emacbase+0x21c))
 
#define RDMASTATE0     	(*(volatile unsigned *)(emacbase+0x220))
#define RDMASTATE1     	(*(volatile unsigned *)(emacbase+0x224))
#define RDMASTATE2     	(*(volatile unsigned *)(emacbase+0x228))
#define RDMASTATE3     	(*(volatile unsigned *)(emacbase+0x22C))
#define RDMASTATE4     	(*(volatile unsigned *)(emacbase+0x230))
#define RDMASTATE5     	(*(volatile unsigned *)(emacbase+0x234))
#define RDMASTATE6     	(*(volatile unsigned *)(emacbase+0x238))
#define RDMASTATE7     	(*(volatile unsigned *)(emacbase+0x23C))
#define FBLADDCNT      	(*(volatile unsigned *)(emacbase+0x240))
#define FBLADDSTART    	(*(volatile unsigned *)(emacbase+0x244))
#define FBLADDEND      	(*(volatile unsigned *)(emacbase+0x248))
#define RXONOFF        	(*(volatile unsigned *)(emacbase+0x24C))
 
#define FBL0NEXTD      	(*(volatile unsigned *)(emacbase+0x280))
#define FBL0LASTD      	(*(volatile unsigned *)(emacbase+0x284))
#define FBL0COUNTD     	(*(volatile unsigned *)(emacbase+0x288))
#define FBL0BUFSIZE    	(*(volatile unsigned *)(emacbase+0x28C))
 
#define MACCONTROL     	(*(volatile unsigned *)(emacbase+0x300))
#define MACSTATUS      	(*(volatile unsigned *)(emacbase+0x304))
#define MACADDRHI      	(*(volatile unsigned *)(emacbase+0x308))
#define MACADDRLO      	(*(volatile unsigned *)(emacbase+0x30C))
#define MACHASH1       	(*(volatile unsigned *)(emacbase+0x310))
#define MACHASH2       	(*(volatile unsigned *)(emacbase+0x314))
 
#define WRAPCLK        	(*(volatile unsigned *)(emacbase+0x340))
#define BOFTEST        	(*(volatile unsigned *)(emacbase+0x344))
#define PACTEST        	(*(volatile unsigned *)(emacbase+0x348))
#define PAUSEOP        	(*(volatile unsigned *)(emacbase+0x34C))
 
#define MDIOCONTROL    	(*(volatile unsigned *)(emacbase+0x380))
#define MDIOUSERACCESS 	(*(volatile unsigned *)(emacbase+0x384))
#define MDIOACK        	(*(volatile unsigned *)(emacbase+0x388))
#define MDIOLINK       	(*(volatile unsigned *)(emacbase+0x38C))
#define MDIOMACPHY     	(*(volatile unsigned *)(emacbase+0x390))

#define SAVE1 	(*(volatile unsigned *)(0x9401f000))
#define SAVE2 	(*(volatile unsigned *)(0x9401f004))
#define SAVE3 	(*(volatile unsigned *)(0x9401f008))
#define SAVE4 	(*(volatile unsigned *)(0x9401f00c))
#define SAVE5 	(*(volatile unsigned *)(0x9401f010))
#define SAVE6 	(*(volatile unsigned *)(0x9401f014))
#define SAVE7 	(*(volatile unsigned *)(0x9401f018))
#define SAVE8 	(*(volatile unsigned *)(0x9401f01c))

#ifdef ACPEP 
#define	ACPEP_EPLD_RESET_CTRL_REG (*(volatile short *)(0x9C800004))
#define	ACPEP_EPLD_RESET_MIIA 0x0080
#define	ACPEP_EPLD_RESET_MIIB 0x0040
#endif	

#define en10pages        	((en10size) >> pageshift)
#define LINK_TIMEOUT		5
#define TEST_TIMEOUT 		120000

#define NORMAL				0
#define INTERNAL_LOOP 		1
#define EXTERNAL_LOOP 		2
#define WIRE_LOOP     		3

#define TX_BUF_COUNT     	25
#define FLIP_TBUF_INDEX  	0 	/*16 at which point it flips to SDRAM*/
#define MIN_FRAME_SIZE   	64
#define MAX_FRAME_SIZE 		1518
#define TX_BURST_COUNT   	11
#define SEQ              	16

bit32u emacbase;
bit32u PhyState;

int loops, steps;
int tx_frame_seq, rx_fram_seq, tx_buf_index;
volatile unsigned *tx_buf[TX_BUF_COUNT]; 

void *GetRxPacket(void);

struct txcompring_s
  {
  int status;
  int fblid_noofbufs;
  int sof_list;
  int eof_list;
  };

struct txcompring_s *TxCompPtr;
int TxCompRingMask;
int TxCompRingBase;
int txcompring_size;
int txcompring_index;

struct rxcompring_s
  {
  int status;
  int sof_list;
  int eof_list;
  int flen_errs;
  };

struct rxcompring_s *RxCompPtr;
int RxCompRingMask;
int RxCompRingBase;
int rxcompring_size;
int rxcompring_index;

struct rcb_s
  {
  int size;
  int BufPtr;
  int Res1;
  int Res2;
  int *DatPtr;
  int Res3;
  int Res4;
  int Res5;
  }rcb_array_i[RCB_ENTRIES];

struct rcb_s *rcb_array,*CurrentRcb;

volatile struct tcb_s
  {
  int mode;
  int BufPtr;
  int Res1;
  int DO_FBLID;
  void *RcbPtr;
  int Res3;
  int Res4;
  int Res5;
  }tcb_array_i[TCB_ENTRIES];

struct tcb_s *tcb_array;

int rcb_index, rcb_pending;
int tcb_index, tcb_pending;

octet *sed_va;                          /* virtual address of ethernet card */
BOOL sed_respondARPreq;                 /* controls responses to ARP req's */
char bufAinUse, bufBinUse;              /* tell whether bufs are in use */

/* 
 *  Initialize the Ethernet Interface, and this package.  Enable input on
 * both buffers.
 */
void InitRcb(int size)
  {
  int i;
  int *pTmp;

  rcb_index=0;
  rcb_pending = 0;
  rcb_array=(struct rcb_s *)UNCACHED(&rcb_array_i[0]);
  for(i=0;i<RCB_ENTRIES;i++)
    {
    pTmp=sys_malloc(size);
    if (!pTmp)
      sys_printf("Error: sys_malloc\n");
    rcb_array[i].size=0;
    rcb_array[i].BufPtr=PHYS(pTmp);
    rcb_array[i].Res1=0;
    rcb_array[i].Res2=0;
    rcb_array[i].DatPtr=(int *)UNCACHED(pTmp);
    }
  SAVE4=(int)rcb_array;
  }

void init_txcomp(int num)
  {
  int *pTmp,iTmp,i,j;

  /*Make num power of two*/

  num*=2;
  num--;
  for(i=0,j=0x80000000;i<32;i++,j>>=1)
    if (j&num) num&=j;
  txcompring_size=num;

  /*Allocate so that it is on a power of size alignment*/

  iTmp=num*16*2;
  pTmp=sys_malloc(iTmp);
  if (!pTmp) 
    sys_printf("Error: sys_malloc\n");
  iTmp=(int)UNCACHED(pTmp);
  iTmp+=((num*16)-1);
  iTmp&=~((num*16)-1);
  SAVE2=iTmp;
  pTmp=(int *)iTmp;
  TxCompPtr=(struct txcompring_s *)pTmp;
  for(i=0;i<num;i++)
    {
    *pTmp++=0;
    *pTmp++=0;
    *pTmp++=0;
    *pTmp++=0;
    }

  /* allocate Tx completion ring (num entries) */

  TCRPTR    = PHYS(TxCompPtr);      
  TCRSIZE   = num-1;
  TCRTOTENT = num;         
  TCRENTINC = num; 
  TxCompRingMask=(num-1)<<4;
  TxCompRingBase=(~(((num-1)<<4)|0xf))&((int)TxCompPtr);
  }

void init_rxcomp(int num)
  {
  int *pTmp,iTmp,i,j;

  /*Make num power of two*/

  num*=2;
  num--;
  for(i=0,j=0x80000000;i<32;i++,j>>=1)
    if (j&num) num&=j;
  rxcompring_size=num;

  /*Allocate so that it is on a power of size alignment*/

  iTmp=num*16*2;
  pTmp=sys_malloc(iTmp);
  if (!pTmp) 
    sys_printf("Error: sys_malloc\n");
  iTmp=(int)UNCACHED(pTmp);
  iTmp+=((num*16)-1);
  iTmp&=~((num*16)-1);
  SAVE3=iTmp;
  pTmp=(int *)iTmp;
  RxCompPtr=(struct rxcompring_s *)pTmp;
  for(i=0;i<num;i++)
    {
    *pTmp++=0;
    *pTmp++=0;
    *pTmp++=0;
    *pTmp++=0;
    }

  /* allocate Tx completion ring (num entries) */

  RCRPTR    = PHYS(RxCompPtr);      
  RCRSIZE   = num-1;
  RCRTOTENT = num;         
  RCRENTINC = num; 
  RxCompRingMask=(num-1)<<4;
  RxCompRingBase=(~(((num-1)<<4)|0xf))&((int)RxCompPtr);
  }

void RxFree(struct rcb_s *rcb)
  {

  rcb->Res1=0;
  rcb->Res2=0;
  rcb_pending++;
  while((FBLADDCNT&0x80000000)==0)
    {
    }

  FBLADDCNT = 1;  
  FBLADDSTART = PHYS(rcb);
  FBLADDEND   = PHYS(rcb);
  }

void clockwait(unsigned int et)
  {
  unsigned int ct;

  et/=2;
  t_clear();
  do
    {
    ct=t_get();
    }while(ct<et);
  }

void InitTcb(void)
  {
  int i;

  tcb_index=0;
  tcb_array=(struct tcb_s *)UNCACHED(&tcb_array_i[0]);
  for(i=0;i<TCB_ENTRIES;i++)
    {
    tcb_array[i].mode=0;
    tcb_array[i].BufPtr=0;
    tcb_array[i].Res1=0;
    tcb_array[i].DO_FBLID=0;
    tcb_array[i].RcbPtr=0;
    }
  SAVE1=(int)tcb_array;
  }

void IssueSend(volatile int *buffer,int size, int pass_crc)
  {
  int itmp;
  struct tcb_s *tcb_ptr;

  size+=4; /*Deal with CRC padding*/

  itmp=tcb_index++; 
  if (tcb_index>=TCB_ENTRIES) 
    tcb_index=0;

  tcb_array[itmp].mode=(size+4)|0xc0000000;
  if (pass_crc)
	tcb_array[itmp].mode|=0x20000000;
		  
  tcb_array[itmp].BufPtr=PHYS((int *)buffer);
  tcb_array[itmp].DO_FBLID=(((bit32u)buffer)&3)<<16;
  tcb_pending++;
  tcb_ptr=&tcb_array[itmp];

  while((TXPADDCNT&0x80000000)==0)
    {
    }

  TXPADDCNT = 1;    
  TXPADDSTART = PHYS(tcb_ptr);
  TXPADDEND   = PHYS(tcb_ptr);
  }

void sed_shutdown(void)
  {
	/* Take the MAC out of reset */
	if(emacbase ==  EMACA_BASE)
	{
		RESET_PRCR  &= ~EMACA_RESET;
	}
	else
	{
  		RESET_PRCR  &= ~EMACB_RESET;
	}

#ifdef ACPEP
	/* Put the PHY in reset */
	if(emacbase ==  EMACA_BASE)
	{
		ACPEP_EPLD_RESET_CTRL_REG &= ~ACPEP_EPLD_RESET_MIIA;
	}
	else
	{
		ACPEP_EPLD_RESET_CTRL_REG &= ~ACPEP_EPLD_RESET_MIIB;
	}
#endif
  }

int sed_Init(int loopback)
  {
  register int i,EmacDuplex = 0,EmacSpeed = 0, PhyNum = 0;
  bit32u uitmp, linktimeout;
  char *cp;
  unsigned int timeoutvalue;
  bit32u tempPhyState = 0;

  /*
   * and initialize the exported variable which gives the Eth broadcast
   * address, for everyone else to use. 
   */

  for (i=0; i<3; i++) 
    sed_ethBcastAddr[i] = 0xFFFF;
#ifdef ACPEP 
	/* Take the PHY out of reset */
	if(emacbase ==  EMACA_BASE)
	{
		ACPEP_EPLD_RESET_CTRL_REG |= ACPEP_EPLD_RESET_MIIA;
	}
	else
	{
		ACPEP_EPLD_RESET_CTRL_REG |= ACPEP_EPLD_RESET_MIIB;
	}
#endif	
    
  /* accept packets addressed for us and broadcast packets */
  
  InitTcb();
  InitRcb(BUFFER_SIZE);    /*Initialize RCB with 1518 byte buffers*/


  /* Take the MAC out of reset */
  if(emacbase ==  EMACA_BASE)
  {
	RESET_PRCR  &= ~EMACA_RESET;
	clockwait(64);
	RESET_PRCR  |= EMACA_RESET;
	clockwait(64);
  }
  else
  {
  	RESET_PRCR  &= ~EMACB_RESET;
  	clockwait(64);
  	RESET_PRCR  |= EMACB_RESET;
  	clockwait(64);
  }

  /*Reset the mac*/
  DMACONFIG = 0x80000000;
  DMACONFIG = 0x00000000;

  /* allocate Tx completion ring (TX_COMP_ENTRIES entries) */
  init_txcomp(TX_COMP_ENTRIES);

  /* Set DMA burst length to 16 words */
  TDMASTATE7 = 0x00100000; 

  /* allocate Rx completion ring (four entries) */
  init_rxcomp(RX_COMP_ENTRIES);

  /* Set Rx DMA state stuff */
  RDMASTATE0 = 0x00000200; 

  /* Set Rx Buffer Size */
  FBL0BUFSIZE = BUFFER_SIZE;

  /*Initialize MDIO Phy State machine*/
  PhyState = 0;
  EmacMdioInit(emacbase,(int *)&PhyState,av_cpufreq);
  
  clockwait((av_cpufreq/1000000)*32*64*4);     /* Wait for a pool loop */
 
  if (av_cpufreq >= 75000000)
	tempPhyState = NWAY_FD100|NWAY_HD100|NWAY_FD10|NWAY_HD10; /* Phy 100 and Full Duplex */
  else
	tempPhyState = NWAY_FD100|NWAY_FD10; /* Full Duplex */
  if (loopback == EXTERNAL_LOOP)
	tempPhyState |= PHY_LOOP; /* external phy loop */
  else if (loopback == NORMAL)
	tempPhyState |= NWAY_AUTO; /* auto negotiation */
  EmacMdioSetPhyMode(emacbase, (int *)&PhyState, tempPhyState);

  if (loopback == EXTERNAL_LOOP)
  {
	for (i = 0; i < 5; i++)
  	  EmacMdioTic(emacbase,(int *)&PhyState);
  }
  else if (loopback == NORMAL)
  {
	/*Call EmacMdioTic every 10mS until EmacMdioGetLinked returns TRUE;*/
    /*This can be called every 10 mS forever so that cable un-plugs and re-plugs are delt with.*/
    timeoutvalue = (cp = sys_getenv("link_timeout")) ? atoui(cp) : LINK_TIMEOUT;
    t_clear();  
    linktimeout = t_get() + GetTicks(timeoutvalue);
    sys_printf("Waiting for %d secs to detect the EMAC link...\n", timeoutvalue);
    while((!EmacMdioGetLinked(emacbase,(int *)&PhyState)) && (t_get() < linktimeout))
    {
      /*clockwait(av_cpufreq/100);*/  /* Commented as the above timer gets reset */
	  EmacMdioTic(emacbase,(int *)&PhyState);
    }
    if (!EmacMdioGetLinked(emacbase,(int *)&PhyState))
    {
	  sys_printf("EMAC Link DOWN.\n");
	  return 1;
    }
    else
      sys_printf("EMAC Link UP.\n");
  }
  
  /*The Below section is done any time the EmacMdioTic returns TRUE!*/
  /*Retreive Duplex and Speed and the Phy Number*/
  EmacDuplex = EmacMdioGetDuplex(emacbase,(int *)&PhyState);
  EmacSpeed = EmacMdioGetSpeed(emacbase,(int *)&PhyState);
  PhyNum = EmacMdioGetPhyNum(emacbase,(int *)&PhyState);

  /* Set mode of the MAC  */   
  MDIOMACPHY = PhyNum | (((loopback == WIRE_LOOP) || (loopback == NORMAL))?0x80:0x00);
  
  if (loopback == EXTERNAL_LOOP)
  {
  	WRAPCLK |= 0x80000000; /*Force MII link in External WRAP*/
    clockwait((av_cpufreq/1000000)*64*2*4);      /*Wait for the write to happen*/
  }

  MACCONTROL = ((EmacDuplex)?FULL_DUPLEX:0) | ((EmacSpeed)?SPEED_100:0) | ((loopback == INTERNAL_LOOP)?0:NO_LOOP) | TXPACE | CLRP | ((loopback != NORMAL)?(PEFCE|CAF):0);
  
  /* Enable Rx and Tx DMA, and unreset MAC */
  DMACONFIG = 0x00000003;

  if (loopback == NORMAL)
  {
    /* Set Copy All Frames mode */
    INTSTS  = 0x1ff; /* Clear all pending interrupts */
 
    /* Set the MAC address for the PHY */
    cp = (char *)sed_lclEthAddr;
    uitmp =(((bit32u)*cp++)&0x0ff);
    uitmp|=(((bit32u)*cp++)&0x0ff)<<8;
    uitmp|=(((bit32u)*cp++)&0x0ff)<<16;
    uitmp|=(((bit32u)*cp++)&0x0ff)<<24;
    MACADDRHI=uitmp;
    uitmp =(((bit32u)*cp++)&0x0ff);
    uitmp|=(((bit32u)*cp++)&0x0ff)<<8;
    MACADDRLO=uitmp;    
  }

  for(i = 0; i < RCB_ENTRIES; i++)
    RxFree(&rcb_array[i]);

  /* Now put some data in Tx buffer */
  return(0);
  }

/* 
 * Format an ethernet header in the transmit buffer, and say where it is.
 * Note that because of the way the 3Com interface works, we need to know
 * how long the packet is before we know where to put it.  The solution is
 * that we format the packet at the BEGINNING of the transmit buffer, and
 * later copy it (carefully) to where it belongs.  Another hack would be
 * to be inefficient about the size of the packet to be sent (always send
 * a larger ethernet packet than you need to, but copying should be ok for
 * now.
 */

char abuffer[4096];

octet *
sed_FormatPacket( destEAddr, ethType )
        register octet *destEAddr;
  {
  octet *xMitBuf;
  bit32u *dp;
  int i;
    
  for(i=0,dp=(bit32u *)abuffer;i<((sizeof abuffer)/4);i++) 
    *dp++=0;

  xMitBuf = (octet *)&abuffer[2];
  Move( destEAddr, xMitBuf, 6 );
  Move( sed_lclEthAddr, xMitBuf + 6, 6 );
  *((short *)(xMitBuf+12)) = wfix(ethType);
  return(xMitBuf+14);
  }

/*
 *  Send a packet out over the ethernet.  The packet is sitting at the
 * beginning of the transmit buffer.  The routine returns when the
 * packet has been successfully sent.
 */
int sed_Send( pkLengthInOctets )
  register int pkLengthInOctets;
  {
  char *cp;

  pkLengthInOctets += 14;             /* account for Ethernet header */
  pkLengthInOctets = (pkLengthInOctets + 1) & (~1);

  if (pkLengthInOctets < E10P_MIN) 
    pkLengthInOctets = E10P_MIN; /* and min. ethernet len */

  cp=&abuffer[2];
  IssueSend((int *)UNCACHED(cp),pkLengthInOctets, FALSE);
  /*Now wait for Tx completion*/
  while (TCRFREEENT == txcompring_size)
    {
    }
  TCRENTINC=1;
  return(0);
  }

/* 
 * Test for the arrival of a packet on the Ethernet interface.  The packet may
 * arrive in either buffer A or buffer B; the location of the packet is
 * returned.  If no packet is returned withing 'timeout' milliseconds,
 * then the routine returns zero.
 * 
 * Note: ignores ethernet errors.  may occasionally return something
 * which was received in error.
 */

octet *sed_IsPacket(void)
  {
  octet *pb;
    
  pb=GetRxPacket();
  if (pb)
    {
    pb+=14;
    }
  return(pb);
  }

/* 
 *  Check to make sure that the packet that you received was the one that
 * you expected to get.
 */
int sed_CheckPacket( recBufLocation, expectedType )
    word *recBufLocation;
    word expectedType;
  {

  if ( recBufLocation[-1] != wfix(expectedType) ) 
    return(0);
   else
    return(1);
  }

char ubuff[2048];

void *GetRxPacket(void)
  {
  bit32u uitmpsts,rlen;
  char *uipbufrtn;

  uipbufrtn=0;
  do
    {
    if (RCRPENDENT)
      {
      uitmpsts=RxCompPtr->status;
      CurrentRcb=(struct rcb_s *)UNCACHED(RxCompPtr->sof_list);
      rlen=CurrentRcb->size&0x0ffff;
      if (((uitmpsts&0xc0000000)==0x80000000)&&(rlen>=60)&&(rlen<=1514))
        { /* Good frame*/
        sys_memcpy(&ubuff[2],CurrentRcb->DatPtr,rlen);
        uipbufrtn=&ubuff[2];
        }
      if (uitmpsts&0x80000000)
        {
        RxFree(CurrentRcb);                         
        }
      RxCompPtr=((struct rxcompring_s *) ((((int)(RxCompPtr+1))&RxCompRingMask)|(RxCompRingBase)));
      RCRENTINC=1;
      }
    }while((RCRPENDENT)&&(uipbufrtn==0));
  return(uipbufrtn);
  }

#ifdef DIAG_SUPPORT
void FillBuffer(volatile int *buffer,int size)
{
  int i;
  char *cp;

  if ((size > 1518) || (size < 64)) 
	return;
  cp = (char *)buffer;
  for(i = 0; i < size; i++)
    *cp++ = (i + 1);
}

int CheckBuffer(volatile int *buffer, int size, int seq)
{
  int i;
  char *cp;

  if ((size > 1518) || (size < 64)) 
  {
    return 1;
  }
  size -= 4;
  cp = (char *)buffer;
  for(i = 0; i < size; i++, cp++)
  {
    if (i == SEQ)
    {
      if ((*cp & 0x0ff) != (seq & 0x0ff))
      {
		/*sys_printf("\n Rx Buffer data miscompare, Expected %x, Found %x\n", (seq&0x0ff), (*cp&0x0ff));*/
        return 1;
       }
    }
    else
    {
      if ((*cp & 0x0ff) != ((i + 1) & 0x0ff)) 
      {
		/*sys_printf("\n Rx Buffer data miscompare, Expected %x, Found %x\n", ((i+1)&0x0ff), (*cp&0x0ff));*/
        return 1;
      }
    }
  }
  rcb_pending--;
  return(0);
}

void SetSeq(volatile int *buffer,int seq)
{
  char *cp;

  if (SEQ >= BUFFER_SIZE) 
	return;
  cp = (char *)buffer;
  cp[SEQ] = (char)seq;
}

int test_emac(int loopback)
{
  volatile unsigned *mem_ptr; 
  int data_val, i, j, m, RxNeed, ExpTxErrors, try, sts; 

  if (sed_Init(loopback) == 1)
	return 1;

  /* Now put some data in Tx buffer */
  for(i = 0;i < TX_BUF_COUNT; i++)
  {
    if (i >= FLIP_TBUF_INDEX)
      mem_ptr = sys_malloc(1518+16);
    else
      mem_ptr  = sys_malloc(1518+16);
    if (!mem_ptr) {
      sys_printf("Error: sys_malloc\n");
	  return 1;
	}
    mem_ptr=(volatile unsigned *)((i&0xf)+((bit32u)mem_ptr));
    FillBuffer((int *)mem_ptr,1518);
    tx_buf[i] = mem_ptr;
  }

  tx_buf_index = 0;
  tx_frame_seq = rx_fram_seq = 0;
  ExpTxErrors = 0;

  if ((loopback == EXTERNAL_LOOP) || (loopback == WIRE_LOOP))
    clockwait(3*av_cpufreq);
  t_clear();
  if (MACCONTROL&NO_LOOP)
  {
    while(MACSTATUS & 1) 
    {
      if (t_get() > (4*av_cpufreq)) 
      {
		sys_printf("\n Timed out waiting for Link\n");
        return 1;
      }
    }
  }

  /* Now send frame */
  for(j = 0; j < loops; j++)
  {
    for(i = MIN_FRAME_SIZE;i <= MAX_FRAME_SIZE; i += steps)
    {
      for(m = 0; m < TX_BURST_COUNT; m++)
      {
        mem_ptr = tx_buf[tx_buf_index++];
        if (tx_buf_index >= TX_BUF_COUNT) tx_buf_index = 0;
        SetSeq((int *)mem_ptr, tx_frame_seq++);
        IssueSend((int *)mem_ptr, i, FALSE);
        if (((tx_frame_seq & 0xff) == 0) && (( j> 2) || (loops == 1)))
        {
          IssueSend((int *)mem_ptr, i, TRUE);
          ExpTxErrors++;
        }
      }
      for(m = 0; m < TX_BURST_COUNT; m++)
      {
        try = TEST_TIMEOUT;
        while (TCRFREEENT == txcompring_size)
        {
          data_val++;
          if (!try) 
          {
			/*sys_printf("\n Timed out waiting for Tx Completion Ring\n");*/
            return 1;
          }
          try--;
        }
        RxNeed = 1;
        while (RxNeed)
        {
          try = TEST_TIMEOUT;
          while (RCRFREEENT == rxcompring_size)
          {
            data_val++;
            if (!try) 
            {
			  /*sys_printf("\n Timed out waiting for Rx Completion Ring %x %x\n", RCRFREEENT, rxcompring_size);*/
              return 1;
            }
            try--;
          }
      	  CurrentRcb = (struct rcb_s *)UNCACHED(RxCompPtr->sof_list);
          if ((RxCompPtr->status & 0xc0000000) == 0x80000000)
          {
            RxNeed--;
            sts = CheckBuffer(CurrentRcb->DatPtr, i, rx_fram_seq++);
            if (sts) 
            {
              MACCONTROL = CAF | FULL_DUPLEX | SPEED_100 | PEFCE;
              return(sts);
            }
            if ((CurrentRcb->size & 0x0ffff) != (i+4)) 
			{
			  /*sys_printf("\n Rx buffer Length error, i=%d, size=%x\n", (i+4), (CurrentRcb->size & 0xffff));*/
              return 1;
			}
            *(CurrentRcb->DatPtr) = 0;
            RxFree(CurrentRcb);
          }
          RxCompPtr = ((struct rxcompring_s *) ((((int)(RxCompPtr + 1))&RxCompRingMask) | (RxCompRingBase)));
          RCRENTINC = 1;
        }
        tcb_pending--;
        TCRENTINC = 1;
      }
      while(ExpTxErrors) 
      {
        try = TEST_TIMEOUT;
        while (TCRFREEENT == txcompring_size)
        {
          data_val++;
          if (!try) 
          {
			/*sys_printf("\n Timed out waiting for Tx Completion Ring\n");*/
            return 1;
          }
          try--;
        }
        ExpTxErrors--;
        tcb_pending--;
        TCRENTINC = 1;
      }
    }
  }
  sed_shutdown();
  return 0;
}

#if 0
"emac(id=eth0:InternalLoopback, base=0xA8610000, reset_bit=17, loopback=internal)",
"emac(id=eth1:InternalLoopback, base=0xA8612800, reset_bit=21, loopback=internal)",
"emac(id=eth0:ExternalLoopback, base=0xA8610000, reset_bit=17, loopback=external, mii_phy=1, critical=no)",
"emac(id=eth1:ExternalLoopback, base=0xA8612800, reset_bit=21, loopback=external, mii_phy=1, critical=no)",
"emac(id=eth0:WireLoopback    , base=0xA8610000, reset_bit=17, loopback=wire    , mii_phy=1, critical=no)",
"emac(id=eth1:WireLoopback    , base=0xA8612800, reset_bit=21, loopback=wire    , mii_phy=1, critical=no)",
#endif
int demac(void)
{
    char *cp;

	rtim = t_get();
	av_cpufreq = (cp = sys_getenv("cpufrequency")) ? atoul(cp) : 125000000;
  	ticdiv = av_cpufreq / 2000;

	loops = 1/*10*/;
	steps = 7/*1*/;	
	
	emacbase = EMACA_BASE;
	
	sys_printf("Testing 'eth0' InternalLoop ");
	if (test_emac(INTERNAL_LOOP) == 1)
	{
		sys_printf("Failed\n");
		return 1;
	}
	else
		sys_printf("Passed\n");
	
	sys_printf("Testing 'eth0' ExternalLoop ");
	if (test_emac(EXTERNAL_LOOP) == 1)
	{
		sys_printf("Failed\n");
		return 1;
	}
	else
		sys_printf("Passed\n");

#if 0
    sys_printf("Testing 'eth0' WireLoop ");
	if (test_emac(WIRE_LOOP) == 1)
	{
		sys_printf("Failed\n");
		return 1;
	}
	else
		sys_printf("Passed\n");
#endif
	return 0;
}
#endif /*DIAG_SUPPORT*/

#include "emacphy.c"
