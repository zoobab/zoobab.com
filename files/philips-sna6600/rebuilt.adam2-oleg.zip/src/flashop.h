/*-----------------------------------------------------------------------------*/
/*                                                                             */
/*   Copyright (C) 1999-2003 by Texas Instruments, Inc.  All rights reserved.  */
/*   Copyright (C) 2001-2003 Telogy Networks.	    						   */
/*                                                                             */
/*-----------------------------------------------------------------------------*/

#ifndef	___FLASHOP_H___
#define	___FLASHOP_H___

#ifdef AR5D01
#define MIN_BOOT_BLOCK_SIZE     (64*1024)
#define MIN_ENV_BLOCK_SIZE      (64*1024)
#else
#ifdef ACPEP
#define MIN_BOOT_BLOCK_SIZE     (128*1024)
#define MIN_ENV_BLOCK_SIZE      (128*1024)
#else
#ifdef WA100
#define MIN_BOOT_BLOCK_SIZE     (64*1024)
#define MIN_ENV_BLOCK_SIZE      (64*1024)
#else
#ifdef AR5W01
#define MIN_BOOT_BLOCK_SIZE     (64*1024)
#define MIN_ENV_BLOCK_SIZE      (64*1024)
#else
#if defined(AR7DB) || defined(AR7RD) || defined(AR7WRD)
	#if	BOOT_SIZE == 64
		#define MIN_BOOT_BLOCK_SIZE     (64*1024)	//By Charles add for check flash size bootloader size 04-28-2004
	#elif BOOT_SIZE == 128
		#define MIN_BOOT_BLOCK_SIZE     (128*1024)	//By Charles add for check flash size bootloader size 04-28-2004
	#else
		#define MIN_BOOT_BLOCK_SIZE     (64*1024)	//By Charles add for check flash size bootloader size 04-28-2004
	#endif	/* BOOT_SIZE Endif */
	#define MIN_ENV_BLOCK_SIZE      (64*1024)	//By Charles add for check flash size env size 04-28-2004
#else
	#define MIN_BOOT_BLOCK_SIZE     (256*1024)
	#define MIN_ENV_BLOCK_SIZE      (256*1024)
#endif
#endif
#endif
#endif
#endif

int FWBGetBlockSize(bit32u base);           /*Get Flash Block Size            */
int FWBErase(bit32u base,int size,int verbose); /*Erase flash                 */
int FWBOpen(bit32u base);                   /*Prepare for flash writes        */
int FWBWriteByte(bit32u adr, bit8 cVal);    /*Write byte to flash             */
int FWBClose(void);                         /*Write any pending data to flash */
int FWBUnLock(bit32u adr,bit32 size);       /*Unlock Flash block(s)           */
int FWBLock(bit32u from,bit32 size);        /*Lock Flash block(s)             */
int FWBValid(bit32u base);		    /* Check for limits	*/

#ifdef ACPEP
/* This function is only available directly from a file linked to flashop.c */
int FWBGet_flash_type(void);
#endif

#endif /* ___FLASHOP_H___ */

