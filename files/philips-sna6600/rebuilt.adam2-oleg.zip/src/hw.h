/*-----------------------------------------------------------------------------*/
/*                                                                             */
/*   Copyright (C) 1999-2003 by Texas Instruments, Inc.  All rights reserved.  */
/*   Copyright (C) 2001-2003 Telogy Networks.	    						   */
/*                                                                             */
/*-----------------------------------------------------------------------------*/

#ifndef	_HARDWARE_H_ADAM2_
#define	_HARDWARE_H_ADAM2_

#define ASCII_DISP_BASE 	0xbd000038
#define ASCII_DISP_OFFSET   1

#define CS0_BASE 0xb0000000
#define CS1_BASE 0xb4000000

#ifdef AR5D01
#define CS0_SIZE (2*1024*1024)
#define CS1_SIZE (8*1024*1024)
#else
#ifdef ACPEP
#define CS0_SIZE (16*1024*1024)
#define CS1_SIZE (64*1024*1024)
#else
#ifdef WA100
#define CS0_SIZE (2*1024*1024)
#define CS1_SIZE (8*1024*1024)
#else
#ifdef AR5W01
#define CS0_SIZE (4*1024*1024)
#define CS1_SIZE (16*1024*1024)
#else
#if defined(AR7WRD)	//By Charles Modify for check flash & SDRAM Size 04-28-2004
	#if FLASH_SIZE == 4
		#define CS0_SIZE (4*1024*1024)
	#elif FLASH_SIZE == 8
		#define CS0_SIZE (8*1024*1024)
	#else
		#define CS0_SIZE (4*1024*1024)
	#endif
	
	#if MEM_SIZE == 16
		#define CS1_SIZE (16*1024*1024)
	#elif MEM_SIZE == 32
		#define CS1_SIZE (32*1024*1024)
	#else 
		#define CS1_SIZE (16*1024*1024)
	#endif	/* FLASHSIZE & MEM_SIZE Endif */
#else
#if defined(AR7DB)
	#if FLASH_SIZE == 4 // by Oleg
		#define CS0_SIZE (4*1024*1024)
	#else
		#define CS0_SIZE (2*1024*1024)
	#endif
	
	#if MEM_SIZE == 16
		#define CS1_SIZE (16*1024*1024)
	#elif MEM_SIZE == 32
		#define CS1_SIZE (32*1024*1024)
	#else 
		#define CS1_SIZE (8*1024*1024)
	#endif	/* FLASHSIZE & MEM_SIZE Endif */
#else

/* Allow 2-8 and 4-16 foot prints for AR7RD ADAM2 builds */
#if defined(AR7RD)
	#if FLASH_SIZE == 4
		#define CS0_SIZE (4*1024*1024)
	#else
		#define CS0_SIZE (2*1024*1024)
	#endif
	
	#if MEM_SIZE == 16
		#define CS1_SIZE (16*1024*1024)
	#elif MEM_SIZE == 32
		#define CS1_SIZE (32*1024*1024)
	#else 
		#define CS1_SIZE (8*1024*1024)
	#endif
#else
#ifdef SEAD2
#define CS0_SIZE (32*1024*1024)
#define CS1_SIZE (128*1024*1024)
#else
#define CS0_SIZE (32*1024*1024)
#define CS1_SIZE (64*1024*1024)
#endif /* SEAD2 */
#endif /* AR7RD */
#endif /* AR7DB */
#endif /* AR7WRD */
#endif /* AR5W01 */
#endif /* WA100 */
#endif /* ACPEP */
#endif /* AR5D01 */

#define EMIF_SDRAM_BASE     	0x94000000
#define EMIF_SDRAM_MAX_SIZE     (CS1_SIZE) 	/*it was 0x08000000 or 0x01000000*/

#define CS3_BASE 0xbc000000
#define CS3_SIZE (16*1024*1024)
#define CS4_BASE 0xbd000000
#define CS4_SIZE (16*1024*1024)
#define CS5_BASE 0xbe000000
#define CS5_SIZE (16*1024*1024)

#define ACPEP_CPU_FREQ  50000000

#define KSEG_MSK     	0xe0000000
#define KSEG0BASE       0x80000000
#define KSEG1BASE       0xa0000000

#ifdef _ASSEMBLER_
#define KSEG1(addr)     (((addr) & ~KSEG_MSK) | KSEG1BASE)
#define KSEG0(addr)     (((addr) & ~KSEG_MSK) | KSEG0BASE)
#define KUSEG(addr)     ((addr) & ~KSEG_MSK)
#else
#define KSEG1(addr)     (((UINT32)(addr) & ~KSEG_MSK) | KSEG1BASE)
#define KSEG0(addr)     (((UINT32)(addr) & ~KSEG_MSK) | KSEG0BASE)
#define KUSEG(addr)   	((UINT32)(addr) & ~KSEG_MSK)
#endif

#define UNCACHED(addr)	KSEG1(addr)
#define CACHED(addr)	KSEG0(addr)
#define PHYS(addr)		KUSEG(addr)

#ifndef _ASSEMBLER_
#define EMACA_BASE   	(KSEG1(0x08610000))
#define EMACB_BASE   	(KSEG1(0x08612800))
#define EMIF_BASE       (KSEG1(0x08610800))
#define GPIO_BASE       (KSEG1(0x08610900))
#define CLOCK_BASE   	(KSEG1(0x08610a00))
#define UARTA_BASE      (KSEG1(0x08610e00))
#define UARTB_BASE      (KSEG1(0x08610f00))
#define IIC_BASE        (KSEG1(0x08611000))
#define RESET_BASE 		(KSEG1(0x08611600))
#define INTR_BASE		(KSEG1(0x08612400))

#define BOOTCR     		(*(volatile unsigned *)(0xa8611a00+0x0))
#define BOOTCR_PLLPB 	0x00000020
#define BCR_BYPASS 		(1<<5)

/* EMAC registers -- sed.c */

/* EMIF registers */
#define EMIF_REV        (*(volatile unsigned int*)(EMIF_BASE+0x00))
#define EMIF_GASYNC     (*(volatile unsigned int*)(EMIF_BASE+0x04))
#define EMIF_DRAMCTL    (*(volatile unsigned int*)(EMIF_BASE+0x08))
#define EMIF_REFRESH    (*(volatile unsigned int*)(EMIF_BASE+0x0c))
#define EMIF_ASYNC_CS0  (*(volatile unsigned int*)(EMIF_BASE+0x10))
#define EMIF_ASYNC_CS3  (*(volatile unsigned int*)(EMIF_BASE+0x14))
#define EMIF_ASYNC_CS4  (*(volatile unsigned int*)(EMIF_BASE+0x18))
#define EMIF_ASYNC_CS5  (*(volatile unsigned int*)(EMIF_BASE+0x1c))

#define EMIF_DRAMCTL_CL3_BIT 0x00002000

/* GPIO registers */
#define GPIO_IN         (*(volatile unsigned *)(GPIO_BASE+0x0))
#define GPIO_OUT   		(*(volatile unsigned int *)(GPIO_BASE+0x4))
#define GPIO_DIR   		(*(volatile unsigned int *)(GPIO_BASE+0x8)) /* 0=o/p, 1=i/p */
#define GPIO_EN    		(*(volatile unsigned int *)(GPIO_BASE+0xc)) /* 0=GPIO Mux 1=GPIO */

/* GPIO mux bits */
#define EINT_0			(1<<17)
#define EINT_1			(1<<18)
#define EINT_2			(1<<19)
#define EINT_3			(1<<20)
#define GPIO_0			(1<<21)
#define GPIO_1			(1<<22)
#define GPIO_2			(1<<23)
#define GPIO_3			(1<<24)

/* Clock registers */
#define CLK_PDCR  		(*(volatile unsigned *)(CLOCK_BASE+0x00))
#define SCLKCR_DIV      (*(volatile unsigned *)(CLOCK_BASE+0x20))
#define SCLKCR_MUL      (*(volatile unsigned *)(CLOCK_BASE+0x30))

/* UART registers -- sio.c */

/* IIC registers */
#define IIC_DATA_HI    	(*(volatile unsigned *)(IIC_BASE+0x0))
#define IIC_DATA_LOW   	(*(volatile unsigned *)(IIC_BASE+0x4))
#define IIC_CONFIG     	(*(volatile unsigned *)(IIC_BASE+0x8))
#define IIC_DATA_READ  	(*(volatile unsigned *)(IIC_BASE+0xc))
#define IIC_CLOCK_DIV  	(*(volatile unsigned *)(IIC_BASE+0x10))

#define IICWRITE  		0x200
#define IICREAD   		0x300
#define END_BURST 		0x400

/* RESET registers */
#define RESET_PRCR      (*(volatile unsigned *)(RESET_BASE+0x0))

/* Reset Control bits */
#define UART0_RESET		(1<<0)
#define UART1_RESET		(1<<1)
#define IIC_RESET  		(1<<2)
#define GPIO_RESET 		(1<<6)
#define EMACA_RESET 	(1<<17)
#define EMACB_RESET 	(1<<21)
#define MDIO_RESET		(1<<22)
#define EMAC_PHY_RESET 	(1<<26)

/* Interrupt control registers */
#define INTR_EXCR		(*(volatile unsigned *)(INTR_BASE + 0x088))

#ifdef ACPEP
#define TNETD53XX_MIPS_PLL 	0x08610A30
#define TNETD53XX_MIPS_DIV 	0x08610A20
#define TNETD53XX_REG32(A)	(*(volatile unsigned *)(UNCACHED(A)))
#endif /*ACPEP*/

#if defined(EVM3) || defined(EVM3D)
#define PPM_TOLERANCE 5000
#endif

#if defined(AR7DB) || defined(AR7RD) || defined(AR7WRD)
#define MHZ(x)              ((x) * 1000 * 1000)
#define CONF_REFXTAL_FREQ   MHZ(25)
#define CONF_AFEXTAL_FREQ   MHZ(24)
#define CONF_XTAL3IN_FREQ   MHZ(35)
#define CONF_CPU_FREQ       MHZ(150)
#define CONF_SYS_FREQ       MHZ(125)
#define SYS_MAX_F           MHZ(125)
#define SYS_MIN_F           MHZ(25)

#define CPU_SYNC_MAX_F      SYS_MAX_F
#define CPU_ASYNC_MAX_F     MHZ(160)
#define CONF_SDRAM_SZ       MEG(64)

#if defined(AR7RD) || defined(AR7WRD)
#define CONF_CPMAC_IF       1 /* Valid values: 0, 1 EXTERNAL */
#else
#define CONF_CPMAC_IF       0 /* Valid values: 0, 1 INTERNAL */
#endif

#endif
#endif /* _ASSEMBLER_ */

#endif /* _HARDWARE_H_ADAM2_ */


