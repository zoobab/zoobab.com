/*-----------------------------------------------------------------------------*/
/*                                                                             */
/*   Copyright (C) 1999-2003 by Texas Instruments, Inc.  All rights reserved.  */
/*   Copyright (C) 2001-2003 Telogy Networks.	    						   */
/*                                                                             */
/*-----------------------------------------------------------------------------*/

#ifndef	___SRLOADER_H___
#define	___SRLOADER_H___

#define TAG_LITTLE 0xFEEDFA42
#define TAG_BIG    0xDEADBE42

#ifdef EB
#define TAG_WANTED TAG_BIG
#endif
#ifdef EL
#define TAG_WANTED TAG_LITTLE
#endif

#ifdef FFS_SUPPORT
bit32u progloader(int argc, char *argv[]);
#endif

bit32u imageloader(bit32u address);

int getf32(bit32u address, bit32u *dat, int fileflag);

#endif

