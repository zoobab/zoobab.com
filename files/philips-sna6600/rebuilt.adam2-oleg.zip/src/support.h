/*-----------------------------------------------------------------------------*/
/*                                                                             */
/*   Copyright (C) 1996-2003 by Texas Instruments, Inc.  All rights reserved.  */
/*   Copyright (C) 2001-2003 Telogy Networks.	    						   */
/*                                                                             */
/*-----------------------------------------------------------------------------*/

#include "_stddef.h"
#include "_stdio.h"
                     
/* support.c calls */
#ifndef	___SUPPORT_H___
#define	___SUPPORT_H___
       
void SkipSpaces(char **ptr);
int IsCharMember(char achar,char *member);
void GetStringField(char **cpp,char *cstr,int clen,char *leagals);
void GetInputLine(char *str,int len,char *leagals);
unsigned int atoui(char *cp);
int isalnum(int c);
int islower(int c);
int isdigit(int c);
int isxdigit(int c);


unsigned long strtoul(const char *str, char **endptr, int base);
long strtol(const char *str, char **endptr, int base);
unsigned int atoui(char *cp);
unsigned long atoul(const char *str);
unsigned long atol(const char *str);

char *strtok(char *s, int c);
char *strncpy(char *s1, const char *s2, int len);

#endif


