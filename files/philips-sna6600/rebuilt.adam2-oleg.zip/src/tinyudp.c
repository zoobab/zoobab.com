/*-----------------------------------------------------------------------------*/
/*                                                                             */
/*   Copyright (C) 2002-2003 by Texas Instruments, Inc.  All rights reserved.  */
/*   Copyright (C) 2002-2003 Telogy Networks, Inc.							   */
/*                                                                             */
/*   NOTE: THIS VERSION OF CODE IS MAINTAINED BY TELOGY NETWORKS AND NOT TI!   */
/*                                                                             */
/*     IMPORTANT - READ CAREFULLY BEFORE PROCEEDING TO USE SOFTWARE.           */
/*                                                                             */
/*  This document is displayed for you to read prior to using the software     */
/*  and documentation.  By using the software and documentation, or opening    */
/*  the sealed packet containing the software, or proceeding to download the   */
/*  software from a Bulletin Board System(BBS) or a WEB Server, you agree to   */
/*  abide by the following Texas Instruments License Agreement. If you choose  */
/*  not to agree with these provisions, promptly discontinue use of the        */
/*  software and documentation and return the material to the place you        */
/*  obtained it.                                                               */
/*                                                                             */
/*                               *** NOTE ***                                  */
/*                                                                             */
/*  The licensed materials contain MIPS Technologies, Inc. confidential        */
/*  information which is protected by the appropriate MIPS Technologies, Inc.  */
/*  license agreement.  It is your responsibility to comply with these         */
/*  licenses.                                                                  */
/*                                                                             */
/*                   Texas Instruments License Agreement                       */
/*                                                                             */
/*  1. License - Texas Instruments (hereinafter "TI"), grants you a license    */
/*  to use the software program and documentation in this package ("Licensed   */
/*  Materials") for Texas Instruments broadband products.                      */
/*                                                                             */
/*  2. Restrictions - You may not reverse-assemble or reverse-compile the      */
/*  Licensed Materials provided in object code or executable format.  You may  */
/*  not sublicense, transfer, assign, rent, or lease the Licensed Materials    */
/*  or this Agreement without written permission from TI.                      */
/*                                                                             */
/*  3. Copyright - The Licensed Materials are copyrighted. Accordingly, you    */
/*  may either make one copy of the Licensed Materials for backup and/or       */
/*  archival purposes or copy the Licensed Materials to another medium and     */
/*  keep the original Licensed Materials for backup and/or archival purposes.  */
/*                                                                             */
/*  4. Runtime and Applications Software - You may create modified or          */
/*  derivative programs of software identified as Runtime Libraries or         */
/*  Applications Software, which, in source code form, remain subject to this  */
/*  Agreement, but object code versions of such derivative programs are not    */
/*  subject to this Agreement.                                                 */
/*                                                                             */
/*  5. Warranty - TI warrants the media to be free from defects in material    */
/*  and workmanship and that the software will substantially conform to the    */
/*  related documentation for a period of ninety (90) days after the date of   */
/*  your purchase. TI does not warrant that the Licensed Materials will be     */
/*  free from error or will meet your specific requirements.                   */
/*                                                                             */
/*  6. Remedies - If you find defects in the media or that the software does   */
/*  not conform to the enclosed documentation, you may return the Licensed     */
/*  Materials along with the purchase receipt, postage prepaid, to the         */
/*  following address within the warranty period and receive a refund.         */
/*                                                                             */
/*  TEXAS INSTRUMENTS                                                          */
/*  Application Specific Products, MS 8650                                     */
/*  c/o ADAM2 Application Manager                                              */
/*  12500 TI Boulevard                                                         */
/*  Dallas, TX 75243  - U.S.A.                                                 */
/*                                                                             */
/*  7. Limitations - TI makes no warranty or condition, either expressed or    */
/*  implied, including, but not limited to, any implied warranties of          */
/*  merchantability and fitness for a particular purpose, regarding the        */
/*  licensed materials.                                                        */
/*                                                                             */
/*  Neither TI nor any applicable licensor will be liable for any indirect,    */
/*  incidental or consequential damages, including but not limited to loss of  */
/*  profits.                                                                   */
/*                                                                             */
/*  8. Term - The license is effective until terminated.   You may terminate   */
/*  it at any other time by destroying the program together with all copies,   */
/*  modifications and merged portions in any form. It also will terminate if   */
/*  you fail to comply with any term or condition of this Agreement.           */
/*                                                                             */
/*  9. Export Control - The re-export of United States origin software and     */
/*  documentation is subject to the U.S. Export Administration Regulations or  */
/*  your equivalent local regulations. Compliance with such regulations is     */
/*  your responsibility.                                                       */
/*                                                                             */
/*                         *** IMPORTANT NOTICE ***                            */
/*                                                                             */
/*  Texas Instruments (TI) reserves the right to make changes to or to         */
/*  discontinue any semiconductor product or service identified in this        */
/*  publication without notice. TI advises its customers to obtain the latest  */
/*  version of the relevant information to verify, before placing orders,      */
/*  that the information being relied upon is current.                         */
/*                                                                             */
/*  TI warrants performance of its semiconductor products and related          */
/*  software to current specifications in accordance with TI's standard        */
/*  warranty. Testing and other quality control techniques are utilized to     */
/*  the extent TI deems necessary to support this warranty. Unless mandated    */
/*  by government requirements, specific testing of all parameters of each     */
/*  device is not necessarily performed.                                       */
/*                                                                             */
/*  Please be aware that Texas Instruments products are not intended for use   */
/*  in life-support appliances, devices, or systems. Use of a TI product in    */
/*  such applications without the written approval of the appropriate TI       */
/*  officer is prohibited. Certain applications using semiconductor devices    */
/*  may involve potential risks of injury, property damage, or loss of life.   */
/*  In order to minimize these risks, adequate design and operating            */
/*  safeguards should be provided by the customer to minimize inherent or      */
/*  procedural hazards. Inclusion of TI products in such applications is       */
/*  understood to be fully at the risk of the customer using TI devices or     */
/*  systems.                                                                   */
/*                                                                             */
/*  TI assumes no liability for TI applications assistance, customer product   */
/*  design, software performance, or infringement of patents or services       */
/*  described herein. Nor does TI warrant or represent that license, either    */
/*  expressed or implied, is granted under any patent right, copyright, mask   */
/*  work right, or other intellectual property right of TI covering or         */
/*  relating to any combination, machine, or process in which such             */
/*  semiconductor products or services might be or are used.                   */
/*                                                                             */
/*  All company and/or product names are trademarks and/or registered          */
/*  trademarks of their respective manaufacturers.                             */
/*                                                                             */
/*-----------------------------------------------------------------------------*/

#include "_stdio.h"

#include "tinyip.h"

/* largest chunk of data which we will pass through the network. this is
 * well below the Internet's minimum MTU value so we can be assured that
 * even after we tack on our own header information the complete packet
 * will be passed along without being fragmented. Our packet buffer sizes
 * are tied to this value.
*/
#define MTU 	1024

/* resolved IP address in network byte order */
typedef unsigned long ipaddr;

/* structure for internal packet buffers - adds an in-use flag */
typedef struct _PacketBuffer {
	int validData;                  /* does this buffer contain data? */
	ipaddr src;                     /* source node */
	unsigned length;                /* length of packet data */
	unsigned char data[MTU];        /* application's packet data */
} PacketBuffer;

/* packet sequence number used in the current implementation to reorder 
 * out-of-sequence packets we increment this value with each packet 
 * that we send 
*/

static unsigned gl_srcport;				/* currently open src port */
static unsigned gl_dstport;				/* currently open dst port */

udp_Socket listen;                  	/* socket used for listening */
udp_Socket talk;                    	/* socket used for talking */
static PacketBuffer rxpacket;     			/* incoming packet buffers */

udp_Socket *udp_allsocs;

/* IP identification numbers */
static word udp_id;

/* Handler for incoming packets. */
void udp_Handler(in_Header *ip)
{
    udp_Header *up;
    tcp_PseudoHeader ph;
    word len;
    byte *dp;
    udp_Socket *s;
	eth_HwAddress ethAddr;

	len = in_GetHdrlenBytes(ip);
    up = (udp_Header *)((byte *)ip + len);	/* udp segment pointer */
    len = wfix(ip->length) - len;

    /* demux to active sockets */
    for (s = udp_allsocs; s; s = s->next) 
	{
        if ( (s->hisport != 0) &&
             (wfix(up->dstPort) == s->myport) &&
             (wfix(up->srcPort) == s->hisport) &&
             (lfix(ip->source) == s->hisaddr) ) 
			break;
	
		if ( ((s->hisaddr == 0) || (s->hisaddr == INADDR_BROADCAST)) && 
		 	 (wfix(up->dstPort) == s->myport) )
			break;
    }
	
    if (s == NULL) {
		return;
    }

    /* these parameters are used for things other than just checksums */
    ph.src = ip->source;
    ph.dst = ip->destination;
    ph.mbz = 0;
    ph.protocol = UDP_PROTO;
    ph.length = wfix(len);
    if (up->checksum)
	{
		ph.checksum = wfix(checksum(up, len));
		if (checksum(&ph, sizeof(ph)) != 0xffff) {
			sys_printf("Error: Invalid checksum.\n");
	    	return;
		}
    }

	MoveW(((byte *)ip - 8), ethAddr, sizeof(eth_HwAddress));
	sar_addEntry(lfix(ip->source), ethAddr);
	
    /* process user data */
    if ((len -= UDP_LENGTH) > 0) 
	{
		dp = (byte *)(up);
#ifdef TFTP_SERVER_SUPPORT
		//wwzh add for tftp server at 2004-03-18
		gl_dstport = htons(up->srcPort);
#endif

        if (s->dataHandler) 
			s->dataHandler(s, &dp[UDP_LENGTH], len , &ph, up);
		else 
		{
            if (len > s->maxrdatalen ) 
				len = s->maxrdatalen;
	    	Move(&dp[UDP_LENGTH], s->rdata, len);
	    	s->rdatalen = len;
		}
    }
	else
	{
		sys_printf("Error: Invalid length.\n");
	}
}

/*
 * dataHandler
 * 
 * Description: Incoming packet processor. Called by tcp_tick() for
 * 		each incoming UDP packet. Copies the data into an available buffer
 * 		and extracts the source node information from the packet's UDP
 * 		pseudoheader.
 * 		
 * 	Parameters:
 * 		s (in) - Pointer to the UDP socket.
 * 		dp (in) - Pointer to the incoming data buffer.
 * 		len (in) - Length of the data.
 *		ph (in) - Packet pseudoheader.
 *		up (in) - Upcall routine pointer - unused.
*/
void udp_dataHandler (udp_Socket *s, byte *dp, int len, void *ph, void *up)
{
	s = s;
	up = up;

	/* look for a free data buffer */
    if (rxpacket.validData != 0)
	{
        return;         
	}

	if (len > 0) 
	{
    	/* perform sanity check on the packet length */
        if (len < MTU) 
		{
        	/* copy data to buffer, flag buffer as in use */
            sys_memcpy(rxpacket.data, dp, len);
            rxpacket.src = lfix(((tcp_PseudoHeader *)ph)->src);
			rxpacket.length = len;
            rxpacket.validData = 1;

			if (s->appHandler)
				s->appHandler();
      	}
	}
}

int udplib_open(word srcport, word dstport, procref application)
{
	if (gl_srcport)
		udplib_close();
	
	gl_srcport = srcport;
	gl_dstport = dstport;
	if (!udp_open(&listen, gl_srcport, -1, gl_dstport, udp_dataHandler, application))
		return 0;
	return 1;
}

int udplib_close(void)
{
	udp_close(&listen);
	gl_srcport = gl_dstport = 0;
	return 0;
}

/*
 * udp_open
 * 
 * Description: Open the specified UDP port for send/receive. NOTE: under
 *     the current implementation, only one port can bo open at a time;
 *     if this function is called while another port is already open, that
 *	   port will be closed so that the requested port may be opened.
 * Parameters:
 * 	p (in) - Port to open.
 * Returns:
 *  0 if port successfully opened,
 *  1 if error.
*/  
int udp_open(udp_Socket *s, word srcport, longword ina, word dstport, procref dataHandler, procref application)
{
	udp_close(s);
	sys_memset(s, 0, sizeof(udp_Socket));

	s->rdata = s->rddata;
	s->maxrdatalen = udp_MaxBufSize;
	s->ip_type = UDP_PROTO;
	s->myport = srcport;
	
	/* check for broadcast */
	if ((long)(ina) == -1 || !ina)
		sys_memset(s->hisethaddr, 0xff, sizeof(eth_HwAddress));
	else {
		if (!sar_MapIn2Eth(ina, (eth_HwAddress *)&s->hisethaddr[0]))	
		{
			/*sys_printf( "Couldn't resolve it!\n" );*/
			return 0;
		}
	}	

   	s->hisaddr = ina;
	s->hisport = dstport;
	s->dataHandler = dataHandler;
	s->appHandler = application;
	s->next = udp_allsocs;
	udp_allsocs = s;
	return 1; 
}
/*
 * udp_close
 * 
 * Description: Shutdown the currently open port (if any).
 * 
 * Returns:
 * 	0 if successful,
 * 	1 if an error occurred.
*/ 	
int udp_close(udp_Socket *ds)
{
	udp_Socket *s, **sp;

	sp = &udp_allsocs;

	for(;;)
	{
		s = *sp;
		if (s == ds)
		{
			*sp = s->next;
			break;
		}
		if (s == NULL) 
			break;
		sp = &s->next;
	}
    return 1;
}

/*
 * udp_init
 * 
 * Description: Initialize the driver.
 * 
 * Returns:
 * 	0 if successful
*/
int udplib_init(in_HwAddress my_ip)
{
	sin_lclINAddr = my_ip;
	udp_allsocs = NULL;	
	gl_srcport = gl_dstport = 0;
	udp_id = 0;

	return 1;
}

/*
 * udp_deinit
 * 
 * Description: Shut down the driver.
 * 
 * Returns:
 *     0 if successful
*/     
int udplib_deinit(void)
{
	if (gl_srcport)
    	udplib_close();

	gl_srcport = gl_dstport = 0;
	udp_allsocs = NULL;	
	
    return 1;
}

int udp_receive(unsigned int *ipaddress, void *data, int len, int Client)
{
	int ret_length;

GetAnotherPacket:
	if (Client == TRUE)
		ip_Handler();

	/* assume no packets will be waiting */
 	ret_length = 0;

    /* 
	 * check the packet buffers for new data
	 * if more than one packet is waiting, return the oldest one */
	if (rxpacket.validData == 0)
		return 0;

    /* point to the packet we're working on */
    if (rxpacket.length > MTU) 
	{
    	/* whoa - packet is too big!?!?!?!? */
        rxpacket.validData = 0;
		goto GetAnotherPacket;
    }

    /* copy the data into the xfer buffer */
    *ipaddress = rxpacket.src;
    ret_length = rxpacket.length;
	if (ret_length > len)
		ret_length = len;
    sys_memcpy(data, rxpacket.data, rxpacket.length);
    rxpacket.validData = 0;

    return ret_length;     /* success */
}

/*
 * udplib_send
 * 
 * Description: Send the data in the transfer buffer to the node specified in
 *     the transfer buffer's node field.
 *     
 * Returns:
 *     0 if successful,
 *     1 if an error occurred.
*/
int udp_send(unsigned int ipaddr, int len, void * data)
{
	static PacketBuffer sendbuf;          /* where outgoing packets are assembled */

	if (!gl_srcport)
		return (1);     /* D'OHH! Gotta open the port before you send */

	/* set up the packet for transmission */
	sendbuf.validData = 1;
	sendbuf.src = ipaddr;
	sendbuf.length = len;
	sys_memcpy(sendbuf.data, data, len);

	/* this sequence is equivalent to a BSD sendto() call*/
	if (udp_open(&talk, gl_srcport, ipaddr, gl_dstport, udp_dataHandler, NULL)) 
	{
		udp_write(&talk, (unsigned char *)sendbuf.data, len, 0);
		udp_close(&talk);
		return (1);
	}
	return (0);
}

/* udp_write() handles fragmented UDP by assuming it'll be called once for all
 * fragments with no intervening calls.  This is the case in sock_write().
 * 		Handles upto a hair-under 32K datagrams.  Could be made to handle upto
 * a hair-under 64K easily...  wanna Erick?
 * 		Might be possible to test 'offset' for non/zero fewer times to be more
 * efficient.  Might also be more efficient to use the old UDP checksum() call
 * when more_frags is false in the first frag (i.e., not a fragmented dgram).
 * 		Uses _mss to decide splits which defaults to 1400.  Could pack more
 * into an Ethernet packet.*/
#define IP_MF 0x0020               /* more fragments, net ubyte order */

int udp_write(udp_Socket *s, byte *datap, int len, word offset)
{
	/* special pseudo header because need to compute checksum in two 
	 * parts (may not have all of datagram built at once).*/
	tcp_PseudoHeader ph;
	
	struct _pkt 
	{
		in_Header  in;
		udp_Header udp;
		int	   data;
	} *pkt;
	
	byte *dp;
	in_Header *inp;
	udp_Header *udpp = NULL;

	word maxlen;
	int more_frags;

	pkt = (struct _pkt *)sed_FormatPacket(&s->hisethaddr[0], 0x800);

	if (offset) 
	{   
		/* this is not the first fragment data goes right after IP header */
		dp = (byte *) &pkt->udp;
	} 
	else 
	{
		dp = (byte *) &pkt->data;
		udpp = &pkt->udp;

		/* udp header */
		udpp->srcPort = wfix(s->myport);
		udpp->dstPort = wfix(s->hisport);
		udpp->checksum = 0;
		udpp->length = wfix(UDP_LENGTH + len);
	}
	inp = &pkt->in;

	sys_memset(inp, 0, sizeof(in_Header));

	maxlen = ETH_MSS & 0xFFF8;             /* make a multiple of 8 */
	if (!offset) 
		maxlen -= UDP_LENGTH; /* note UDP_LENGTH is 8, so ok */

	if (len > maxlen) 
	{
		len = maxlen;
		more_frags = 1;
	} 
	else 
		more_frags = 0;

	inp->length = wfix(sizeof(in_Header) + (offset ? 0 : UDP_LENGTH) + len);
	MoveW(datap, dp, len);

	/* internet header */
	inp->vht = wfix(0x4500); /* version 4, hdrlen 5, tos 0*/
	
	/* if offset non-zero, then is part of a prev datagram so don't incr ID */
	inp->identification = wfix(offset ? udp_id : ++udp_id);   /* was post inc */
	inp->frag = (offset ? wfix((offset + UDP_LENGTH) >> 3) : 0);
	if (more_frags) 
		inp->frag |= IP_MF;
	inp->ttlProtocol = wfix((250<<8) + UDP_PROTO);
	inp->checksum = 0;
	inp->source = lfix(sin_lclINAddr);
	inp->destination = lfix(s->hisaddr);
	inp->checksum = wfix(~checksum(inp, sizeof(in_Header)));

	/* compute udp checksum if desired */
	if(!offset) 
	{  
		ph.src = inp->source;
		ph.dst = inp->destination;
		ph.mbz = 0;
		ph.protocol = UDP_PROTO;	/* udp */
		ph.length = wfix(wfix(pkt->in.length) - sizeof(in_Header));

		/* can't use since may not have the whole dgram built at once this 
		 * way handles it */
		ph.checksum = wfix(checksum(udpp, wfix(ph.length)));
		udpp->checksum =  wfix(~checksum(&ph, sizeof(ph)));
	}

	sed_Send(wfix(inp->length));

	return (len);
}

