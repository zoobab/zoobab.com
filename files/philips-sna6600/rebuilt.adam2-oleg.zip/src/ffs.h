/*-----------------------------------------------------------------------------*/
/*                                                                             */
/*   Copyright (C) 1999-2003 by Texas Instruments, Inc.  All rights reserved.  */
/*   Copyright (C) 2001-2003 Telogy Networks.	    						   */
/*                                                                             */
/*-----------------------------------------------------------------------------*/

#ifndef FFS
#define FFS

#define FFS_VERSION 0x00

#define FFS_F_DELETE           0x8000
#define FFS_F_BLOCK_ALIGN      0x4000
#define FFS_F_AUTO_EXECUTE     0x2000
#define FFS_F_EXT_FIFLE_SYSTEM 0x1000
#define FFS_F_VOLUME_ID        0x0800
#define FFS_F_LINK             0x0400
#define FFS_F_DIRECTORY        0x0200
#define FFS_F_USER_READ        0x0100
#define FFS_F_USER_WRITE       0x0080
#define FFS_F_USER_EXECUTE     0x0040
#define FFS_F_GROUP_READ       0x0020
#define FFS_F_GROUP_WRITE      0x0010
#define FFS_F_GROUP_EXECUTE    0x0008
#define FFS_F_WORLD_READ       0x0004
#define FFS_F_WORLD_WRITE      0x0002
#define FFS_F_WORLD_EXECUTE    0x0001

#define FFS_ERRS_NO_ERROR              0
#define FFS_ERRS_NO_SUCH_FFS           1
#define FFS_ERRS_NOT_A_VALID_FFS       2
#define FFS_ERRS_SLOT_NOT_ENABLED      3
#define FFS_ERRS_VERSION_NOT_SUPPORTED 4
#define FFS_ERRS_FFS_ALREADY_MOUNTED   5

typedef char cbit16[2];
typedef char cbit8;
typedef char cbit24[3];

typedef struct ffs_sEntry 
                  {
                  cbit16 inode;
                  cbit16 flags;
                  cbit16 mdate;
                  cbit16 mtime;
                  cbit8  uid;
                  cbit8  gid;
                  cbit8  fnlen;
                  cbit24 flen;
                  cbit8  aeo;
                  cbit8  data[1];
                  }ffs_tEntry;

typedef struct fs_sBlock
                 {
                 struct fs_sBlock  *Next;
                 int               Length;
                 char              Data[1];
                 }fs_tBlock;

typedef struct fs_sFileHandle
                 {
                 int        FlashFile;      
                 int        Mode;
                 int        State;
                 int        SeekValue;
                 ffs_tEntry *FlashFileSystemEntry;
                 fs_tBlock  *FSRamBlock; 
                 }fs_tFileHandle;

#define SLOT_BASE     0xbc000000
#define NUM_OF_SLOTS 1

#define FLASH_BASE       	0xb0000000
#if 0
#define MIN_BOOT_BLOCK_SIZE     (128*1024)
#define MIN_ENV_BLOCK_SIZE      (64*1024)
#endif

typedef struct ffs_s 
                 {
                 void *ffs_ptr;
                 int  slot;
                 }ffs_tMountPoint;

/* Initialize calls */

void   ffs_InitFlashFIleSystem(void);

/* File minipulation calls */

FFS_FILE   *ffs_fopen(const char *filename, const char *type);
size_t ffs_fread(void *ptr, size_t size, size_t nitems, FFS_FILE *stream);
size_t ffs_fwrite(const void *ptr, size_t size, size_t nitems, FFS_FILE *stream);
int    ffs_fclose(FFS_FILE *stream);
int    ffs_fseek(FFS_FILE *stream, bit32 offset, int ptrname);
int    ffs_remove(const char *filename);

/* Mounting and unmounting Calls */

int    ffs_AddFileSystem(int slot,void *ffs);
int    ffs_RemoveSlotMount(int slot);

/* Internal ffs.c calls also used by ffs_utils.c */

int    _ffs_hw_isslotenabled(int slot);
void   ffs_RepairFlashFileSystems(int slot);
int    ffs_AddNewSlotMount(int slot);
ffs_tEntry *_ffs_DumpFlashFileSystemEntry(ffs_tEntry *ffse,int show_deleted);
bit16u _ffs_GetBit16Value(char *cbit16);
void   _ffs_PutBit16Value(char *cbit16, bit16u val);
void   _ffs_UpdateBit16Value(char *cbit16, bit16u val);
bit32  _ffs_GetBit24Value(char *cbit24);
void   _ffs_PutBit24Value(char *cbit16, bit32u val);
bit32  _ffs_GetBit32Value(char *cbit32);
void   _ffs_DecodeAndPrintMdate(int mdate);
void   _ffs_DecodeAndPrintMtime(int mtime);
void   _ffs_SplitIntoFirstDirAndRest(char *src,char **d1,char **l1);
ffs_tEntry *_ffs_FindFFSEWithNameInDir(ffs_tEntry *ffs,int inode,char *name);
void   _ffs_xferstream(FFS_FILE *stream,ffs_tEntry *old,ffs_tEntry *new);

#endif
