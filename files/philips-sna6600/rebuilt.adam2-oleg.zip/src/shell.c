/*-----------------------------------------------------------------------------*/
/*                                                                             */
/*   Copyright (C) 1996-2003 by Texas Instruments, Inc.  All rights reserved.  */
/*   Copyright (C) 2001-2003 Telogy Networks, Inc.							   */
/*                                                                             */
/*     IMPORTANT - READ CAREFULLY BEFORE PROCEEDING TO USE SOFTWARE.           */
/*                                                                             */
/*  This document is displayed for you to read prior to using the software     */
/*  and documentation.  By using the software and documentation, or opening    */
/*  the sealed packet containing the software, or proceeding to download the   */
/*  software from a Bulletin Board System(BBS) or a WEB Server, you agree to   */
/*  abide by the following Texas Instruments License Agreement. If you choose  */
/*  not to agree with these provisions, promptly discontinue use of the        */
/*  software and documentation and return the material to the place you        */
/*  obtained it.                                                               */
/*                                                                             */
/*                               *** NOTE ***                                  */
/*                                                                             */
/*  The licensed materials contain MIPS Technologies, Inc. confidential        */
/*  information which is protected by the appropriate MIPS Technologies, Inc.  */
/*  license agreement.  It is your responsibility to comply with these         */
/*  licenses.                                                                  */
/*                                                                             */
/*                   Texas Instruments License Agreement                       */
/*                                                                             */
/*  1. License - Texas Instruments (hereinafter "TI"), grants you a license    */
/*  to use the software program and documentation in this package ("Licensed   */
/*  Materials") for Texas Instruments broadband products.                      */
/*                                                                             */
/*  2. Restrictions - You may not reverse-assemble or reverse-compile the      */
/*  Licensed Materials provided in object code or executable format.  You may  */
/*  not sublicense, transfer, assign, rent, or lease the Licensed Materials    */
/*  or this Agreement without written permission from TI.                      */
/*                                                                             */
/*  3. Copyright - The Licensed Materials are copyrighted. Accordingly, you    */
/*  may either make one copy of the Licensed Materials for backup and/or       */
/*  archival purposes or copy the Licensed Materials to another medium and     */
/*  keep the original Licensed Materials for backup and/or archival purposes.  */
/*                                                                             */
/*  4. Runtime and Applications Software - You may create modified or          */
/*  derivative programs of software identified as Runtime Libraries or         */
/*  Applications Software, which, in source code form, remain subject to this  */
/*  Agreement, but object code versions of such derivative programs are not    */
/*  subject to this Agreement.                                                 */
/*                                                                             */
/*  5. Warranty - TI warrants the media to be free from defects in material    */
/*  and workmanship and that the software will substantially conform to the    */
/*  related documentation for a period of ninety (90) days after the date of   */
/*  your purchase. TI does not warrant that the Licensed Materials will be     */
/*  free from error or will meet your specific requirements.                   */
/*                                                                             */
/*  6. Remedies - If you find defects in the media or that the software does   */
/*  not conform to the enclosed documentation, you may return the Licensed     */
/*  Materials along with the purchase receipt, postage prepaid, to the         */
/*  following address within the warranty period and receive a refund.         */
/*                                                                             */
/*  TEXAS INSTRUMENTS                                                          */
/*  Application Specific Products, MS 8650                                     */
/*  c/o ADAM2 Application Manager                                              */
/*  12500 TI Boulevard                                                         */
/*  Dallas, TX 75243  - U.S.A.                                                 */
/*                                                                             */
/*  7. Limitations - TI makes no warranty or condition, either expressed or    */
/*  implied, including, but not limited to, any implied warranties of          */
/*  merchantability and fitness for a particular purpose, regarding the        */
/*  licensed materials.                                                        */
/*                                                                             */
/*  Neither TI nor any applicable licensor will be liable for any indirect,    */
/*  incidental or consequential damages, including but not limited to loss of  */
/*  profits.                                                                   */
/*                                                                             */
/*  8. Term - The license is effective until terminated.   You may terminate   */
/*  it at any other time by destroying the program together with all copies,   */
/*  modifications and merged portions in any form. It also will terminate if   */
/*  you fail to comply with any term or condition of this Agreement.           */
/*                                                                             */
/*  9. Export Control - The re-export of United States origin software and     */
/*  documentation is subject to the U.S. Export Administration Regulations or  */
/*  your equivalent local regulations. Compliance with such regulations is     */
/*  your responsibility.                                                       */
/*                                                                             */
/*                         *** IMPORTANT NOTICE ***                            */
/*                                                                             */
/*  Texas Instruments (TI) reserves the right to make changes to or to         */
/*  discontinue any semiconductor product or service identified in this        */
/*  publication without notice. TI advises its customers to obtain the latest  */
/*  version of the relevant information to verify, before placing orders,      */
/*  that the information being relied upon is current.                         */
/*                                                                             */
/*  TI warrants performance of its semiconductor products and related          */
/*  software to current specifications in accordance with TI's standard        */
/*  warranty. Testing and other quality control techniques are utilized to     */
/*  the extent TI deems necessary to support this warranty. Unless mandated    */
/*  by government requirements, specific testing of all parameters of each     */
/*  device is not necessarily performed.                                       */
/*                                                                             */
/*  Please be aware that Texas Instruments products are not intended for use   */
/*  in life-support appliances, devices, or systems. Use of a TI product in    */
/*  such applications without the written approval of the appropriate TI       */
/*  officer is prohibited. Certain applications using semiconductor devices    */
/*  may involve potential risks of injury, property damage, or loss of life.   */
/*  In order to minimize these risks, adequate design and operating            */
/*  safeguards should be provided by the customer to minimize inherent or      */
/*  procedural hazards. Inclusion of TI products in such applications is       */
/*  understood to be fully at the risk of the customer using TI devices or     */
/*  systems.                                                                   */
/*                                                                             */
/*  TI assumes no liability for TI applications assistance, customer product   */
/*  design, software performance, or infringement of patents or services       */
/*  described herein. Nor does TI warrant or represent that license, either    */
/*  expressed or implied, is granted under any patent right, copyright, mask   */
/*  work right, or other intellectual property right of TI covering or         */
/*  relating to any combination, machine, or process in which such             */
/*  semiconductor products or services might be or are used.                   */
/*                                                                             */
/*  All company and/or product names are trademarks and/or registered          */
/*  trademarks of their respective manaufacturers.                             */
/*                                                                             */
/*-----------------------------------------------------------------------------*/

#include "_stdio.h"
#include "errors.h"
#include "env.h"
#include "mms.h"
#include "support.h"
#include "avreset.h"
#include "shell.h"
#include "srloader.h"
#include "sio.h"
#include "main.h"
#include "revision.h"
#include "hw.h"
#include "flashop.h"
#ifdef FFS_SUPPORT
#include "files.h"
#include "ffs.h"
#include "ffs_util.h"
#endif /* FFS_SUPPORT */
//#if defined(DHCP_SUPPORT) || defined(FTP_SERVER_SUPPORT) || defined(FTP_CLIENT_SUPPORT) //By Charles addition for Support tftp server 08-13-2004
#if defined(DHCP_SUPPORT) || defined(FTP_SERVER_SUPPORT) || defined(FTP_CLIENT_SUPPORT) || defined(TFTP_SERVER_SUPPORT)
#include "tinyip.h"
#endif

bit32 myatox(char *str,bit32 *num);
void FlushICache();
void FlushDCache();

#define PPM 10000
#define EXP_F 95000000
#define EXP_H 125000000

// by Oleg check added
#ifdef FFS_SUPPORT
#define CurrentWorkingDirectory "�:/emac/"
#endif

#define	NulStr 			""

#if defined(AR5D01) || defined(WA100) || defined(AR5W01)
static bit32u gopc = 0x90010000;
#else
#if defined(ACPEP) || defined(AR7DB) || defined(AR7RD) || defined(AR7WRD)
static bit32u gopc = 0x90020000;
#else
static bit32u gopc = 0x90040000;
#endif /* defined(ACPEP) || defined(AR7DB) || defined(AR7RD) || defined(AR7WRD) */
#endif /* defined(AR5D01) || defined(WA100) || defined(AR5W01) */

static unsigned int sramvector[]={0x80000000,0x80000080,0x80000100,0x80000180,0x80000200};

extern int GetCpuFreq(void);

extern void SetRefClkPll(int v);

typedef struct _CommandInfo
{
	char	*command_str;
	bit32u	(*commandFunction)(int argc, char *argv[]);
	char	*descr_str;
} CommandInfo;

static CommandInfo Adam2Commands[] = {
	{"h/help",	adam2help,	"Displays the commands supported"},
	{"info",    infocmd,    "Displays board information"},
#ifndef ACPEP	
	{"memop",   memop,		"Memory Optimization"},
#if 0
	{"setmfreq",setmfreq,	"sets freq to <req_fullrate_freq>,<req_halfrate_freq>,<freq with -f>"},
#endif
        {"setmfreq",setmfreq,   "configures/dumps the system and cpu frequencies"},	
#endif /* ACPEP */
	{"dm",		dm,			"Dump memory at <address>"},
#if 0
	{"im",		im,			"Inspect memory at <address>"},
#endif
	{"erase",	erasecmd,		"Erase Flash except Adam2 Kernel and Env space"},
	{"printenv",printenvcmd,"Displays Env. Variables"},
	{"setenv",  setenvcmd,	"Sets Env. variable <var> with a value <val>"},
	{"unsetenv",unsetenvcmd,"Unsets the Env. variable <var>"},
	{"fixenv",	fixenv,		"Defragment for Env. space"},
	{"reboot",	rebootcmd,		"Reboot"},
	{"go",		gocommand,	"Loads the image starting at address <mtd1>"},
#ifdef FTP_CLIENT_SUPPORT
	{"ftp",		ftpcmd,		"ftp <net_file> into <local_address>"},
#endif
#ifdef PING_SUPPORT
	{"ping",	pingcmd,	"ping <host> <count>"},
#endif
	{0,			0,			0}
};

void fix_vector_for_linux(void)
{
	unsigned int *ip;
	int i;

	for(i=0;i<5;i++)
	{
		ip=(unsigned int *)sramvector[i];
		*ip++=0x3c1a9400;
		*ip++=0x275a0000|(sramvector[i]&0x0ffff);
		*ip++=0x03400008;
		*ip++=0;
	}
}

void AppCopyVectors(void)
{
	/*Copy vectors to internal ram at 0x80000000 */
	copy_vector(0x80000000);
	copy_vector(0x80000080);
	copy_vector(0x80000100);
	copy_vector(0x80000180);
	copy_vector(0x80000200);

	/*Copy vectors to Dram at 0x94000000, for SEAD emulation  */
#ifndef _AVALANCHE_
	copy_vector(0x94000000);
	copy_vector(0x94000080);
	copy_vector(0x94000100);
	copy_vector(0x94000180);
	copy_vector(0x94000200);

	fix_vector_for_linux();
#endif
}	   

// by Oleg check added
#ifdef FFS_SUPPORT

void ShellAddPathToFileName(char *OutBuf,char *InBuf,char *Path)
{   
	if ((InBuf[0]!='/')&&(InBuf[1]!=':'))
    {
		strcpy(OutBuf,Path);
		strcat(OutBuf,InBuf);
    }
	else
    {
		strcpy(OutBuf,InBuf);
    }  
} 

void ShellAddCWDToFileName(char *OutBuf,char *InBuf)
{
	ShellAddPathToFileName(OutBuf,InBuf,CurrentWorkingDirectory);
}       

#endif

bit32u ShellMain(void)
{
	char InputLine[100];	
	
	GetInputLine(InputLine,sizeof InputLine,"./\\-_~\t@,<>;:?[]{}!#$%^&*()=+|`'\" ");
	
	ShellDoMultiCommand(InputLine);
	return 1;
}

bit32u ShellDoMultiCommand(char *lineptr)
{
	char *nextlineptr;

	SkipSpaces(&lineptr);

	while(*lineptr)
    {
		nextlineptr=lineptr;
		while((*nextlineptr)&&((isalnum(*nextlineptr))||
							   (IsCharMember(*nextlineptr,"./\\-_~\t@,<>:?[]{}!#$%^&*()=+`'\" "))))
		{
			nextlineptr++;
		}
		if (*nextlineptr=='|')
		{
			//sys_printf("%s: Pipe not supported yet\n",lineptr);
			return(6);
		}
		if ((*nextlineptr==';')||(*nextlineptr=='|'))
		{
			*nextlineptr++=0;
		}
		if (lineptr==nextlineptr)
			return(1);
		ShellDoSingleCommand(lineptr);
		PrintfRestore();
		lineptr=nextlineptr;
    }
	return(0);
}

bit32u ShellDoSingleCommand(char *lineptr)
{
#ifdef FFS_SUPPORT
	char CommandFileName[80];
#endif
	
	char RequestedCommand[80],*argv[10];
	int i,argc;
	
	IfFlowEnable();
	AppCopyVectors();
	SkipSpaces(&lineptr);
	GetStringField(&lineptr,RequestedCommand,sizeof RequestedCommand,"./\\-_~:?");
	if ((*lineptr)&&(!IsCharMember(*lineptr," \t")))
	{
		sys_printf("%s%s: Syntax Error!\n",RequestedCommand,lineptr);
		for(i=0;i<strlen(RequestedCommand);i++) 
			sys_printf(" ");
		sys_printf("^\n");
		return(1);
    }
	SkipSpaces(&lineptr);   

	/*Create argc,argv and the environment */

	argv[0]=RequestedCommand;
	argc=1;
	while((*lineptr)&&(argc<10))
	{
		SkipSpaces(&lineptr);   
		if ((*lineptr)&&(argc<10))
		{
			argv[argc++]=lineptr;
			while((*lineptr!='\t')&&(*lineptr!=' ')&&(*lineptr!=0))
				lineptr++;
			if (*lineptr)
				*lineptr++=0;
		}    
    } 
	
#ifdef FFS_SUPPORT
	if (strcmp(RequestedCommand,"df")==0)
    {
    	ffs_ReportFFSInfo();
    	return(0);
    }

  	if (strcmp(RequestedCommand,"_Format")==0)
    	return(_ffs_FormatRootFlashDisk(argc,argv));

  	if (strcmp(RequestedCommand,"dfs")==0)
    	return(ffs_dumpfilesystem(argc,argv));  
#endif /* FFS_SUPPORT */
	
	init_env();
	
	ResetMMS();

	i = 0;

	while (Adam2Commands[i].command_str != NULL)
	{
		if ( (strcmp(RequestedCommand, Adam2Commands[i].command_str) == 0) || 
			 (((strcmp(RequestedCommand, "h") == 0) || 
			   (strcmp(RequestedCommand, "help") == 0)) && (i == 0)) )
			return(Adam2Commands[i].commandFunction(argc,argv));
		i++;
	}

#ifdef FFS_SUPPORT
	ShellAddPathToFileName(CommandFileName,RequestedCommand,"/bin/");
	if (!IsFileExist(CommandFileName,"x")) 
    {        
		ShellAddCWDToFileName(CommandFileName,RequestedCommand);
		if (!IsFileExist(CommandFileName,"x"))
		{
			sys_printf("%s: Command not Found!\n",CommandFileName);
			return(2);
		}
    }  
	argv[0]=CommandFileName;
	gopc=progloader(argc,argv); 
    FlushICache();
    FlushDCache();
	if (gopc)
		ExeAt(gopc,argc,argv,(char **)env_vars);
	return(0);	
#else
	sys_printf("%s: Command not Found!\n", RequestedCommand);
	return(2);
#endif /* FFS_SUPPORT */
}

bit32u dm(int argc,char *argv[])
{      
	static bit32u DmAdrStart = 0xb4000000;
	bit32 badr,eadr,ic,j,iTmp;
	char cTmp[17],cTmp1;
	bit32u adb,ade,i;

	/* Need to deal with ffffffff0 - rollover */  
                 
	badr=DmAdrStart;
	if (argc>1)        
	{
		if (!myatox(argv[1],&badr))
		{
			sys_printf("Invalid hex address\n");
			return(EC_DUMP_MEMORY+EC_INVALID_HEX_NUMBER);
		} 
    }  
	eadr=badr+0x7f;
	if (argc>2)    
	{
		if (!myatox(argv[2],&eadr))
		{
			sys_printf("Invalid Range\n");
			return(EC_DUMP_MEMORY+EC_INVALID_HEX_NUMBER);
		}
	} 
    FlushDCache();
	badr&=~3;
	eadr&=~3;   
	adb=badr&~0xf;
	ade=eadr|0xf; 
	cTmp[16]=0;
	for(i=adb;i<=ade;i+=4)
    {
		if(SioInCharCheck(&cTmp1))
		{
			if (cTmp1==((char)0x1b)) 
			{
				sys_printf("\nUser Abort\n");
				return(EC_DUMP_MEMORY+EC_USER_ABORT);
			}
		} 
		ic=i&0x0f;
		if ((i&0x0f)==0)
			sys_printf("\n%08x:",i);
		
		if ((i>=badr)&&(i<=eadr))
		{                         /*  These locations lock up the config bus   */
			if (BadAddress(i))
			{  
				sys_printf(" ACK_ERR_");
				cTmp[ic++]=' ';
				cTmp[ic++]=' ';
				cTmp[ic++]=' ';
				cTmp[ic++]=' ';
			}
			else 
			{    
				iTmp=*((bit32*)i);
				sys_printf(" %08x",iTmp); 
				cTmp[ic]=(char)(iTmp);
				cTmp[ic+1]=(char)(iTmp>>8);
				cTmp[ic+2]=(char)(iTmp>>16);
				cTmp[ic+3]=(char)(iTmp>>24);
				for(j=0;j<4;j++,ic++)
				{
					if (!cTmp[ic]) cTmp[ic]='.';
					if ((!isalnum(cTmp[ic]))&&
					  (!IsCharMember(cTmp[ic],"~!@#$%^&*()_+|}{\":?><`-=[]\\;',./ ")))
					cTmp[ic]='.';
				} 
			}   
			DmAdrStart=i+4;     
		}
		else                            
		{
			sys_printf(" XXXXXXXX"); 
			cTmp[ic++]=' ';
			cTmp[ic++]=' ';
			cTmp[ic++]=' ';
			cTmp[ic++]=' ';
		}
		if ((i&0x0f)==0xc) sys_printf(" - %s",cTmp);  
	}   
	sys_printf("\n");  
	return(EC_NO_ERRORS);  
}

#if 0
bit32u im(int argc,char *argv[])
{                 
	static bit32u ImAdrStart = 0xb4000000;
	bit32 badr,tmp;
	int done,new,chars;
	char achar;

	badr=ImAdrStart;
	if (argc>1)
	{
		if (!myatox(argv[1],&badr))
		{
			sys_printf("Invalid hex address\n");
			return(EC_INSPECT_MEMORY+EC_INVALID_HEX_NUMBER);
		}
	}
	if (argc>2)
	{
		sys_printf("Invalid command line\n");
		return(EC_INSPECT_MEMORY+EC_INCORRECT_ARGUMENTS);
	}
    FlushDCache();
	done=FALSE;
	badr&=~3;
	do 
	{ 
		sys_printf("%08x: ",badr);
		if (BadAddress(badr))
		{
			sys_printf("No Ack ");
		} 
		else
		{ 
			tmp = MEM_READ(badr);
			sys_printf("%08x ",tmp);
		}
		ImAdrStart=badr;
		tmp=0;
		chars=0;
		new=FALSE;
		do
		{ 
			achar=SioInChar();
			switch(achar)
			{
				case 0x8: 
					if(chars)
					{
						sys_printf("\010 \010"); chars--; tmp>>=4;}
						break;
				case ' ': 
					if (chars)
					{
						MEM_WRITE(badr,tmp); 
					}
					badr+=4;
					new=TRUE;
					break;
				case '-': 
					if (chars)
					{
						MEM_WRITE(badr,tmp);
					}
					badr-=4;
					new=TRUE;
					break;
				case 0xd:
				case 0xa: 
					if (chars)
					{
						MEM_WRITE(badr,tmp);
					}
					done=TRUE;
					new=TRUE;
					break;
				default:  
					if (isxdigit(achar))
					{
						sys_printf("%c",achar);
						tmp<<=4;
						chars++;
						if (achar<='9')
							tmp+=achar-'0';
						else
							tmp+=(achar&0x5f)-'A'+10;
					}
					break;
			}
		}while(!new);
		sys_printf("\n");  
	}while(!done);
	return(EC_NO_ERRORS);
}   
#endif
   
bit32 myatox(char *str,bit32 *num)
{
	bit32 tmp;
  
	if (*str++ != '0')
		return(FALSE);

	if (*str++ != 'x')
		return(FALSE);

	tmp=0;
	while(*str)
    {
		if (isxdigit(*str))
		{
			tmp<<=4;
			if (*str<='9')
				tmp+=*str-'0';
			else
				tmp+=(*str&0x5f)-'A'+10;
		}
		else if (*str == ',')
		{
			break;
		}
		else
		{
			return(FALSE);
		}
		str++;
    }
	*num=tmp;
	return(TRUE);
}

int BadAddress(bit32u adr)
{
	return(FALSE);
}

#ifdef BATCH_SREC_SUPPORT

#define BATCH_FILE_DOES_NOT_EXIST 1
#define BATCH_FILE_NOT_A_BATCH_FILE 2

char  batchbuffer[2048];
char *batchcurrentptr;
int   batchcurrentline;
int   batchcurrentlen;
char batbuff[200];

void initbatchreadline(void)
  {
  batchcurrentlen=0;
  batchcurrentline=0;
  }

int batchreadline(FFS_FILE *fil,char *buf,int len)
  {
  int rlen;

  rlen=0;
  if (len==0)
    return(0);
  while(1)
    {
    if (batchcurrentlen==0)
      {
      batchcurrentlen=fread(batchbuffer,1,sizeof batchbuffer,fil);
      if (batchcurrentlen==0)
        {
        if (rlen)
          {
          *buf=0;
          return(rlen);
          }
        return(-1);
        }
      batchcurrentptr=batchbuffer;
      }
    if (batchcurrentlen)
      {
      if (*batchcurrentptr=='\n')
        {
        *buf=0;
        batchcurrentptr++;
        batchcurrentlen--;
        return(rlen);
        }
       else
        {
        if ((len>1)&&(*batchcurrentptr!='\r'))
          {
          *buf++=*batchcurrentptr++;
          len--;
          }
         else
          batchcurrentptr++;
        rlen++;
        batchcurrentlen--;
        }
      }
     else
      {
      *buf=0;
      batchcurrentptr++;
      batchcurrentlen--;
      return(rlen);
      }
    }
  }

int batch(char *filename)
  {
  FFS_FILE *fp;
  char achar;
  int rlen,i;

  fp=fopen(filename,"r");
  if (!fp) return(BATCH_FILE_DOES_NOT_EXIST);
  achar=fgetc(fp);
  if (achar!='#') return(BATCH_FILE_NOT_A_BATCH_FILE);
  achar=fgetc(fp);
  if (achar!='!') return(BATCH_FILE_NOT_A_BATCH_FILE);
  initbatchreadline();
  batchreadline(fp,batbuff,sizeof batbuff);
  while((rlen=batchreadline(fp,batbuff,sizeof batbuff))!=-1)
    {
    for(i=0;i<strlen(batbuff);i++) 
      {
      if (batbuff[i]=='#') 
        batbuff[i]=0;
      }
    if (strlen(batbuff))
      ShellDoMultiCommand(batbuff);
    }
  fclose(fp);
  return(0);
  }
#endif /* BATCH_SREC_SUPPORT */

int executeProgram(int resetFlag, bit32 address, int argc, char *argv[])
{
	AppCopyVectors();
	init_env();
	if (resetFlag) 
	{
#if defined(FTP_SERVER_SUPPORT) || defined(DHCP_SUPPORT) || defined(TFTP_SERVER_SUPPORT)
		/* This is required, as ADAM2 kept VMAC in initialized state, 
		 * which caused kernel panics in linux kernel VMAC. */	
		if (ip_initialized == 1)
			ip_deinit();
#endif /* defined(FTP_SERVER_SUPPORT) || defined(DHCP_SUPPORT) || defined(TFTP_SERVER_SUPPORT) */
		ResetMMS();
	}
	
	return(ExeAt(address,argc,argv,(char **)env_vars));
}
		
bit32u gocommand(int argc,char *argv[])
{
	char *pp;
	bit32 addr;

	pp=sys_getenv("mtd1");
	if (!pp)
	{
		sys_printf("mtd1 Variable not set, defaulting to %x.\n", gopc);
		addr = gopc;
	}
	else if (!myatox(pp, &addr))
	{
		sys_printf("Invalid hex address\n");
		return(EC_INVALID_HEX_NUMBER);
	}

	gopc = imageloader(addr);

	if (gopc)
		return (executeProgram(1, gopc, argc, argv));

#ifdef(FTP_SERVER_SUPPORT) || defined(TFTP_SERVER_SUPPORT)

//wwzh add for kernel crash
	red_led();	//By Charles comment for coment 08-13-2004

	crashFlag = CRASH_KERNEL;
#endif
	return(0);
}

#ifndef ACPEP
void setmfreq_help(void)
{
#if defined(AR7DB) || defined(AR7RD) || defined(AR7WRD)
    sys_printf("Usage: setmfreq [-d] [-s sys_freq, in MHz] [cpu_freq, in MHz]\n");
#else
	sys_printf("Usage: setmfreq [-f freq]\n");              
	sys_printf("       f - Sets the frequency to 'freq'\n");
#endif
}

bit32u setmfreq(int argc,char *argv[])
{
#if defined(AR7DB) || defined(AR7RD) || defined(AR7WRD)
	int dbg_opt = FALSE;
	int cpuf_opt = FALSE;
	int sysf_opt = FALSE;
	int ii;
	bit32u sysf = -1, cpuf = -1;
	if (argc < 2 || argc > 5) {
		goto cfgcpuf_options;
	}
	for (ii = 1; ii < argc; ii++) {
		switch(*argv[ii]) {
			case '-':
				if ((argv[ii] + 1) == NULL) {
					goto cfgcpuf_options;
				} else if (*(argv[ii] + 1) == 's') {
					if (sysf_opt == FALSE && ii + 1 < argc) {
						sysf_opt = TRUE;
						sysf = MHZ((int)strtol(argv[++ii], NULL, 10));
						continue;
					} else
						goto cfgcpuf_options;
				} else if (*(argv[ii] + 1) == 'd') {
					if (dbg_opt == FALSE) {
						dbg_opt = TRUE;
						goto cfgcpuf_start;
					} else
						goto cfgcpuf_options;
				} else
					goto cfgcpuf_options;
		} /* switch */
		if (cpuf_opt == FALSE) {
			cpuf_opt = TRUE;
			cpuf = MHZ((int)strtol(argv[ii], NULL, 10));
		} else
			goto cfgcpuf_options;
	} /* for */
cfgcpuf_start:
	cfg_cpufreq(sysf, cpuf, dbg_opt);
	return 0;
cfgcpuf_options:
	setmfreq_help();
	return -1;
	
#else /* AR7DB | AR7RD | AR7WRD */
	
	bit32u multi,cpufreq,i,nativefreq,newreq,exp_f,exp_h,divider;
	char *cp,sbuf[30];

	multi = 1;
	exp_f=(cp=sys_getenv("req_fullrate_freq"))?atoul(cp):EXP_F;
	exp_h=(cp=sys_getenv("req_halfrate_freq"))?atoul(cp):EXP_H;

	if ((argc > 3) || (argc == 2))
	{
		setmfreq_help();
		return (EC_INCORRECT_ARGUMENTS);
	}
		
	if (argc == 3)
	{
		cp=argv[1];
		if ((strcmp(argv[1], "-f")) == 0)
		{
			exp_f=atoul(argv[2]);
			exp_h=exp_f;
		}
		else
		{
			setmfreq_help();
			return (EC_INCORRECT_ARGUMENTS);
		}
	}

	cpufreq=GetCpuFreq();

	cpufreq+=(PPM/2);
	cpufreq/=PPM;
	cpufreq*=PPM;
	sys_printf("Set CPU frequency");
	sys_printf(" from %d to ",cpufreq);
	
	nativefreq=cpufreq;

	/* Get the divider */
	divider=(SCLKCR_DIV&0xf)+1;
	nativefreq*=divider;

	/* Get the multiplier */
	if ((BOOTCR&(1<<5))==0) /* If PLL */
	{
		multi=((SCLKCR_MUL>>12)&0xf)+1;
		nativefreq/=multi;
	}

	sys_sprintf(sbuf,"%d",nativefreq);
	sys_setenv("REFCLK",sbuf);

	newreq=(EMIF_REV&0x40000000)?exp_f:exp_h;

	for(i=1;(i*nativefreq)<=newreq;i++)
	{
	}
	i--;

	EMIF_DRAMCTL|= 0x80000000;
	SetRefClkPll(i-1);
	EMIF_DRAMCTL&=~0x80000000;
	
	cpufreq=GetCpuFreq();	
	sys_sprintf(sbuf,"%d",cpufreq);	
	sys_setenv("cpufrequency",sbuf);

	cpufreq+=(PPM/2);
	cpufreq/=PPM;
	cpufreq*=PPM;
	sys_printf("%d.\n",cpufreq);
	multi=(SCLKCR_MUL>>12)&0xf;
	return(0);
#endif /* AR7DB | AR7RD | AR7WRD */	
}
#endif /* ACPEP	*/

bit32u printenvcmd(int argc,char *argv[])
{
	int i;
	char *cp,*cp2;

	for(i=0;i<MAX_ENV_ENTRY;i++)
    {
		cp=sys_getienv(i);
		if (cp)
		{
			cp2=sys_getenv(cp);
			if (!cp2) 
				cp2 = NulStr;
			sys_printf("%-20s  %s\n", cp, cp2);
		}
    }
	return(0);
}

bit32u setenvcmd(int argc,char *argv[])
{
	int sts,i;
	char valu[120];

	sts=7;
	if (argc>1)
	{
		valu[0]=0;
		for(i=2;i<argc;i++)
		{
			if (strlen(valu)) 
				strcat(valu," ");
			strcat(valu,argv[i]);
		}
		sts=sys_setenv(argv[1],valu);
	}
	if (sts) 
		sys_printf("%s: Error(%d) occured, varible not set!\n",argv[0],sts);
	return(sts);
}

bit32u unsetenvcmd(int argc,char *argv[])
{
	int sts;

	sts=7;
	if (argc>1)
	{
		sts=sys_unsetenv(argv[1]);
    }
	if (sts) 
		sys_printf("%s: Error(%d) occured, varible not set!\n",argv[0],sts);
	return(sts);
}

struct env_s
{
	char var[124];
	char val[124];
	int  evalid;
}env[MAX_ENV_ENTRY];

int buildenvtab(void)
{
	int i,j;
	char *cp,*cp2;

	for(i=0;i<MAX_ENV_ENTRY;i++)
		env[i].evalid=FALSE;
	for(i=0,j=0;(i<MAX_ENV_ENTRY)&&(j<MAX_ENV_ENTRY);i++)
    {
		cp=sys_getienv(i);
		if (!cp)
			continue;

		cp2=sys_getenv(cp);
#ifndef DHCP_SUPPORT
		if ( !cp2 || (!strlen(cp2) && (strcmp(cp, "autoload") != 0)) ) 
#else
		if ( !cp2 || (!strlen(cp2) && 
			(strcmp(cp, "autoload") != 0) && (strcmp(cp, "dhcp") != 0) &&
			 strcmp(cp, "crash") != 0) ) 
#endif
			continue;
		strcpy(env[j].var,cp);
		strcpy(env[j].val,cp2);
		env[j].evalid=TRUE;
		j++;
    }
	return(0);
}

int writeenvtab(void)
{
	bit32u i,blocksize;
	bit8u *pdata;
	bit8u *pdst;

	blocksize=FWBGetBlockSize(CS0_BASE+CS0_SIZE-4);
	if (blocksize==0)
	{
		sys_printf("Invalid block size reported\n");
		return(0);
	}
	
	if (blocksize<MIN_ENV_BLOCK_SIZE) 
		blocksize=MIN_ENV_BLOCK_SIZE;

#if 0	
	/* Determine how much is used */
	for(i=0,cp=((bit8u *)(CS0_BASE+CS0_SIZE-CFGMAN_MTD_OFFSET-1));(i<blocksize)&(*cp==0x0ff);i++,cp--) {}
  
	sys_printf("Free = %8d, Used = %8d\n",i,blocksize-i);
	sys_printf("Compressing Environment.\n");
#endif

	/* create a buffer to hold the configman data (config.xml) */
	pdata=sys_malloc(CFGMAN_MTD_SIZE);
	if(!pdata) return 0;
	
	/* save the configman data */
	sys_memcpy(pdata,(void *)(CS0_BASE+CS0_SIZE-blocksize+CFGMAN_MTD_OFFSET), CFGMAN_MTD_SIZE);
	
	/* erase the entire region (env var & configman data) */
	FWBErase(CS0_BASE+CS0_SIZE-blocksize,blocksize,0);

	/* TODO: Do I need to open the flash device? */
	/* restore the configman data */
	pdst=(bit8u *)(CS0_BASE+CS0_SIZE-blocksize+CFGMAN_MTD_OFFSET);
	if( !FWBOpen((bit32u)pdst) )
		sys_printf("ERROR: Could not open flash for write at 0x%x.\n", pdst);
	WriteToFlash(pdst, pdata, CFGMAN_MTD_SIZE);
	if( !FWBClose() )
		sys_printf("ERROR: Could not close flash\n");

	sys_free(pdata);

	/* restore the env vars */
	for(i=0;i<MAX_ENV_ENTRY;i++)
	{
		if (env[i].evalid)
		{
			sys_setenv(env[i].var,env[i].val);
		}
	}
	return(0);
}

bit32u fixenv(int argc,char *argv[])
{
	buildenvtab();
	writeenvtab();
	return(0);
}

bit32u rebootcmd(int argc,char *argv[])
{
	reboot();
	return(0);
}

bit32u erase(bit32 start, bit32u end)
{
	bit32u blocksize;
	bit32u base, size;
	
	if ((blocksize = FWBGetBlockSize(start)) == 0)
	{
		return(EC_INVALID_HEX_NUMBER);
	}
		
	if ((start & (blocksize-1)) != 0)
		base = (start + (blocksize - 1)) | (~(blocksize-1));
	else
		base = start;

	if ((end & (blocksize-1)) != 0)
		size = (end + (blocksize - 1)) | (~(blocksize-1));
	else
		size = end;
	size -= base;
	
	sys_printf("Erasing from 0x%x to 0x%x.\n", base, (base+size));
	if (!FWBErase(base, size, 1))
    {
		sys_printf("\nFormatting Flash disk Failed!");
		return(1);
    }
	sys_printf("\nErase Successful.\n");
    return(0);
}

bit32u erasecmd(int argc,char *argv[])
{
	bit32u bootblocksize, envblocksize;
	int i;
	bit32 start, end;

	bootblocksize=FWBGetBlockSize(CS0_BASE);
	if (bootblocksize<MIN_BOOT_BLOCK_SIZE) 
		bootblocksize=MIN_BOOT_BLOCK_SIZE;

	envblocksize=FWBGetBlockSize(CS0_BASE + CS0_SIZE - 1);
	if (envblocksize<MIN_ENV_BLOCK_SIZE) 
		envblocksize=MIN_ENV_BLOCK_SIZE;

	i = getflashsize(CS0_BASE, CS0_SIZE)/(1024 * 1024);
	sys_printf("Calculated Flash size: %d Mbytes\n",i);

	start = CS0_BASE + bootblocksize;
	end = start + ((1024 * 1024 * i) - (bootblocksize + envblocksize));

	if (argc == 3)
	{
		if ((!myatox(argv[1], &start)) || (!myatox(argv[2], &end)))
		{
			sys_printf("Invalid hex address\n");
			return(EC_INVALID_HEX_NUMBER);
		}
		
		start &= 0x1FFFFFFF;
		start |= 0xA0000000;
		
		end &= 0x1FFFFFFF;
		end |= 0xA0000000;
	}

    return(erase(start, end));
}

int calparam(int cpufreq,char *str,int req_tim,int max_bit)
{
	int i,mm,rv,period;

	req_tim+=2;
	cpufreq/=100;
	req_tim*=100;
	period=1000000000/cpufreq;
	

	for(i=0,mm=1;i<max_bit;i++,mm<<=1) {}

	rv=0;
	while(req_tim)
	{
		rv++;
		if (req_tim>period)
			req_tim-=period;
		else
			req_tim=0;
		if (rv>mm) 
			rv=mm;
	}
	if (rv) 
		rv--;

	return(rv);
}

void AsyncOp(int cpufreq,int Rsetup,int Rstrobe,int Rhold,int Wsetup,int Wstrobe,int Whold,int RWta,int regadr)
{
	bit32u Wstval, Rstval, Wsuval, Rsuval, Whlval, Rhlval, CSVal, TAval, *rp;

	rp=(bit32u *)regadr;
	Wstrobe=150-5;      /*Access less setup*/
	Rstrobe=Wstrobe;
	Wsetup=5;           /*Setup*/
	Rsetup=Wsetup;
	Whold=15;           /*Output disable/hold*/
	Rhold=Whold;
	RWta=5;             /*CS to CS*/

	Wsuval=calparam(cpufreq,"Wsu",Wsetup,4);
	Wstval=calparam(cpufreq,"Wstrobe",Wstrobe,6);
	Whlval=calparam(cpufreq,"Wh",Whold,3);
	Rsuval=calparam(cpufreq,"Rsu",Rsetup,4);
	Rstval=calparam(cpufreq,"Rstrobe",Rstrobe,6);
	Rhlval=calparam(cpufreq,"Rh",Rhold,3);
	TAval =calparam(cpufreq,"ta",RWta,2);

	CSVal=(Wsuval<<26)|(Wstval<<20)|(Whlval<<17)|(Rsuval<<13)|(Rstval<<7)|(Rhlval<<4)|(TAval<<2);

	CSVal|=(*rp&0xc0000003);
	*rp=CSVal;
}

void SdramOp(int cpufreq,int refresh_rate)
{
	bit32u refresh;

	if (cpufreq<=(125000000/2))
	{
		EMIF_DRAMCTL&=~EMIF_DRAMCTL_CL3_BIT;
	}
	else
	{
		EMIF_DRAMCTL|=EMIF_DRAMCTL_CL3_BIT;
	}
	
	refresh=((cpufreq/10000)*refresh_rate)/1000;
	EMIF_REFRESH=refresh;
}

bit32u memop(int argc,char *argv[])
{
	bit32u cpufreq;
	char *cp;

	cpufreq = (cp = sys_getenv("cpufrequency")) ? atoul(cp) : 20000000;

	if (argc == 3 && ((strcmp(argv[1], "-f")) == 0))
	{
		cpufreq = atoul(argv[2]);
	}
	else if (argc > 1)
	{
		sys_printf("\nError.\nUsage: %s [-f freq]\n", argv[0]);
		sys_printf("       f - Optimize to 'freq' in Hz\n");
		return(1);
	}

	if ((cpufreq > 300000000) || (cpufreq < 1000000))
    {
		sys_printf("Frequency out of rang\n");
		return(1);
    }
	sys_printf("Memory optimization ");

	if ((EMIF_REV&0x40000000)==0)
		cpufreq/=2;  
	/*sys_printf("\n\nEMIF_REV =0x%x , EMIF_BASE = 0x%x , cpufreq = %d\n\n",EMIF_REV,EMIF_BASE,cpufreq);//By Charles addition*/
	AsyncOp(cpufreq,5,145,15,5,145,15,5,EMIF_BASE+0x10);
	AsyncOp(cpufreq,5,145,15,5,145,15,5,EMIF_BASE+0x14);
	AsyncOp(cpufreq,5,145,15,5,145,15,5,EMIF_BASE+0x18);
	AsyncOp(cpufreq,5,145,15,5,145,15,5,EMIF_BASE+0x1c);
	SdramOp(cpufreq,78);
	sys_printf("Complete!\n");
	return(0);
}

//#if defined(FTP_SERVER_SUPPORT) || defined(FTP_CLIENT_SUPPORT) || defined(DHCP_SUPPORT)	//By Charles addition for Support tftp server 08-13-2004
#if defined(FTP_SERVER_SUPPORT) || defined(FTP_CLIENT_SUPPORT) || defined(DHCP_SUPPORT) || defined(TFTP_SERVER_SUPPORT)
eth_HwAddress sed_lclEthAddr;
eth_HwAddress sed_ethBcastAddr;

in_HwAddress  sin_lclINAddr;
in_HwAddress  net_Gateway;
in_HwAddress  net_IpMask;

bit32u rtim;
unsigned int av_cpufreq;
unsigned int ticdiv;

int my_getenv(char *val, char *envvar, char *prepend)
{
	char *cp = NULL;

	cp = sys_getenv(envvar);

	if (!cp)
		return(FALSE);

	strcpy(val, prepend);
	strcat(val, cp);
	return(TRUE);
}

int convert2num(char *str, bit32u *val)
{
 bit32u tmpval = 0;
 int i, j;
 char *dp, anum[6];

 while ((*str ==' ') || (*str == '\t')) str++;

 for (i=0; i<4; i++)
 { 
  for (j=0, dp=anum; ((*str >= '0')&&(*str <= '9'))&&(j < (sizeof anum)); j++)
	*dp++ = *str++;
  *dp = 0;
  if (strlen(anum) == 0) return(FALSE);  
  if (i != 3)
  {
   if (*str != '.') return(FALSE); else str++;
  }
  tmpval = (tmpval << 8) | (atol(anum) & 0x0ff);
 }

 if (*str) return(FALSE);
 *val = tmpval;
 return(TRUE);
}
#endif /* defined(FTP_SERVER_SUPPORT) || defined(FTP_CLIENT_SUPPORT)|| defined(DHCP_SUPPORT) || defined(TFTP_SERVER_SUPPORT) */

void WriteToFlash(UINT8 *pDst, UINT8 *pSrc, UINT32 NumBytes)
{
	static UINT32 TotalBytes = 0;

	while (NumBytes--)
	{
		if ((TotalBytes++ % INDICATE_WRITE) == 0 )
			sys_printf(".");
		
		if (!FWBWriteByte((UINT32)pDst++, (bit8)*pSrc++) )
		{
			sys_printf("ERROR: Flash write aborted %x\n", (int)pDst);
			break;
		}
	}
}

#ifdef FTP_CLIENT_SUPPORT

extern int datainbound;

static bit32 DstAddr;

static char remote_dir[80];
static int tlen;

void ftp_usage(char *str)
{
  	sys_printf("Usage: %s [-bp] net_file local_address\n", str);
  	sys_printf("       b              - block aligned flash address type\n");
  	sys_printf("       p              - prompt and set remote_pass from password\n");
  	sys_printf("       net_file       - remote file name, overrides remote_dir if\n");
  	sys_printf("                        net_file contains directory delimiters.\n");
  	sys_printf("       local_address  - flash local address\n");
  	sys_printf("\n");
  	sys_printf("       environment variable 'my_ipaddress'  	 - IP address of this system, EMACA\n");
  	sys_printf("       environment variable 'maca      			 - Ethernet MAC address, EMACA\n");
  	sys_printf("       environment variable 'gateway'       	 - Optional gateway address\n");
  	sys_printf("       environment variable 'ipmask'  			 - Optional IP mask\n");
  	sys_printf("       environment variable 'ftp_remote_ipaddress- IP address of FTP server\n");
  	sys_printf("       environment variable 'remote_user'		 - User ID on remote system\n");
  	sys_printf("       environment variable 'remote_pass'		 - Password on remote system (see -p above)\n");
  	sys_printf("       environment variable 'remote_dir' 		 - Optional remote directory for files\n");
}

void GotData(tcp_Socket *s, byte *dp, int len, int state)
{
  	switch (state)
  	{
    	case SOPEN:
		if (!FWBOpen(DstAddr))
			sys_printf("ERROR: Could not open flash for write at Address 0x%x.\n", DstAddr);
		datainbound = TRUE;
		break;
		
    	case SDATA: 
            if ((dp) && (len))
            {
				WriteToFlash((UINT8 *)DstAddr, (UINT8 *)dp, len);
                tlen += len;
				DstAddr += len;
            }
            break;
				  
    	case SCLOSE:  
            if (tlen)
			{
				if (!FWBClose())
        			sys_printf("ERROR: Could not close flash block, tlen = %d\n", tlen);
            }
            tlen = 0;
            datainbound = FALSE;
            break;
			
    	case SABORT:  
            if (tlen)
			{
				if (!FWBClose())
        			sys_printf("ERROR: Could not close flash block, tlen = %d\n", tlen);
            }
            tlen = 0;
            datainbound = FALSE;
            break;
			
    	default:
            break;
    }
}

bit32u ftpcmd(int argc,char *argv[])
{
	bit32u my_ipval, his_ipval;
	char sSrcFile[80];
	char env_setting[80]; /* Generic place holder */
	char *cp, *start_cp, *end_cp;
	int block_align = FALSE;
	bit32u newAddr, blocksize;
	char  remote_user[80];
	char  remote_pass[80];
	char  remote_passde[80];
	char  rdir[80];
	char  scratch[80];
	char  tmpethadr[sizeof(eth_HwAddress)];
	int i;	

	if (argc < 2 || argc > 4)
	{
		sys_printf("Error: Invalid number of arguments.\n");
		ftp_usage(argv[0]);
		return(1);
	}

	i = 1;	
	if (argc == 2)
	{
	   	if (strcmp(argv[1], "-p") == 0)
			return(newpass());
		else
		{
			sys_printf("Error: Invalid option.\n");
			ftp_usage(argv[0]);
			return(1);
		}

	}
	if (argc == 4)
	{
		if (strcmp(argv[i], "-b") != 0)
		{
			sys_printf("Error: Invalid option.\n");
			ftp_usage(argv[0]);
			return(1);
		}
		block_align = TRUE;
		i++;
	}

#ifdef DHCP_SUPPORT
	if (ip_initialized == 1)
		ip_deinit();
	if (ip_init() == 1)
	{
		sys_printf("Error: ip_init failed.\n");
		return(1);
	}
#else
	rtim = t_get();
	av_cpufreq = (cp = sys_getenv("cpufrequency")) ? atoul(cp) : 125000000;
  	ticdiv = av_cpufreq / 2000;

	emacbase = EMACA_BASE;
	
	net_IpMask = 0;
  	net_Gateway = 0;
#endif

  	datainbound = FALSE;

	strcpy(sSrcFile, argv[i]);
	i++;

	if (!myatox(argv[i], &DstAddr) || !sSrcFile[0])
	{
		sys_printf("Error: Invalid Source/Destination Files.\n");
		ftp_usage(argv[0]);
		return(1);
	}

	DstAddr &= 0x1fffffff;
	DstAddr |= 0xa0000000;

	if (FWBValid(DstAddr) == 0)
	{
		sys_printf("Error: Invalid flash address %x\n", DstAddr);
		return(1);
	}

	if ((blocksize = FWBGetBlockSize(DstAddr)) == 0)
	{
		sys_printf("Error: Invalid flash address %x\n", DstAddr);
		return(1);
	}

	if (block_align)
	{
		newAddr = DstAddr;
		if ((newAddr & (blocksize-1)) != 0)
		{
			sys_printf("Destination Address is not block aligned - %x\n", newAddr);
			DstAddr = (newAddr + (blocksize - 1)) | (~(blocksize-1));
			sys_printf("Making Destination Address block aligned - %x\n", DstAddr);
		}
	}

	if (!my_getenv(env_setting, "my_ipaddress", ""))
	{
		sys_printf("Error: environment variable \"my_ipaddress\" not set.\n");
		return(1);
	}	
	if (!convert2num(env_setting, &my_ipval))
  	{
		sys_printf("Error: invalid value for environment variable \"my_ipaddress\".\n");
		return(1);
	}
	sin_lclINAddr = my_ipval;	

	if (!my_getenv(env_setting, "maca", ""))
	{
		sys_printf("Error: environment variable \"maca\" not set.\n");
		return(1);
	}		
	start_cp = env_setting;
	for (i = 0; i < sizeof(eth_HwAddress); i++)
	{
		tmpethadr[i] = (UINT8)(strtol(start_cp, &end_cp, 16));
		start_cp = ++end_cp;
	}
  	Move(tmpethadr, sed_lclEthAddr, sizeof(eth_HwAddress));

	if (my_getenv(env_setting, "gateway", ""))
	{
		if (!convert2num(env_setting, &net_Gateway))
  		{
			sys_printf("Error: invalid value for environment variable \"gateway\".\n");
			return(1);
		}
	}
	
	if (my_getenv(env_setting, "ipmask", ""))
	{
		if (!convert2num(env_setting, &net_IpMask))
  		{
			sys_printf("Error: invalid value for environment variable \"ipmask\".\n");
			return(1);
		}
	}
	
	if (!my_getenv(env_setting, "ftp_remote_ipaddress", ""))
	{
		sys_printf("Error: environment variable \"ftp_remote_ipaddress\" not set.\n");
		return(1);
	}	
	if (!convert2num(env_setting, &his_ipval))
  	{
		sys_printf("Error: invalid value for environment variable \"ftp_remote_ipaddress\".\n");
		return(1);
	}

  	if (!my_getenv(remote_user, "remote_user", "user ")) 
	{
		sys_printf("Error: environment variable \"remote_user\" not set.\n");
   		return(1);
	}
  	
	if (!my_getenv(env_setting, "remote_pass", "")) 
	{
		sys_printf("Error: environment variable \"remote_pass\" not set.\n");
   		return(1);
	}
  	if (!decrypt(env_setting, scratch))
	{
		sys_printf("Error: cannot decrypt password.\n");
   		return(1);
	}
	sys_sprintf(remote_passde,"pass %s", scratch);
	sys_sprintf(remote_pass, "pass %s", scratch);
  	cp = &remote_passde[5];
  	while (*cp) *cp++ = '*';
	
	my_getenv(remote_dir, "remote_dir", "cwd ");	
  	strcpy(rdir, sSrcFile);
  	cp = strrchr(rdir, '/');
  	if (!cp)
    	cp = strrchr(rdir, '\\');
  	if (cp)
    {
    	*cp = 0;
    	strcpy(remote_dir,"cwd ");
    	cp++;
    	strcat(remote_dir, rdir);
    	strcpy(sSrcFile, cp);
    }

  	if ( (( net_Gateway) && (!net_IpMask)) ||
         ((!net_Gateway) && (net_IpMask)) )
	{
		sys_printf("Error: Both gateway and ipmask must be valid.\n");
		return(1);
	}

	tlen = 0;
   	if (tcp_Init() == 1)
	{
		sys_printf("Error: tcp_Init failed.\n");
		return(1);
	}
	
  	ftp (his_ipval, my_ipval, remote_user, remote_pass, remote_dir, sSrcFile, GotData);
	sys_printf("\n");
#ifndef DHCP_SUPPORT
	sed_shutdown();
#endif
  	return(0);
}
#endif /* FTP_CLIENT_SUPPORT */

bit32u infocmd(int argc,char *argv[])
{
	char *cd, *ct;
	int cpufreq;
	
    sys_printf("%-30s%d.%d.%02d\n", "Monitor Revision", MonitorMajorRev, MonitorMinorRev, TelogyMonitorRev);
  
	cd = __DATE__;
	ct = __TIME__;
	sys_printf("%-30s%s, %s\n", "Monitor Compilation time", cd, ct);

 	sys_printf("%-30s%s\n","Endianness", (EMIF_REV&0x80000000)?"Big":"Little");
  
	sys_printf("%-30s%s", "External Memory rate", (EMIF_REV&0x40000000)?"Full":"Half");
  	if (EMIF_DRAMCTL&0x4000)
    {
    	sys_printf(", 16 bit wide");
    }
	sys_printf("\n");

	cpufreq = GetCpuFreq();	
	cpufreq = cpufreq / 1000000;
	sys_printf("%-30s%d MHz\n", "CPU Frequency", cpufreq);

	return(0);
}

#ifdef PING_SUPPORT
bit32u pingcmd(int argc,char *argv[])
{
	bit32u host_address;
	unsigned long count;

	if (ip_initialized != 1)
		return 1;		

	if (argc != 3)
	{
		sys_printf("Usage: ping <host> <count>\n");	
		return 1;
	}
	
	if (!convert2num(argv[1], &host_address))
  	{
		sys_printf("Error: invalid host address.\n");
		return 1;
	}
	
	count = atol(argv[2]);

	if (count == 0) 
		count = 4;	/* Default value */

	send_ping(host_address, count, 32);

	return 0;
}
#endif

bit32u adam2help(int argc,char *argv[])
{
	int i =0;

	sys_printf("\t Commands\t\tDescription\n");
	sys_printf("\t --------\t\t-----------\n");

	while (Adam2Commands[i].command_str != NULL)
	{
		sys_printf("%15s %s\n", Adam2Commands[i].command_str, Adam2Commands[i].descr_str);
		i++;
	}

	return(0);
}

