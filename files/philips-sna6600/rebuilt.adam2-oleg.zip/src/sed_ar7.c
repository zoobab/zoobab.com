/*-----------------------------------------------------------------------------*/
/*                                                                             */
/*   Copyright (C) 2003 by Texas Instruments, Inc.  All rights reserved.       */
/*   Copyright (C) 2003 Telogy Networks, Inc.							       */
/*                                                                             */
/*     IMPORTANT - READ CAREFULLY BEFORE PROCEEDING TO USE SOFTWARE.           */
/*                                                                             */
/*  This document is displayed for you to read prior to using the software     */
/*  and documentation.  By using the software and documentation, or opening    */
/*  the sealed packet containing the software, or proceeding to download the   */
/*  software from a Bulletin Board System(BBS) or a WEB Server, you agree to   */
/*  abide by the following Texas Instruments License Agreement. If you choose  */
/*  not to agree with these provisions, promptly discontinue use of the        */
/*  software and documentation and return the material to the place you        */
/*  obtained it.                                                               */
/*                                                                             */
/*                               *** NOTE ***                                  */
/*                                                                             */
/*  The licensed materials contain MIPS Technologies, Inc. confidential        */
/*  information which is protected by the appropriate MIPS Technologies, Inc.  */
/*  license agreement.  It is your responsibility to comply with these         */
/*  licenses.                                                                  */
/*                                                                             */
/*                   Texas Instruments License Agreement                       */
/*                                                                             */
/*  1. License - Texas Instruments (hereinafter "TI"), grants you a license    */
/*  to use the software program and documentation in this package ("Licensed   */
/*  Materials") for Texas Instruments broadband products.                      */
/*                                                                             */
/*  2. Restrictions - You may not reverse-assemble or reverse-compile the      */
/*  Licensed Materials provided in object code or executable format.  You may  */
/*  not sublicense, transfer, assign, rent, or lease the Licensed Materials    */
/*  or this Agreement without written permission from TI.                      */
/*                                                                             */
/*  3. Copyright - The Licensed Materials are copyrighted. Accordingly, you    */
/*  may either make one copy of the Licensed Materials for backup and/or       */
/*  archival purposes or copy the Licensed Materials to another medium and     */
/*  keep the original Licensed Materials for backup and/or archival purposes.  */
/*                                                                             */
/*  4. Runtime and Applications Software - You may create modified or          */
/*  derivative programs of software identified as Runtime Libraries or         */
/*  Applications Software, which, in source code form, remain subject to this  */
/*  Agreement, but object code versions of such derivative programs are not    */
/*  subject to this Agreement.                                                 */
/*                                                                             */
/*  5. Warranty - TI warrants the media to be free from defects in material    */
/*  and workmanship and that the software will substantially conform to the    */
/*  related documentation for a period of ninety (90) days after the date of   */
/*  your purchase. TI does not warrant that the Licensed Materials will be     */
/*  free from error or will meet your specific requirements.                   */
/*                                                                             */
/*  6. Remedies - If you find defects in the media or that the software does   */
/*  not conform to the enclosed documentation, you may return the Licensed     */
/*  Materials along with the purchase receipt, postage prepaid, to the         */
/*  following address within the warranty period and receive a refund.         */
/*                                                                             */
/*  TEXAS INSTRUMENTS                                                          */
/*  Application Specific Products, MS 8650                                     */
/*  c/o ADAM2 Application Manager                                              */
/*  12500 TI Boulevard                                                         */
/*  Dallas, TX 75243  - U.S.A.                                                 */
/*                                                                             */
/*  7. Limitations - TI makes no warranty or condition, either expressed or    */
/*  implied, including, but not limited to, any implied warranties of          */
/*  merchantability and fitness for a particular purpose, regarding the        */
/*  licensed materials.                                                        */
/*                                                                             */
/*  Neither TI nor any applicable licensor will be liable for any indirect,    */
/*  incidental or consequential damages, including but not limited to loss of  */
/*  profits.                                                                   */
/*                                                                             */
/*  8. Term - The license is effective until terminated.   You may terminate   */
/*  it at any other time by destroying the program together with all copies,   */
/*  modifications and merged portions in any form. It also will terminate if   */
/*  you fail to comply with any term or condition of this Agreement.           */
/*                                                                             */
/*  9. Export Control - The re-export of United States origin software and     */
/*  documentation is subject to the U.S. Export Administration Regulations or  */
/*  your equivalent local regulations. Compliance with such regulations is     */
/*  your responsibility.                                                       */
/*                                                                             */
/*                         *** IMPORTANT NOTICE ***                            */
/*                                                                             */
/*  Texas Instruments (TI) reserves the right to make changes to or to         */
/*  discontinue any semiconductor product or service identified in this        */
/*  publication without notice. TI advises its customers to obtain the latest  */
/*  version of the relevant information to verify, before placing orders,      */
/*  that the information being relied upon is current.                         */
/*                                                                             */
/*  TI warrants performance of its semiconductor products and related          */
/*  software to current specifications in accordance with TI's standard        */
/*  warranty. Testing and other quality control techniques are utilized to     */
/*  the extent TI deems necessary to support this warranty. Unless mandated    */
/*  by government requirements, specific testing of all parameters of each     */
/*  device is not necessarily performed.                                       */
/*                                                                             */
/*  Please be aware that Texas Instruments products are not intended for use   */
/*  in life-support appliances, devices, or systems. Use of a TI product in    */
/*  such applications without the written approval of the appropriate TI       */
/*  officer is prohibited. Certain applications using semiconductor devices    */
/*  may involve potential risks of injury, property damage, or loss of life.   */
/*  In order to minimize these risks, adequate design and operating            */
/*  safeguards should be provided by the customer to minimize inherent or      */
/*  procedural hazards. Inclusion of TI products in such applications is       */
/*  understood to be fully at the risk of the customer using TI devices or     */
/*  systems.                                                                   */
/*                                                                             */
/*  TI assumes no liability for TI applications assistance, customer product   */
/*  design, software performance, or infringement of patents or services       */
/*  described herein. Nor does TI warrant or represent that license, either    */
/*  expressed or implied, is granted under any patent right, copyright, mask   */
/*  work right, or other intellectual property right of TI covering or         */
/*  relating to any combination, machine, or process in which such             */
/*  semiconductor products or services might be or are used.                   */
/*                                                                             */
/*  All company and/or product names are trademarks and/or registered          */
/*  trademarks of their respective manaufacturers.                             */
/*                                                                             */
/*-----------------------------------------------------------------------------*/
/* 																			   */
/* Ethernet Driver. 														   */
/* A Very Simple set of ethernet driver primitives.  The ethernet (3com Mbus)  */
/* interface is controlled by busy-waiting, the application is handed the      */
/* location of on-board packet buffers, and allowed to fill in the             */
/* transmit buffer directly.  The interface is entirely blocking.              */
/*  																		   */
/* Written March, 1986 by Geoffrey Cooper 									   */
/* 																			   */
/* Copyright (C) 1986, IMAGEN Corporation 									   */
/*  "This code may be duplicated in whole or in part provided that [1] there   */
/*   is no commercial gain involved in the duplication, and [2] that this      */
/*   copyright notice is preserved on all copies.  Any other duplication       */
/*   requires written notice of the author."                                   */
/*  																		   */
/* Primitives: 																   */
/*  sed_Init()  -- Initialize the package 									   */
/*  sed_FormatPacket( destEAddr ) => location of transmit buffer               */
/*  sed_Send( pkLength ) -- send the packet that is in the transmit buffer     */ 
/*  sed_Receive( recBufLocation ) -- enable receiving packets.                 */
/*  sed_IsPacket() => location of packet in receive buffer                     */
/*  sed_CheckPacket( recBufLocation, expectedType )                            */
/*  sed_shutdown(); 														   */
/* 																			   */
/* Global Variables: 														   */
/*  sed_lclEthAddr -- Ethernet address of this host. 						   */
/*  sed_ethBcastAddr -- Ethernet broadcast address.                            */
/*-----------------------------------------------------------------------------*/

#include "_stdio.h"
#include "tinyip.h"
#include "emacphy.h"
#include "hw.h"
#include "env.h"
#include "support.h"
#include "errors.h"
#include "cpmac.h"

//#define  CPMAC_DEBUG	1

#define E10P_MIN        60              /* Minimum Ethernet packet size */

bit32u emacbase;

void sed_shutdown(void)
  {
	/* Do nothing, don't take the MAC out of reset */
	/*
	if(emacbase ==  EMACA_BASE)
	{
		RESET_PRCR  &= ~EMACA_RESET;
	}
	else
	{
  		RESET_PRCR  &= ~EMACB_RESET;
	}
	*/
	return;
  }

int sed_Init(int loopback)
  {
  int i;
  
  cpmac_init();
  for (i=0; i<3; i++) 
  	sed_ethBcastAddr[i] = 0xFFFF;
  return(0);
  }

/* 
 * Format an ethernet header in the transmit buffer, and say where it is.
 * Note that because of the way the 3Com interface works, we need to know
 * how long the packet is before we know where to put it.  The solution is
 * that we format the packet at the BEGINNING of the transmit buffer, and
 * later copy it (carefully) to where it belongs.  Another hack would be
 * to be inefficient about the size of the packet to be sent (always send
 * a larger ethernet packet than you need to, but copying should be ok for
 * now.
 */

char abuffer[4096];

octet *
sed_FormatPacket( destEAddr, ethType )
        register octet *destEAddr;
  {
  octet *xMitBuf;
  bit32u *dp;
  int i;
    
  for(i=0,dp=(bit32u *)abuffer;i<((sizeof abuffer)/4);i++) 
    *dp++=0;

  xMitBuf = (octet *)&abuffer[2];
  Move( destEAddr, xMitBuf, 6 );
  Move( sed_lclEthAddr, xMitBuf + 6, 6 );
  *((short *)(xMitBuf+12)) = wfix(ethType);
  return(xMitBuf+14);
  }

/*
 *  Send a packet out over the ethernet.  The packet is sitting at the
 * beginning of the transmit buffer.  The routine returns when the
 * packet has been successfully sent.
 */
int sed_Send( pkLengthInOctets )
  register int pkLengthInOctets;
  {
  char *cp;

  pkLengthInOctets += 14;             /* account for Ethernet header */
  pkLengthInOctets = (pkLengthInOctets + 1) & (~1);

  if (pkLengthInOctets < E10P_MIN) 
    pkLengthInOctets = E10P_MIN; /* and min. ethernet len */

  cp=&abuffer[2];
  cpmac_tx((char *)UNCACHED(cp),pkLengthInOctets);
  return(0);
  }

/* 
 * Test for the arrival of a packet on the Ethernet interface.  The packet may
 * arrive in either buffer A or buffer B; the location of the packet is
 * returned.  If no packet is returned withing 'timeout' milliseconds,
 * then the routine returns zero.
 * 
 * Note: ignores ethernet errors.  may occasionally return something
 * which was received in error.
 */

octet *sed_IsPacket(void)
  {
  octet *pb;
    
  int len;
  Status ret;
  volatile unsigned int  poll_itv = 60000;

#ifdef CPMAC_DEBUG
  sys_printf("WAITING FOR INCOMING PACKET...\n");
#endif

  do {
  	ret = cpmac_rx((char **)&pb, &len);

	if (SBL_ELKDN == ret || SBL_EFAILURE == ret) {
	  sys_printf("\ncpmac rx failed or link is down.");
	  return NULL;
	}

	if (SBL_SUCCESS == ret)
	{
#ifdef CPMAC_DEBUG
	  sys_printf("rx success!!\n");
#endif
	  break;
	}

  } while (SBL_ETIMEOUT == ret && --poll_itv > 0);

  if(poll_itv ==  0)
  {
#ifdef CPMAC_DEBUG
	sys_printf("Rx timed out!!\n");	
	cpmac_stats(); 
#endif
  }
  if (pb)
    {
    pb+=14;
#ifdef CPMAC_DEBUG
  	sys_printf("GOT PACKET! Address: 0x%08x\n", pb);
#endif
    }
  return(pb);
  }

/* 
 *  Check to make sure that the packet that you received was the one that
 * you expected to get.
 */
int sed_CheckPacket( recBufLocation, expectedType )
    word *recBufLocation;
    word expectedType;
  {

  if ( recBufLocation[-1] != wfix(expectedType) ) 
    return(0);
   else
    return(1);
  }

#include "cpmac.c"

