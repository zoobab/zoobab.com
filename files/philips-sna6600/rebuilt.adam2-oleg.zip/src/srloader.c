/*-----------------------------------------------------------------------------*/
/*                                                                             */
/*   Copyright (C) 1999-2003 by Texas Instruments, Inc.  All rights reserved.  */
/*   Copyright (C) 2001-2003 Telogy Networks, Inc.							   */
/*                                                                             */
/*     IMPORTANT - READ CAREFULLY BEFORE PROCEEDING TO USE SOFTWARE.           */
/*                                                                             */
/*  This document is displayed for you to read prior to using the software     */
/*  and documentation.  By using the software and documentation, or opening    */
/*  the sealed packet containing the software, or proceeding to download the   */
/*  software from a Bulletin Board System(BBS) or a WEB Server, you agree to   */
/*  abide by the following Texas Instruments License Agreement. If you choose  */
/*  not to agree with these provisions, promptly discontinue use of the        */
/*  software and documentation and return the material to the place you        */
/*  obtained it.                                                               */
/*                                                                             */
/*                               *** NOTE ***                                  */
/*                                                                             */
/*  The licensed materials contain MIPS Technologies, Inc. confidential        */
/*  information which is protected by the appropriate MIPS Technologies, Inc.  */
/*  license agreement.  It is your responsibility to comply with these         */
/*  licenses.                                                                  */
/*                                                                             */
/*                   Texas Instruments License Agreement                       */
/*                                                                             */
/*  1. License - Texas Instruments (hereinafter "TI"), grants you a license    */
/*  to use the software program and documentation in this package ("Licensed   */
/*  Materials") for Texas Instruments broadband products.                      */
/*                                                                             */
/*  2. Restrictions - You may not reverse-assemble or reverse-compile the      */
/*  Licensed Materials provided in object code or executable format.  You may  */
/*  not sublicense, transfer, assign, rent, or lease the Licensed Materials    */
/*  or this Agreement without written permission from TI.                      */
/*                                                                             */
/*  3. Copyright - The Licensed Materials are copyrighted. Accordingly, you    */
/*  may either make one copy of the Licensed Materials for backup and/or       */
/*  archival purposes or copy the Licensed Materials to another medium and     */
/*  keep the original Licensed Materials for backup and/or archival purposes.  */
/*                                                                             */
/*  4. Runtime and Applications Software - You may create modified or          */
/*  derivative programs of software identified as Runtime Libraries or         */
/*  Applications Software, which, in source code form, remain subject to this  */
/*  Agreement, but object code versions of such derivative programs are not    */
/*  subject to this Agreement.                                                 */
/*                                                                             */
/*  5. Warranty - TI warrants the media to be free from defects in material    */
/*  and workmanship and that the software will substantially conform to the    */
/*  related documentation for a period of ninety (90) days after the date of   */
/*  your purchase. TI does not warrant that the Licensed Materials will be     */
/*  free from error or will meet your specific requirements.                   */
/*                                                                             */
/*  6. Remedies - If you find defects in the media or that the software does   */
/*  not conform to the enclosed documentation, you may return the Licensed     */
/*  Materials along with the purchase receipt, postage prepaid, to the         */
/*  following address within the warranty period and receive a refund.         */
/*                                                                             */
/*  TEXAS INSTRUMENTS                                                          */
/*  Application Specific Products, MS 8650                                     */
/*  c/o ADAM2 Application Manager                                              */
/*  12500 TI Boulevard                                                         */
/*  Dallas, TX 75243  - U.S.A.                                                 */
/*                                                                             */
/*  7. Limitations - TI makes no warranty or condition, either expressed or    */
/*  implied, including, but not limited to, any implied warranties of          */
/*  merchantability and fitness for a particular purpose, regarding the        */
/*  licensed materials.                                                        */
/*                                                                             */
/*  Neither TI nor any applicable licensor will be liable for any indirect,    */
/*  incidental or consequential damages, including but not limited to loss of  */
/*  profits.                                                                   */
/*                                                                             */
/*  8. Term - The license is effective until terminated.   You may terminate   */
/*  it at any other time by destroying the program together with all copies,   */
/*  modifications and merged portions in any form. It also will terminate if   */
/*  you fail to comply with any term or condition of this Agreement.           */
/*                                                                             */
/*  9. Export Control - The re-export of United States origin software and     */
/*  documentation is subject to the U.S. Export Administration Regulations or  */
/*  your equivalent local regulations. Compliance with such regulations is     */
/*  your responsibility.                                                       */
/*                                                                             */
/*                         *** IMPORTANT NOTICE ***                            */
/*                                                                             */
/*  Texas Instruments (TI) reserves the right to make changes to or to         */
/*  discontinue any semiconductor product or service identified in this        */
/*  publication without notice. TI advises its customers to obtain the latest  */
/*  version of the relevant information to verify, before placing orders,      */
/*  that the information being relied upon is current.                         */
/*                                                                             */
/*  TI warrants performance of its semiconductor products and related          */
/*  software to current specifications in accordance with TI's standard        */
/*  warranty. Testing and other quality control techniques are utilized to     */
/*  the extent TI deems necessary to support this warranty. Unless mandated    */
/*  by government requirements, specific testing of all parameters of each     */
/*  device is not necessarily performed.                                       */
/*                                                                             */
/*  Please be aware that Texas Instruments products are not intended for use   */
/*  in life-support appliances, devices, or systems. Use of a TI product in    */
/*  such applications without the written approval of the appropriate TI       */
/*  officer is prohibited. Certain applications using semiconductor devices    */
/*  may involve potential risks of injury, property damage, or loss of life.   */
/*  In order to minimize these risks, adequate design and operating            */
/*  safeguards should be provided by the customer to minimize inherent or      */
/*  procedural hazards. Inclusion of TI products in such applications is       */
/*  understood to be fully at the risk of the customer using TI devices or     */
/*  systems.                                                                   */
/*                                                                             */
/*  TI assumes no liability for TI applications assistance, customer product   */
/*  design, software performance, or infringement of patents or services       */
/*  described herein. Nor does TI warrant or represent that license, either    */
/*  expressed or implied, is granted under any patent right, copyright, mask   */
/*  work right, or other intellectual property right of TI covering or         */
/*  relating to any combination, machine, or process in which such             */
/*  semiconductor products or services might be or are used.                   */
/*                                                                             */
/*  All company and/or product names are trademarks and/or registered          */
/*  trademarks of their respective manaufacturers.                             */
/*                                                                             */
/*-----------------------------------------------------------------------------*/

#include "_stdio.h"
#include "support.h"
#include "srloader.h"
#include "mms.h"
#include "shell.h"

/* Rev 0.1 Original */

#define MajRevNum 0
#define MinRevNum 3

#define INVALID_FORMAT 1
#define WRONG_ENDIAN 2
#define BAD_CHECKSUM 3

#define UnknownError	"Unknown Error!"
#define InvalidFormat	"Invalid File format!"
#define WrongEndian		"File for wrong Endian!"
#define BadChecksum 	"Error in checksum!"
#define iline			"-\\|/"

char buffer[2048];

void FlushICache(void);

#ifdef BATCH_SREC_SUPPORT
int inputline;
char *cur_ptr;
int cur_line;
int cur_len;

int s1s2s3_total;
char buff[256];

int gh(char *cp,int nibs);

void initreadline(void)
{
  cur_len=0;
  cur_line=0;
}

int readline(FFS_FILE *fil,char *buf,int len)
{
int rlen;

rlen=0;
if (len==0)
  return(0);
while(1)
  {
  if (cur_len==0)
    {
    cur_len=fread(buffer,1,sizeof buffer,fil);
    if (cur_len==0)
      {
      if (rlen)
        {
        *buf=0;
        return(rlen);
        }
      return(-1);
      }
    cur_ptr=buffer;
    }
  if (cur_len)
    {
    if (*cur_ptr=='\n')
      {
      *buf=0;
      cur_ptr++;
      cur_len--;
      return(rlen);
      }
     else
      {
      if ((len>1)&&(*cur_ptr!='\r'))
        {
        *buf++=*cur_ptr++;
        len--;
        }
       else
        cur_ptr++;
      rlen++;
      cur_len--;
      }
    }
   else
    {
    *buf=0;
    cur_ptr++;
    cur_len--;
    return(rlen);
    }
  }
}

int SRLerrorout(char *c1,char *c2)
  {
  
  sys_printf("\nERROR: %s - '%s'.",c1,c2);
  return(FALSE);
  }

int srloader_checksum(char *cp,int count)
  {
  char *scp;
  int cksum;

  scp=cp;
  while(*scp)
    {
    if (!isxdigit(*scp++))
      return(SRLerrorout("Invalid hex digits",cp));
    }
  scp=cp;
  cksum=count;
  while(count)
    {
    cksum+=gh(scp,2); scp+=2;
    count--;
    }
  cksum&=0x0ff; 
  return(cksum==0x0ff);
  }

int gh(char *cp,int nibs)
  {
  int i,j;

  j=0;
  for(i=0;i<nibs;i++)
    {
    j<<=4;
    if ((*cp>='a')&&(*cp<='z')) *cp&=0x5f;
    if ((*cp>='0')&&(*cp<='9')) 
      j+=(*cp-0x30);
     else
      if ((*cp>='A')&&(*cp<='F'))
        j+=(*cp-0x37);
       else
        SRLerrorout("Bad Hex char", cp);
    cp++;
    }
  return(j);
  }

int doline(char *cp,int *pc)
  {
  char *scp,ch;
  int  itmp,count,adr,dat;

  cur_line++;
  scp=cp;
  if (*cp!='S')
    return(SRLerrorout("Not an Srecord file",scp));
  cp++;
  if (strlen(cp)<4)
    return(SRLerrorout("Srecord too short",scp));
  ch=*cp++;
  count=gh(cp,2); cp+=2;
  if ((count*2)!=strlen(cp)) return(SRLerrorout("Count field larger than record",scp));
  if (!srloader_checksum(cp, count)) return(SRLerrorout("Bad Checksum",scp));

  switch(ch)
    {
    case '0': if (count<3) return(SRLerrorout("Invalid Srecord count field",scp));
              itmp=gh(cp,4); cp+=4; count-=2;
              if (itmp) return(SRLerrorout("Srecord 1 address not zero",scp));
              break;
    case '1': if (count<3) return(SRLerrorout("Invalid Srecord count field",scp));
              return(SRLerrorout("Srecord Not valid for MIPS",scp));
              break;
    case '2': if (count<4) return(SRLerrorout("Invalid Srecord count field",scp));
              return(SRLerrorout("Srecord Not valid for MIPS",scp));
              break;
    case '3': if (count<5) return(SRLerrorout("Invalid Srecord count field",scp));
              adr=gh(cp,8); cp+=8; count-=4;
              count--;
              while(count)
                {
                dat=gh(cp,2); cp+=2; count--;
                MEM_WRITE8(adr++,dat);
                }
              s1s2s3_total++;
              break;
    case '4': return(SRLerrorout("Invalid Srecord type",scp));
              break;
    case '5': if (count<3) return(SRLerrorout("Invalid Srecord count field",scp));
              itmp=gh(cp,4); cp+=4; count-=2;
              if (itmp|=s1s2s3_total) return(SRLerrorout("Incorrect number of S3 Record processed",scp));
              break;
    case '6': return(SRLerrorout("Invalid Srecord type",scp));
              break;
    case '7': if (count<5) return(SRLerrorout("Invalid Srecord count field",scp));
              adr=gh(cp,8); cp+=8; count-=4;
              if (count!=1) return(SRLerrorout("Invalid Srecord count field",scp));
              *pc=adr;
              break;
    case '8': if (count<4) return(SRLerrorout("Invalid Srecord count field",scp));
              return(SRLerrorout("Srecord Not valid for MIPS",scp));
              break;
    case '9': if (count<3) return(SRLerrorout("Invalid Srecord count field",scp));
              return(SRLerrorout("Srecord Not valid for MIPS",scp));
              break;
    default:
              break;
    }

  return(TRUE);
  }

bit32u srloader(int argc,char *argv[])
  {
  int rlen,sts,gopc,lindex;
  FFS_FILE *fp;
  
  s1s2s3_total = 0;
  lindex=0;
  if(argc==0)
    {
    sys_printf("\nError: No parameters!");
    return(0);
    }
  fp = fopen(argv[0],"r");
  if (fp==NULL)
    {
    sys_printf("\nError: Opening input file.");
    return(0);
    }
  initreadline();
  inputline=0;
  sts=TRUE;
  while((sts)&&((rlen=readline(fp,buff,sizeof buff))!=-1))
    {
    inputline++;
    sts&=doline(buff,&gopc);
    if ((inputline%32)==0)
      {
      sys_printf("%c%c",iline[lindex++],8);
      lindex&=3;
      }
    }
  fclose(fp);
  if(!sts) 
    gopc=0;
  /*sys_printf("PC: %08x\n",gopc);*/
  return(gopc);
  }
#endif /* BATCH_SREC_SUPPORT */

int getf32(bit32u address, bit32u *dat, int fileflag)
{
	char sdat[4];
	int n = 0;
	int i;
	bit32u uitmp;

	if (fileflag == TRUE)
	{
#ifdef FFS_SUPPORT
		FFS_FILE *fp = (FFS_FILE *)address;
		n=fread(sdat,1,4,fp);
#endif
	}
	else
	{
		bit8 *srcptr;
		n = 0;

		srcptr = (bit8 *)address;
		while (n < 4)
			sdat[n++] = *srcptr++;
	}
	
	if (n!=4) 
		return(n);
	for(uitmp=0,i=0;i<4;i++)
		uitmp|=(((bit32u)sdat[i])&0x0ff)<<(i*8);
	*dat=uitmp;
	return(n);  
}

#ifdef FFS_SUPPORT
bit32u bleout(int eval,FFS_FILE *fp)
{
	char *cp;

	cp=UnknownError;
	if (fp) 
		fclose(fp);
	switch(eval)
    {
		case INVALID_FORMAT: 
			cp=InvalidFormat;
            break;

		case WRONG_ENDIAN:   
			cp=WrongEndian;
            break;

		case BAD_CHECKSUM:   
			cp=BadChecksum;
            break;
    }
	sys_printf("BIN Loader: %s\n",cp);
	return(0);
}

bit32u binloader(int argc,char *argv[])
{
	FFS_FILE *fp;
	bit32u len,adr,wlen,rlen,tag,newchecksum,pcadr,chksum;
	int i,done,lindex,lloop;
	char *cp;
	char *dcp;
  
	pcadr=0;
	lloop=0;
	lindex=0;

	fp=fopen(argv[0],"rb");
	if (!fp)
    {
		sys_printf("Error opening file %s!\n",argv[0]);
		return(0);
    }
	if (getf32((bit32u)fp,&tag,TRUE)!=4)
		return(bleout(INVALID_FORMAT,fp));
	if (tag!=TAG_WANTED)
		return(bleout(WRONG_ENDIAN,fp));
	done=FALSE;
	do
    {
		if (getf32((bit32u)fp,&len,TRUE)!=4)
			return(bleout(INVALID_FORMAT,fp));
		newchecksum=len;
		if (getf32((bit32u)fp,&adr,TRUE)!=4)
			return(bleout(INVALID_FORMAT,fp));
		newchecksum+=adr;
		dcp=(char *)(adr);
		if (len==0)
		{
			pcadr=adr;
			done=TRUE;
		}
		else
		{
			while(len)
			{
				if (((lloop++)%4)==0)
				{
					sys_printf("%c%c",iline[lindex++],8);
					lindex&=3;
				}
				wlen=MIN(sizeof buffer,len);
				rlen=fread(buffer,1,wlen,fp);
				if (wlen!=rlen)
					return(bleout(INVALID_FORMAT,fp));
				for(i=0,cp=buffer;i<rlen;i++,cp++,dcp++)
				{
					newchecksum+=((bit32u)*cp)&0x0ff;
					*dcp=*cp;
				}
				len-=rlen;
			}
		}
		if (getf32((bit32u)fp,&chksum,TRUE)!=4)
			return(bleout(INVALID_FORMAT,fp));
		newchecksum+=chksum;
		if (newchecksum)
			return(bleout(BAD_CHECKSUM,fp));
	}while(!done);

	fclose(fp);
	/*sys_printf("PC: %08x\n",pcadr);*/
	return(pcadr);
}

bit32u progloader(int argc, char *argv[])
{
	char ftype[2];
	FFS_FILE *FilePtr;
	int len;
	bit32u gopc;

	FilePtr=fopen(argv[0],"r");  /* Is it executable? "x" */

	if (!FilePtr)
	{
		return(0);
    }

	len=fread(&ftype,1,1,FilePtr);
	fclose(FilePtr);  

	if (len!=1)
    {
		return(0);
    }

	switch(ftype[0])
    {
		case 'B': 
			gopc=binloader(argc,argv);
            break;

#ifdef BATCH_SREC_SUPPORT
    	case 'S': 
			gopc=srloader(argc,argv);
            break;
    	case '#': 
			batch(argv[0]);
            return(0);
            break;
#endif /* BATCH_SREC_SUPPORT */
			
		default:  
            return(0);
            break;
    }
	FlushICache();
	return(gopc);
}
#endif /* FFS_SUPPORT */

bit32u imageloader(bit32u address)
{
	bit32u len,adr,wlen,tag,newchecksum,pcadr,chksum;
	int i,done,lindex,lloop;
	char *cp;
	char *dcp;
  
	pcadr=0;
	lloop=0;
	lindex=0;

	address &= 0x1fffffff;
	address |= 0xa0000000;

	if (getf32(address, &tag, FALSE) !=4 )
	{
		sys_printf("%s\n", InvalidFormat);
		return(0);
	}

	if (tag != TAG_WANTED)
	{
		sys_printf("%s\n", WrongEndian);
		return(0);
	}

	done=FALSE;
	address += 4;

	do
    {
		if (getf32(address,&len,FALSE)!=4)
		{
			sys_printf("%s\n", UnknownError);
			return(0);
		}
	
		newchecksum=len;		
		address += 4;	
		
		if (getf32(address,&adr,FALSE)!=4)
		{
			sys_printf("%s\n", UnknownError);
			return(0);
		}

		newchecksum+=adr;
		address += 4;

		/*sys_printf("addr = %x, len = %x\n", adr, len);*/

		dcp=(char *)(adr);
		if (len==0)
		{
			pcadr=adr;
			done=TRUE;
		}
		else
		{
			while(len)
			{
				if (((lloop++)%4)==0)
				{
					sys_printf("%c%c",iline[lindex++],8);
					lindex&=3;
				}
				wlen = MIN((sizeof(buffer)), len);
				sys_memcpy((void *)buffer, (void *)address, wlen);
				
				for(i=0,cp=buffer;i<wlen;i++,cp++,dcp++)
				{
					newchecksum+=((bit32u)*cp)&0x0ff;
					*dcp=*cp;
				}
				len-=wlen;
				address += wlen;
			}
		}
		if (getf32(address, &chksum, FALSE) !=4 )
		{
			sys_printf("%s\n", BadChecksum);
			return(0);
		}
		address += 4;

		newchecksum+=chksum;
		if (newchecksum)
		{
			sys_printf("%s\n", BadChecksum);
			return(0);
		}

    }while(!done);

	/*sys_printf("PC: %08x\n",pcadr);*/
	FlushICache();
	return(pcadr);
}

