/************************************************************************
 *
 *  strstr.c
 *
 *  search first occurrence of string in string.
 *
 * ######################################################################
 *
 * Copyright (C) 1999 MIPS Technologies, Inc. All rights reserved.
 *
 * Unpublished rights reserved under the Copyright Laws of the United
 * States of America.
 *
 * This document contains information that is confidential and proprietary
 * to MIPS Technologies, Inc. and may be disclosed only to those employees
 * of MIPS Technologies, Inc. with a need to know, or as otherwise
 * permitted in writing by MIPS Technologies, Inc. or a
 * contractually-authorized third party. Any copying, modifying, use or
 * disclosure of this information (in whole or in part) which is not
 * expressly permitted in writing by MIPS Technologies, Inc. or a
 * contractually-authorized third party is strictly prohibited. At a
 * minimum, this information is protected under trade secret and unfair
 * competition laws and the expression of the information contained herein
 * is protected under federal copyright laws. Violations thereof may
 * result in criminal penalties and fines.
 *
 * MIPS Technologies, Inc. or any contractually-authorized third party
 * reserves the right to change the information contained in this document
 * to improve function, design or otherwise. MIPS Technologies, Inc. does
 * not assume any liability arising out of the application or use of this
 * information. Any license under patent rights or any other intellectual
 * property rights owned by MIPS Technologies or third parties shall be
 * conveyed by MIPS Technologies, Inc. or any contractually-authorized
 * third party in a separate license agreement fully executed by the
 * parties.
 *
 * The information contained in this document constitutes "Commercial
 * Computer Software" or "Commercial Computer Software Documentation," as
 * described in FAR 12.212 for civilian agencies, and DFARS 227.7202 for
 * military agencies. This information may only be disclosed to the U.S.
 * Government, or to U.S. Government users, with prior written consent from
 * MIPS Technologies, Inc. or a contractually-authorized third party. Such
 * disclosure to the U.S. Government, or to U.S. Government users, shall
 * be subject to license terms and conditions at least as restrictive and
 * protective of the confidentiality of this information as the terms and
 * conditions used by MIPS Technologies, Inc. in its license agreements
 * covering this information.
 *
 ************************************************************************/


char *strstr(
	const char 	*s1, 
	const char 	*s2)
{
    const char *s ;
    const char *t ;

    if (!s1 || !s2)
	return (0);

    if (!*s2)
	return ((char*)s1);

    for (; *s1; s1++) 
    {
	if (*s1 == *s2) 
        {
	    t = s1;
	    s = s2;
	    for (; *t; s++, t++) 
            {
		if (*t != *s)
		    break;
	    }
	    if (!*s)
		return ((char*)s1);
	}
    }
    return (0);
}
