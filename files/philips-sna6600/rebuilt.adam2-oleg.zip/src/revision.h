/*-----------------------------------------------------------------------------*/
/*                                                                             */
/*   Copyright (C) 1999-2003 by Texas Instruments, Inc.  All rights reserved.  */
/*   Copyright (C) 2001-2003 Telogy Networks.	    						   */
/*                                                                             */
/*-----------------------------------------------------------------------------*/
//#include <cy_codepattern.h>
#define MonitorMajorRev		0
#define MonitorMinorRev		22
#define	TelogyMonitorRev	02
/*0.1                                                                        */
/*Add revision                                                               */
/*Baseline release                                                           */

/*0.2                                                                        */
/*Exception handler added                                                    */
/*Autoexecute bit and number on file                                         */
/*Initialize linux SRAM 80000000                                             */
/*Display routines                                                           */
/*Frequency measurements                                                     */
/*Add sys_getienv to get indexed environment                                 */
/*Set Sio RTS at threshold 4                                                 */
/*initialize DRAM vectors                                                    */

/*0.3                                                                        */
/*Completed autoload                                                         */

/*0.4                                                                        */
/*Add Serial flow disable on CTS During SioInit, enable on command           */
/*Complete memory test, and export to user lib                               */
/*Make serial set baud based on cpu frequency(AVSIO)                         */
/*Add atoui to support                                                       */

/*0.5                                                                        */
/*Added support for quick bin files                                          */
/*Added Big Endian support                                                   */
/*Improved Flash Write speeds                                                */
/*Added Serial File Port locking                                             */
/*Add Avalanche support for:                                                 */
/*   PLL, GPIO, FreqCheck, etc                                               */
/*                                                                           */
/*0.6 Mar 01-2001                                                            */
/*Allow baud rates to be configured on Adam2 consoles                        */
/*Remove old slow flash routiones                                            */
/*                                                                           */
/*0.7                                                                        */
/*Fix internal cat command to ignore EOF character                           */
/*Erase environment flash on endian swap                                     */
/*Fix interrupt vectors prior to each autoloaded app                         */
/*                                                                           */
/*0.8                                                                        */
/*Complete FFS malloc change                                                 */
/*Export malloc call to userlib                                              */
/*Fix SDRAM 1 or 2 external bank detector                                    */
/*Start SDRAM in fast mode                                                   */
/*Compile with max warnings, and assotiated resolutions                      */
/*Repair SEEK_END function                                                   */
/*Correct flash ops fo testing and consistency                               */
/*Seperate frequency calculation for target platform                         */
/*0.9                                                                        */
/*restructure source for Telogy                                              */
/*0.10                                                                       */
/*Add autoload max run # to autoload environment var                         */
/*0.11                                                                       */
/*Reset all devices, WDT timeout only resets WDT, CPU, and EMIF              */
/*Display Autoloaded application test name to diagnostig display             */
/*Increase Reset time in Freq Check to accomidate VBUS resets                */
/*Force Cas latency of 3 during SDRAM configuration test                     */
/*Clarify path in SDRAM identification detector routines                     */
/*Detect PLL Bypass, and bring PLL up to 2X frequency at boot                */
/*0.12                                                                       */
/*Add Usercall to allow REFCLK PLL and divider to be setup, recal frequency  */
/* and resetup the serial ports                                              */
/*Add Ixx-xx for RAM data independence errors                                */
/*0.13                                                                       */
/*Added new User call to GetCpuFreq                                          */
/*cpufrequency is set in BYPASS or if the environment var is not there       */
/*Debug Display message 'Info' changed to 'Info Str' (eliminate confusion    */
/*  from info app)                                                           */
/*Increase the PPM tolerance of the RTC frequency calculator (evm3.c)        */
/*Platform frequency calculator no longer sets cfufrequency environment var  */
/*SioInit uses internal Adam2 _CPUfrequency instead of looking for an        */
/*  environment var                                                          */
/*0.14                                                                       */
/*Fix cpufrequency if setmfreq isn't autoloaded                              */
/*Fix envp to not end prematurly                                             */
/*Add Taos 16 bit EMIF support                                               */
/*Fix freq_cal for sead in big endian                                        */
/*0.15                                                                       */
/*Add PrintfRedirect, PrintfRestore, SioTxEmpty User calls to support        */
/*  background printing in an application.                                   */
/*0.16                                                                       */
/*Add GetFfsBase call to return the FFS Base for a mounted FFS (for defrag)  */
/*Add GetFlashOps call to return flash operation entry points (for defrag)   */
/*Modified FWBErase to print based on the verbose input flag.                */
/*Added FWBUnLock and FWBLock calls to flashop module (for flashk)           */
/*Corrected Flash memory size detector to deal with Adam2 loaded in another  */
/* memory region. (For sead2 USB adam2 at bd400000                           */
/*Increased the application environment pointer array size                   */
/*0.17                                                                       */
/*Support for 4KEc MIPS processor                                            */
/*Fix AMD flash Boot block regions                                           */
/*Fix spelling error on compress message                                     */
/*0.18                                                                       */
/*Add support for user app to reinit the MMS base to use more of the memory  */
/*Add support for Block Aligned Files "b" in the fopen options. Block aligned*/
/*  files are placed in the file system such that padding is added between   */
/*  file header/name and the file itself as to align the file contents to a  */
/*  flash block boundary.                                                    */
/*0.19                                                                       */
/*Allow user to call minit to initialize memory malloc system                */
/*0.20                                                                       */
/*Export SioLock function for external extended Sio file operations          */
/*                                                                           */
/*0.21                                                                       */
/*Fix env reuse variable i in getenv and setenv                              */
/*Clarify 16 bit memory initialization                                       */
/*Deal with QuickTurn slowness in baud rates (Default 1200)                  */
/*                                                                           */
/*0.22                                                                       */
/*Add GetPbusFreq and GetSbusFreq user calls for EMIF and Timer reference    */
/*Add comments to avalanche.S for regs                                       */
/*Make SIO use _PbusFrequency for reference clock                            */
/*Display running application name on debug display                          */
/*                                                                           */
/*To Do...                                                                   */
/*Merge Atlas Support                                                        */
/*Flash Support for 16 and 8 bit Starta Flash                                */
/*Sio Init/ID for flashk to load correct load                                */
/*Allow block aligned file in last block of flash                            */
/*set environment var for the flash type currently in use                    */
/*---------------------------------------------------------------------------*/

/* Telogy versions */

/*---------------------------------------------------------------------------*/
/*0.xx.0																	 */
/*Support for basic commands like setenv, printenv, getenv setmfreq within   */
/* 	Adam2 kernel.															 */
/*In-built FTP support to download the files into the raw flash.			 */
/*Suppor for DHCP within Adam2 kernel for ACPEP boards.						 */
/*0.xx.1 																	 */
/*Replaced FTP client with a FTP server. 									 */
/*Support for some customized user commands within FTP server				 */
/*Support for autodetection, so that the PC application is able to get the   */
/* 	IP Address for Adam2 before starting a FTP client session.				 */
/*Support for STOR command which can download file into FLASH or SDRAM 		 */
/*  depending on the MEDIA type selected by the client.					     */
/*Support for RETR command for retreiving the environment, and linux 		 */
/*	configuration (XML script).												 */
/*Modified the EMAC link detection code to wait for 5 secs to detect the     */
/*  link instead of just waiting till the link is up.						 */
/*Modified the autoload functionality to be enabled only after waiting for   */
/*  5 secs - This waiting is provided so that the PC application can         */
/*  communicate with Adam2.													 */
/*---------------------------------------------------------------------------*/
/* 0.xx.2                                                                    */
/*                                                                           */
/* Added support for using the same MTD for both the Adam2 env vars          */
/* and the cfgman config.xml.                                                */
/*                                                                           */
/*---------------------------------------------------------------------------*/
