/*------------------------------------------------------------------------------*/
/*                                                                             	*/
/*   Copyright (C) 1999-2003 by Texas Instruments, Inc.  All rights reserved.  	*/
/*   Copyright (C) 2001-2003 Telogy Networks.	    						   	*/
/*                                                                              */
/*     IMPORTANT - READ CAREFULLY BEFORE PROCEEDING TO USE SOFTWARE.           	*/
/*                                                                             	*/
/*  This document is displayed for you to read prior to using the software     	*/
/*  and documentation.  By using the software and documentation, or opening    	*/
/*  the sealed packet containing the software, or proceeding to download the   	*/
/*  software from a Bulletin Board System(BBS) or a WEB Server, you agree to   	*/
/*  abide by the following Texas Instruments License Agreement. If you choose  	*/
/*  not to agree with these provisions, promptly discontinue use of the        	*/
/*  software and documentation and return the material to the place you        	*/
/*  obtained it.                                                               	*/
/*                                                                             	*/
/*                               *** NOTE ***                                  	*/
/*                                                                             	*/
/*  The licensed materials contain MIPS Technologies, Inc. confidential        	*/
/*  information which is protected by the appropriate MIPS Technologies, Inc.  	*/
/*  license agreement.  It is your responsibility to comply with these         	*/
/*  licenses.                                                                  	*/
/*                                                                             	*/
/*                   Texas Instruments License Agreement                       	*/
/*                                                                             	*/
/*  1. License - Texas Instruments (hereinafter "TI"), grants you a license    	*/
/*  to use the software program and documentation in this package ("Licensed   	*/
/*  Materials") for Texas Instruments broadband products.                      	*/
/*                                                                             	*/
/*  2. Restrictions - You may not reverse-assemble or reverse-compile the      	*/
/*  Licensed Materials provided in object code or executable format.  You may  	*/
/*  not sublicense, transfer, assign, rent, or lease the Licensed Materials    	*/
/*  or this Agreement without written permission from TI.                      	*/
/*                                                                             	*/
/*  3. Copyright - The Licensed Materials are copyrighted. Accordingly, you    	*/
/*  may either make one copy of the Licensed Materials for backup and/or       	*/
/*  archival purposes or copy the Licensed Materials to another medium and     	*/
/*  keep the original Licensed Materials for backup and/or archival purposes.  	*/
/*                                                                             	*/
/*  4. Runtime and Applications Software - You may create modified or          	*/
/*  derivative programs of software identified as Runtime Libraries or         	*/
/*  Applications Software, which, in source code form, remain subject to this  	*/
/*  Agreement, but object code versions of such derivative programs are not    	*/
/*  subject to this Agreement.                                                 	*/
/*                                                                             	*/
/*  5. Warranty - TI warrants the media to be free from defects in material    	*/
/*  and workmanship and that the software will substantially conform to the    	*/
/*  related documentation for a period of ninety (90) days after the date of   	*/
/*  your purchase. TI does not warrant that the Licensed Materials will be     	*/
/*  free from error or will meet your specific requirements.                   	*/
/*                                                                             	*/
/*  6. Remedies - If you find defects in the media or that the software does   	*/
/*  not conform to the enclosed documentation, you may return the Licensed     	*/
/*  Materials along with the purchase receipt, postage prepaid, to the         	*/
/*  following address within the warranty period and receive a refund.         	*/
/*                                                                             	*/
/*  TEXAS INSTRUMENTS                                                          	*/
/*  Application Specific Products, MS 8650                                     	*/
/*  c/o ADAM2 Application Manager                                              	*/
/*  12500 TI Boulevard                                                         	*/
/*  Dallas, TX 75243  - U.S.A.                                                 	*/
/*                                                                             	*/
/*  7. Limitations - TI makes no warranty or condition, either expressed or    	*/
/*  implied, including, but not limited to, any implied warranties of          	*/
/*  merchantability and fitness for a particular purpose, regarding the        	*/
/*  licensed materials.                                                        	*/
/*                                                                             	*/
/*  Neither TI nor any applicable licensor will be liable for any indirect,    	*/
/*  incidental or consequential damages, including but not limited to loss of  	*/
/*  profits.                                                                   	*/
/*                                                                             	*/
/*  8. Term - The license is effective until terminated.   You may terminate   	*/
/*  it at any other time by destroying the program together with all copies,   	*/
/*  modifications and merged portions in any form. It also will terminate if   	*/
/*  you fail to comply with any term or condition of this Agreement.           	*/
/*                                                                             	*/
/*  9. Export Control - The re-export of United States origin software and     	*/
/*  documentation is subject to the U.S. Export Administration Regulations or  	*/
/*  your equivalent local regulations. Compliance with such regulations is     	*/
/*  your responsibility.                                                       	*/
/*                                                                             	*/
/*                         *** IMPORTANT NOTICE ***                            	*/
/*                                                                             	*/
/*  Texas Instruments (TI) reserves the right to make changes to or to         	*/
/*  discontinue any semiconductor product or service identified in this        	*/
/*  publication without notice. TI advises its customers to obtain the latest  	*/
/*  version of the relevant information to verify, before placing orders,      	*/
/*  that the information being relied upon is current.                         	*/
/*                                                                             	*/
/*  TI warrants performance of its semiconductor products and related          	*/
/*  software to current specifications in accordance with TI's standard        	*/
/*  warranty. Testing and other quality control techniques are utilized to     	*/
/*  the extent TI deems necessary to support this warranty. Unless mandated    	*/
/*  by government requirements, specific testing of all parameters of each     	*/
/*  device is not necessarily performed.                                       	*/
/*                                                                             	*/
/*  Please be aware that Texas Instruments products are not intended for use   	*/
/*  in life-support appliances, devices, or systems. Use of a TI product in    	*/
/*  such applications without the written approval of the appropriate TI       	*/
/*  officer is prohibited. Certain applications using semiconductor devices    	*/
/*  may involve potential risks of injury, property damage, or loss of life.   	*/
/*  In order to minimize these risks, adequate design and operating            	*/
/*  safeguards should be provided by the customer to minimize inherent or      	*/
/*  procedural hazards. Inclusion of TI products in such applications is       	*/
/*  understood to be fully at the risk of the customer using TI devices or     	*/
/*  systems.                                                                   	*/
/*                                                                             	*/
/*  TI assumes no liability for TI applications assistance, customer product   	*/
/*  design, software performance, or infringement of patents or services       	*/
/*  described herein. Nor does TI warrant or represent that license, either    	*/
/*  expressed or implied, is granted under any patent right, copyright, mask   	*/
/*  work right, or other intellectual property right of TI covering or         	*/
/*  relating to any combination, machine, or process in which such             	*/
/*  semiconductor products or services might be or are used.                   	*/
/*                                                                             	*/
/*  All company and/or product names are trademarks and/or registered          	*/
/*  trademarks of their respective manaufacturers.                             	*/
/*------------------------------------------------------------------------------*/

#include "_stdio.h"
#include "support.h"
#include "files.h"
#include "errors.h" 
#include "sio.h"
#include "shell.h"
#include "files.h"
#include "fcb.h"
#include "hw.h"
#include "flashop.h"
#include "ffs.h"
#include "ffs_util.h"

#define _StreamOut SioOutChar  

int *LEDData=(int *)0x01b81008; 

int FileVersion(void)
  {
  return(0x01);
  }
           
void Zap(int i)
  {
  i<<=4;
  i^=0xf0;
  i&=0xf0;
  *LEDData=i;
  }           
           
void _FileSystemInit(void)
  {
  fcb_InitFCB();
  ffs_InitFlashFIleSystem();
  }

void _FCBCloseWriteFiles(void)
  {
  int i;

  for(i=0;i<MAX_OPEN_FILES;i++)
    {
    ffs_AbandonWrite(&_FileArray[i]);  
    }
  }

void _FilePutString(const char *str)
  {
  while(*str)
    _StreamOut(*str++);
  _StreamOut(0);
  }

int _FileGetByte(char *cVal)
  {
  bit32 lTimeOut;

  lTimeOut=FILE_WAIT_TIME;
  while(lTimeOut)
    {
    if (SioInCharCheck(cVal))
      {      
      return(TRUE);
      }
    lTimeOut--;
    }  
  return(FALSE);
  }

void _FilePutShort(short sVal)
  {

  _StreamOut((char)sVal);
  sVal>>=8;
  _StreamOut((char)sVal);
  }

void _FilePutBit32(bit32 lVal)
  {

  _StreamOut((char)lVal);
  lVal>>=8;
  _StreamOut((char)lVal);
  lVal>>=8;
  _StreamOut((char)lVal);
  lVal>>=8;
  _StreamOut((char)lVal);
  }

int _FileHandlerResponce(char cVal)
  {
  char cTmp;
  
  do
    {
    if (!_FileGetByte(&cTmp))
      return(FALSE);
    }while(cTmp!=FILER);  
  if (!_FileGetByte(&cTmp))
    return(FALSE);
  if (cTmp!=cVal)
    return(FALSE);
  return(TRUE);  
  }

int _FileHandlerCheck(void)
  {
  _StreamOut(FILER);
  _StreamOut(FALIVE);
  return(_FileHandlerResponce(FALIVE));
  }

int _FileGetBit32(bit32 *lVal)
  {
  bit32 lTmp;
  int iIndex;
  char cTmp;

  lTmp=0;
  for(iIndex=0;iIndex<4;iIndex++)
    {
    if (!_FileGetByte(&cTmp))
      return(FALSE);
    lTmp|=(((bit32)cTmp)&0x0ffl)<<(iIndex*8);
    }
  *lVal=lTmp;
  return(TRUE);
  }

int _SioFileRemove(const char *file_name)
  {
  bit32 sts;
                  
  SioFlush();
  SioLock(TRUE);
  if (!_FileHandlerCheck()) 
    {
    SioLock(FALSE);
    return(-1);   
    }         
  _StreamOut(FILER);
  _StreamOut(FREMOVE);
  _FilePutString(file_name);
  if (!_FileHandlerResponce(FREMOVE)) 
    {
    SioLock(FALSE);
    return(-1);   
    }
  if (!_FileGetBit32(&sts)) 
    {
    SioLock(FALSE);
    return(-1);   
    }
  if (sts)
    {
    SioLock(FALSE);
    return(-1);   
    }
  SioLock(FALSE);
  return(0);
  }

FFS_FILE *_SioFileOpen(const char *file_name, const char *mode)
  {
  bit32 handle;
  FFS_FILE *pFCB;
                  
  if (!(pFCB=fcb_FileGetFCB()))
    {
    return(0);   
    }  
  SioFlush();
  SioLock(TRUE);
  if (!_FileHandlerCheck()) 
    {
    SioLock(FALSE);
    return(0);   
    }         
  _StreamOut(FILER);
  _StreamOut(FOPEN);
  _FilePutString(file_name);
  _FilePutString(mode);
  if (!_FileHandlerResponce(FOPEN)) 
    {
    SioLock(FALSE);
    return(0);   
    }
  if (!_FileGetBit32(&handle)) 
    {
    SioLock(FALSE);
    return(0);   
    }
  if (!handle)
    {
    SioLock(FALSE);
    return(0);   
    }
  pFCB->SubFileSystem=(FFS_FILE *)handle;
  pFCB->_FileState=FILE_OPEN;
  pFCB->_SubSystemType=FILE_SIO;
  SioLock(FALSE);
  return(pFCB);
  }

int _SioFileClose(FFS_FILE *handle)
  {
  char cTmp;
  bit32 lTmp;

  if (!handle->_FileState)
    return(EOF);  
  SioFlush();
  SioLock(TRUE);
  if (!_FileHandlerCheck()) 
    {
    SioLock(FALSE);
    return(EOF);   
    }
  _StreamOut(FILER);
  _StreamOut(FCLOSE);
  _FilePutBit32((bit32)handle->SubFileSystem);
  handle->_FileState=FILE_FREE;
  if (!_FileHandlerResponce(FCLOSE)) 
    {
    SioLock(FALSE);
    return(EOF);   
    }
  if (!_FileGetByte(&cTmp))
    {
    SioLock(FALSE);
    return(EOF);   
    }
  lTmp=((bit32)cTmp)&0x0ffl;
  SioLock(FALSE);
  return(lTmp);
  }

size_t _SioFileRead(void *buf, size_t size, size_t count, FFS_FILE *fp)
  {
  bit32 lLen;
  int i;
  bit8 *TmpBuf;
  
  TmpBuf=(bit8 *)buf;        
  if (!fp->_FileState)
    return(0);
  SioFlush();
  SioLock(TRUE);
  if (!_FileHandlerCheck()) 
    {
    Zap(1);
    SioLock(FALSE);
    return(0);   
    }
  _StreamOut(FILER);
  _StreamOut(FREAD);
  _FilePutBit32((bit32)fp->SubFileSystem);
  _FilePutBit32(count*size);
  if (!_FileHandlerResponce(FREAD)) 
    {
    Zap(2);
    SioLock(FALSE);
    return(0);   
    }
  if (!_FileGetBit32(&lLen))
    {
    Zap(3);
    SioLock(FALSE);
    return(0);   
    }
  for (i=0;i<lLen;i++)
    {
    if (!_FileGetByte((char *)TmpBuf))
      {
      Zap(4);
      SioLock(FALSE);
      return(0);   
      }
    TmpBuf++;
    }
  SioLock(FALSE);
  return(lLen/size);
  }

size_t _SioFileWrite(const void *buf, size_t size, size_t count, FFS_FILE *fp)
  {
  bit32 lLen,lIndex;
  bit8 *TmpBuf=(bit8 *)buf;

  if (!fp->_FileState)
    return(0);
  SioFlush();
  SioLock(TRUE);
  if (!_FileHandlerCheck()) 
    {
    SioLock(FALSE);
    return(0);   
    }
  _StreamOut(FILER);
  _StreamOut(FWRITE);
  _FilePutBit32((bit32)fp->SubFileSystem);
  _FilePutBit32(count*size);
  for (lIndex=0;lIndex<(size*count);lIndex++)
    _StreamOut(*TmpBuf++);
  if (!_FileHandlerResponce(FWRITE)) 
    {
    SioLock(FALSE);
    return(0);   
    }
  if (!_FileGetBit32(&lLen))
    {
    SioLock(FALSE);
    return(0);   
    }
  SioLock(FALSE);
  return(lLen/size);
  }

bit32 fgetc(FFS_FILE *fh)
  {
  char tmp;
  bit32 len;

  len = fread(&tmp,1,1,fh);
  if(len == 0)
    tmp = EOF;
  return(tmp);
  }

int IsFileExist(char *ifile, char *imode)
  {
  FFS_FILE *FilePtr = NULL;
                 
  FilePtr=fopen(ifile,"r");
  if (!FilePtr) return(FALSE); 
  fclose(FilePtr);
  return(TRUE);
  }

int remove(const char *filename)
  {
  int sts = 0;

  if (filename[1]==':')
    sts=_SioFileRemove(filename);
  else
    sts=ffs_remove(filename);
  return(sts);
  }

FFS_FILE *fopen(const char *filename, const char *type)
  {
  FFS_FILE *fptr = NULL;

  if (filename[1]==':')
    fptr=_SioFileOpen(filename,type);
  else
	fptr=ffs_fopen(filename,type);
  return(fptr);
  }

size_t fread(void *ptr, size_t size, size_t nitems, FFS_FILE *stream)
  {
  if (stream->_SubSystemType==FILE_SIO)
    return(_SioFileRead(ptr,size,nitems,stream));
  if (stream->_SubSystemType==FILE_FLASH)
    return(ffs_fread(ptr,size,nitems,stream));
  return(0);
  }

size_t fwrite(const void *ptr, size_t size, size_t nitems, FFS_FILE *stream)
  {
  if (stream->_SubSystemType==FILE_SIO)
    return(_SioFileWrite(ptr,size,nitems,stream));
  if (stream->_SubSystemType==FILE_FLASH)
    return(ffs_fwrite(ptr,size,nitems,stream));
  return(0);
  }

int fseek(FFS_FILE *stream, bit32 offset, int ptrname)
  {
  if (stream->_SubSystemType==FILE_SIO)
    return(_SioFileSeek(stream,offset,ptrname));
  if (stream->_SubSystemType==FILE_FLASH)
    return(ffs_fseek(stream,offset,ptrname));
  return(0);
  }

void rewind(FFS_FILE *stream)
  { 
  fseek(stream,0,FFS_SEEK_SET);
  return;
  }

bit32 ftell(FFS_FILE *stream)
  {
  sys_printf("%stell - not implemented yet!\n", stream->_SubSystemType==FILE_SIO?"_SioFile":"FlashFile");
  return(0);
  }

int fflush(FFS_FILE *stream)
  {
  sys_printf("%sflush - not implemented yet!\n", stream->_SubSystemType==FILE_SIO?"_SioFile":"FlashFile");
  return(0);
  }

int feof(FFS_FILE *stream)
  {
  sys_printf("%sEof - not implemented yet!\n", stream->_SubSystemType==FILE_SIO?"_SioFile":"FlashFile");
  return(0);
  }

int fclose(FFS_FILE *stream)
  {
  if (stream->_SubSystemType==FILE_SIO)
    return(_SioFileClose(stream));
  if (stream->_SubSystemType==FILE_FLASH)
    return(ffs_fclose(stream));
  return(0);
  }  

int  _SioFileSeek(FFS_FILE *stream, bit32 offset, int ptrname)
  {
  char cTmp;
  
  if (!stream->_FileState)
    return(0);
  SioFlush();
  SioLock(TRUE);
  if (!_FileHandlerCheck()) 
    {
    Zap(5);
    SioLock(FALSE);
    return(0);   
    }
  _StreamOut(FILER);
  _StreamOut(FSEEK);
  _FilePutBit32((bit32)stream->SubFileSystem);
  _FilePutBit32(offset);
  _FilePutShort(ptrname);
  if (!_FileHandlerResponce(FSEEK)) 
    {
    Zap(6);
    SioLock(FALSE);
    return(0);   
    }
  if (!_FileGetByte(&cTmp))
    {
    Zap(7);
    SioLock(FALSE);
    return(0);   
    }
  SioLock(FALSE);
  return(cTmp);
  }

#include "_stdarg.h"          
#define MAX_STRING_SIZE 256         
int sys_fprintf(FFS_FILE *fp, const char *format, ...)
  {
  int     count;
  va_list ap;
  char    buffer[MAX_STRING_SIZE];

  va_start(ap, format);
  count = sys_vsprintf(buffer, (char *)format, ap);
  va_end(ap); 
  count=fwrite(buffer,1,count,fp);
  return (count);
  }

