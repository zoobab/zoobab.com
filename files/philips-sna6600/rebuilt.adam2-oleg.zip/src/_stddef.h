/*------------------------------------------------------------------------------*/
/*                                                                             	*/
/*   Copyright (C) 1999-2003 by Texas Instruments, Inc.  All rights reserved.  	*/
/*   Copyright (C) 2001-2003 Telogy Networks.	    						   	*/
/*                                                                             	*/
/*																				*/
/* 	FILE:	stddef.h															*/
/*																				*/
/* 	DESCRIPTION:																*/
/*		This file contains standard definitions and typedefs.					*/
/*																				*/
/* 	HISTORY:																	*/
/*		26Feb01	BEGR	Original version written								*/
/*------------------------------------------------------------------------------*/
#ifndef ___STDDEF_H___
#define ___STDDEF_H___


#endif

