/*-----------------------------------------------------------------------------*/
/*                                                                             */
/*   Copyright (C) 2002-2003 by Texas Instruments, Inc.  All rights reserved.  */
/*   Copyright (C) 2002-2003 Telogy Networks.	    						   */
/*-----------------------------------------------------------------------------*/

#include "_stdio.h"
#include "env.h"
#include "hw.h"

unsigned int SetupCpuFrequency()
{
  bit32u xtal;

  xtal=25000000;
  if (BOOTCR&BCR_BYPASS)
    return(xtal);
   else
    {
    xtal*=((SCLKCR_MUL>>12)&0xf)+1;  
    xtal/=(SCLKCR_DIV&0xf)+1;
    return(xtal);
    }
}

bit32u GetCurrentDateTime()
{
  return(0);
}

