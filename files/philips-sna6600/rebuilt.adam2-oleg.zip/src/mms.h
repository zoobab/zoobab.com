/*-----------------------------------------------------------------------------*/
/*                                                                             */
/*   Copyright (C) 1993-2003 by Texas Instruments, Inc.  All rights reserved.  */
/*   Copyright (C) 2001-2003 Telogy Networks.	    						   */
/*                                                                             */
/*-----------------------------------------------------------------------------*/

#ifndef _MMS_H
#define _MMS_H

#include "_stdio.h"

void minit(unsigned adr, unsigned size);
void* sys_memalign(unsigned alignment, unsigned size);
void sys_memmap(int lvl);
void sys_memcpy(void *new, void *packet, int oldsize);
void sys_memset(void *new, UINT8 data, int oldsize);

#ifndef NULL
#define NULL 0
#endif

unsigned int atoui(char *cp);

#endif
