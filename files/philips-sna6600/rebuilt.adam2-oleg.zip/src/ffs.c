/*------------------------------------------------------------------------------*/
/*                                                                             	*/
/*   Copyright (C) 1999-2003 by Texas Instruments, Inc.  All rights reserved.  	*/
/*   Copyright (C) 2001-2003 Telogy Networks.	    						   	*/
/*                                                                              */
/*     IMPORTANT - READ CAREFULLY BEFORE PROCEEDING TO USE SOFTWARE.           	*/
/*                                                                             	*/
/*  This document is displayed for you to read prior to using the software     	*/
/*  and documentation.  By using the software and documentation, or opening    	*/
/*  the sealed packet containing the software, or proceeding to download the   	*/
/*  software from a Bulletin Board System(BBS) or a WEB Server, you agree to   	*/
/*  abide by the following Texas Instruments License Agreement. If you choose  	*/
/*  not to agree with these provisions, promptly discontinue use of the        	*/
/*  software and documentation and return the material to the place you        	*/
/*  obtained it.                                                               	*/
/*                                                                             	*/
/*                               *** NOTE ***                                  	*/
/*                                                                             	*/
/*  The licensed materials contain MIPS Technologies, Inc. confidential        	*/
/*  information which is protected by the appropriate MIPS Technologies, Inc.  	*/
/*  license agreement.  It is your responsibility to comply with these         	*/
/*  licenses.                                                                  	*/
/*                                                                             	*/
/*                   Texas Instruments License Agreement                       	*/
/*                                                                             	*/
/*  1. License - Texas Instruments (hereinafter "TI"), grants you a license    	*/
/*  to use the software program and documentation in this package ("Licensed   	*/
/*  Materials") for Texas Instruments broadband products.                      	*/
/*                                                                             	*/
/*  2. Restrictions - You may not reverse-assemble or reverse-compile the      	*/
/*  Licensed Materials provided in object code or executable format.  You may  	*/
/*  not sublicense, transfer, assign, rent, or lease the Licensed Materials    	*/
/*  or this Agreement without written permission from TI.                      	*/
/*                                                                             	*/
/*  3. Copyright - The Licensed Materials are copyrighted. Accordingly, you    	*/
/*  may either make one copy of the Licensed Materials for backup and/or       	*/
/*  archival purposes or copy the Licensed Materials to another medium and     	*/
/*  keep the original Licensed Materials for backup and/or archival purposes.  	*/
/*                                                                             	*/
/*  4. Runtime and Applications Software - You may create modified or          	*/
/*  derivative programs of software identified as Runtime Libraries or         	*/
/*  Applications Software, which, in source code form, remain subject to this  	*/
/*  Agreement, but object code versions of such derivative programs are not    	*/
/*  subject to this Agreement.                                                 	*/
/*                                                                             	*/
/*  5. Warranty - TI warrants the media to be free from defects in material    	*/
/*  and workmanship and that the software will substantially conform to the    	*/
/*  related documentation for a period of ninety (90) days after the date of   	*/
/*  your purchase. TI does not warrant that the Licensed Materials will be     	*/
/*  free from error or will meet your specific requirements.                   	*/
/*                                                                             	*/
/*  6. Remedies - If you find defects in the media or that the software does   	*/
/*  not conform to the enclosed documentation, you may return the Licensed     	*/
/*  Materials along with the purchase receipt, postage prepaid, to the         	*/
/*  following address within the warranty period and receive a refund.         	*/
/*                                                                             	*/
/*  TEXAS INSTRUMENTS                                                          	*/
/*  Application Specific Products, MS 8650                                     	*/
/*  c/o ADAM2 Application Manager                                              	*/
/*  12500 TI Boulevard                                                         	*/
/*  Dallas, TX 75243  - U.S.A.                                                 	*/
/*                                                                             	*/
/*  7. Limitations - TI makes no warranty or condition, either expressed or    	*/
/*  implied, including, but not limited to, any implied warranties of          	*/
/*  merchantability and fitness for a particular purpose, regarding the        	*/
/*  licensed materials.                                                        	*/
/*                                                                             	*/
/*  Neither TI nor any applicable licensor will be liable for any indirect,    	*/
/*  incidental or consequential damages, including but not limited to loss of  	*/
/*  profits.                                                                   	*/
/*                                                                             	*/
/*  8. Term - The license is effective until terminated.   You may terminate   	*/
/*  it at any other time by destroying the program together with all copies,   	*/
/*  modifications and merged portions in any form. It also will terminate if   	*/
/*  you fail to comply with any term or condition of this Agreement.           	*/
/*                                                                             	*/
/*  9. Export Control - The re-export of United States origin software and     	*/
/*  documentation is subject to the U.S. Export Administration Regulations or  	*/
/*  your equivalent local regulations. Compliance with such regulations is     	*/
/*  your responsibility.                                                       	*/
/*                                                                             	*/
/*                         *** IMPORTANT NOTICE ***                            	*/
/*                                                                             	*/
/*  Texas Instruments (TI) reserves the right to make changes to or to         	*/
/*  discontinue any semiconductor product or service identified in this        	*/
/*  publication without notice. TI advises its customers to obtain the latest  	*/
/*  version of the relevant information to verify, before placing orders,      	*/
/*  that the information being relied upon is current.                         	*/
/*                                                                             	*/
/*  TI warrants performance of its semiconductor products and related          	*/
/*  software to current specifications in accordance with TI's standard        	*/
/*  warranty. Testing and other quality control techniques are utilized to     	*/
/*  the extent TI deems necessary to support this warranty. Unless mandated    	*/
/*  by government requirements, specific testing of all parameters of each     	*/
/*  device is not necessarily performed.                                       	*/
/*                                                                             	*/
/*  Please be aware that Texas Instruments products are not intended for use   	*/
/*  in life-support appliances, devices, or systems. Use of a TI product in    	*/
/*  such applications without the written approval of the appropriate TI       	*/
/*  officer is prohibited. Certain applications using semiconductor devices    	*/
/*  may involve potential risks of injury, property damage, or loss of life.   	*/
/*  In order to minimize these risks, adequate design and operating            	*/
/*  safeguards should be provided by the customer to minimize inherent or      	*/
/*  procedural hazards. Inclusion of TI products in such applications is       	*/
/*  understood to be fully at the risk of the customer using TI devices or     	*/
/*  systems.                                                                   	*/
/*                                                                             	*/
/*  TI assumes no liability for TI applications assistance, customer product   	*/
/*  design, software performance, or infringement of patents or services       	*/
/*  described herein. Nor does TI warrant or represent that license, either    	*/
/*  expressed or implied, is granted under any patent right, copyright, mask   	*/
/*  work right, or other intellectual property right of TI covering or         	*/
/*  relating to any combination, machine, or process in which such             	*/
/*  semiconductor products or services might be or are used.                   	*/
/*                                                                             	*/
/*  All company and/or product names are trademarks and/or registered          	*/
/*  trademarks of their respective manaufacturers.                             	*/
/*------------------------------------------------------------------------------*/

#include "_stdio.h"
#include "fcb.h"
#include "ffs.h"
#include "ffs_util.h"
#include "flashop.h"
#include "hw.h" 
#include "support.h" 

/* Flash File System guidlines                                               */
/* The flash file system can only open read write and close a file that      */
/*  the rights apply. That is even root has no authority to read a not       */
/*  owned file.                                                              */
/*                                                                           */
/* FindFirst finds the first file in the global file system that meets the   */
/*  rights. Only root can see all file entries, but cannot read/write them.  */
/*                                                                           */
/* INodes are FFS dependent that is the system can have many FFS and inode   */
/*  is maintained for each.                                                  */
/*                                                                           */

ffs_tMountPoint ffs_sFlashFileSystemsMounts[NUM_OF_SLOTS+1] = {{0,0}, {0,0}};
int ffs_iNumOfFlashMounts = 0;
          
int _ffs_hw_isslotenabled(int slot)
  {
  return(FALSE);
  }

void ffs_RepairFlashFileSystems(int slot)
  {
  }

void ffs_InitFlashFIleSystem(void)
  {
  int i;
  bit32u bootblocksize;

  sys_printf("\nFlash File System ");    
  bootblocksize=FWBGetBlockSize(CS0_BASE);
  if (bootblocksize<MIN_BOOT_BLOCK_SIZE) 
    bootblocksize=MIN_BOOT_BLOCK_SIZE;
  ffs_iNumOfFlashMounts=0;
  ffs_AddFileSystem(0,(void *)(CS0_BASE+bootblocksize));
  for(i=1;i<=NUM_OF_SLOTS;i++)
    {
    }   
  sys_printf("initialized.\n");
  }

int ffs_AddFileSystem(int slot,void *ffs)
  {
  int i;

  if (slot)
    {
    if (!_ffs_hw_isslotenabled(slot))
      {
      return(FFS_ERRS_SLOT_NOT_ENABLED);
      }
    }
  if (!strncmp((char *)ffs,"FFS",3)==0)
    {
    return(FFS_ERRS_NOT_A_VALID_FFS);
    }
  if ((((char *)ffs)[3])>FFS_VERSION)
    {
    return(FFS_ERRS_VERSION_NOT_SUPPORTED);
    }
  for(i=0;i<ffs_iNumOfFlashMounts;i++)
    {
    if (ffs_sFlashFileSystemsMounts[i].slot==slot)
      return(FFS_ERRS_FFS_ALREADY_MOUNTED);
    }
  ffs_sFlashFileSystemsMounts[ffs_iNumOfFlashMounts].ffs_ptr=ffs;
  ffs_sFlashFileSystemsMounts[ffs_iNumOfFlashMounts].slot=slot;
  ffs_iNumOfFlashMounts++;
  ffs_RepairFlashFileSystems(slot);
  return(FFS_ERRS_NO_ERROR);
  }

int ffs_RemoveSlotMount(int slot)
  {
  void *tmp_ffs_ptr;
  int i,tmp_slot;
  
  for(i=0;i<ffs_iNumOfFlashMounts;i++)
    {
    if (ffs_sFlashFileSystemsMounts[i].slot==slot)
      {
      ffs_iNumOfFlashMounts--;
      tmp_ffs_ptr=ffs_sFlashFileSystemsMounts[ffs_iNumOfFlashMounts].ffs_ptr;
      tmp_slot=ffs_sFlashFileSystemsMounts[ffs_iNumOfFlashMounts].slot;
      ffs_sFlashFileSystemsMounts[ffs_iNumOfFlashMounts].ffs_ptr=ffs_sFlashFileSystemsMounts[i].ffs_ptr;
      ffs_sFlashFileSystemsMounts[ffs_iNumOfFlashMounts].slot=ffs_sFlashFileSystemsMounts[i].slot;
      ffs_sFlashFileSystemsMounts[i].ffs_ptr=tmp_ffs_ptr;
      ffs_sFlashFileSystemsMounts[i].slot=tmp_slot;
      return(FFS_ERRS_NO_ERROR);
      }
    }
  return(FFS_ERRS_NO_SUCH_FFS);
  }

int ffs_AddNewSlotMount(int slot)
  {
  return(ffs_AddFileSystem(slot,(void *)(((slot-1)<<15)+SLOT_BASE)));
  }

ffs_tEntry *_ffs_DumpFlashFileSystemEntry(ffs_tEntry *ffse,int show_deleted)
  {
  int i,iFileFlags,iFileNameLength;
  bit32 iFileLength;
  char *cp;  

  iFileFlags=_ffs_GetBit16Value(ffse->flags);
  iFileLength=_ffs_GetBit24Value(ffse->flen);
  iFileNameLength=ffse->fnlen&0x0ff;
  if ((iFileFlags&FFS_F_DELETE)||(show_deleted))
    {
    sys_printf("%c",(iFileFlags&FFS_F_DELETE)?' ':'b');
    sys_printf("%c",(iFileFlags&FFS_F_BLOCK_ALIGN)?'B':' ');
    sys_printf("%c",(iFileFlags&FFS_F_AUTO_EXECUTE)?'a':' ');
    sys_printf("%c",(iFileFlags&FFS_F_EXT_FIFLE_SYSTEM)?'e':' ');
    sys_printf("%c",(iFileFlags&FFS_F_VOLUME_ID)?'v':' ');
    sys_printf("%c",(iFileFlags&FFS_F_LINK)?'l':' ');
    sys_printf("%c",(iFileFlags&FFS_F_DIRECTORY)?'d':' ');
    sys_printf("%c",(iFileFlags&FFS_F_USER_READ)?'r':' ');
    sys_printf("%c",(iFileFlags&FFS_F_USER_WRITE)?'w':' ');
    sys_printf("%c",(iFileFlags&FFS_F_USER_EXECUTE)?'x':' ');
    sys_printf("%c",(iFileFlags&FFS_F_GROUP_READ)?'r':' ');
    sys_printf("%c",(iFileFlags&FFS_F_GROUP_WRITE)?'w':' ');
    sys_printf("%c",(iFileFlags&FFS_F_GROUP_EXECUTE)?'x':' ');
    sys_printf("%c",(iFileFlags&FFS_F_WORLD_READ)?'r':' ');
    sys_printf("%c",(iFileFlags&FFS_F_WORLD_WRITE)?'w':' ');
    sys_printf("%c",(iFileFlags&FFS_F_WORLD_EXECUTE)?'x':' ');
    sys_printf(" %d:%d ",ffse->uid,ffse->gid);
    sys_printf("a:%3d i:%d ",ffse->aeo,_ffs_GetBit16Value(ffse->inode));
    _ffs_DecodeAndPrintMdate(_ffs_GetBit16Value(ffse->mdate));
    sys_printf(" ");
    _ffs_DecodeAndPrintMtime(_ffs_GetBit16Value(ffse->mtime));
    sys_printf(" %7d",iFileLength);
    cp=ffse->data;
    sys_printf(" ");
    for(i=0;i<iFileNameLength;i++)
      sys_printf("%c",*cp++);
    sys_printf("\n");
    }
  return((ffs_tEntry *)(((char *)ffse)+(sizeof(ffs_tEntry)-1)+iFileLength+iFileNameLength));
  }

bit16u _ffs_GetBit16Value(char *cbit16)
  {
  int tmp;

  tmp=(int)*cbit16++;
  tmp&=0x0ff;
  tmp|=(((int) *cbit16)<<8)&0x0ff00;
  return(tmp);
  }   

void _ffs_PutBit16Value(char *cbit16, bit16u val)
  { 
  
  *cbit16++=(bit8) val;
  *cbit16++=(bit8) (val>>8);
  }

void _ffs_UpdateBit16Value(char *cbit16, bit16u val)
  { 
  
  FWBOpen((bit32u)cbit16);
  FWBWriteByte((bit32u)cbit16++,(bit8) val);
  FWBWriteByte((bit32u)cbit16++,(bit8) (val>>8));
  FWBClose();
  }

bit32 _ffs_GetBit24Value(char *cbit24)
  {
  int tmp;

  tmp=(int)*cbit24++;
  tmp&=0x0ff;
  tmp|=(((int) *cbit24++)<<8)&0x0ff00;
  tmp|=(((int) *cbit24)<<16)&0x0ff0000;
  return(tmp);
  }

void _ffs_PutBit24Value(char *cbit16, bit32u val)
  {
  *cbit16++=(bit8) val;
  *cbit16++=(bit8) (val>>8);
  *cbit16++=(bit8) (val>>16);
  }

bit32 _ffs_GetBit32Value(char *cbit32)
  {
  int tmp;
 
  tmp=(int)*cbit32++;
  tmp&=0x0ff;
  tmp|=(((int) *cbit32++)<<8)&0x0ff00;
  tmp|=(((int) *cbit32++)<<16)&0x0ff0000;
  tmp|=(((int) *cbit32++)<<24)&0x0ff000000;
  return(tmp);
  }

static char  *smonth[]={"Jan","Feb","Mar","Apr","May","Jun",
                           "Jul","Aug","Sep","Oct","Nov","Dec"};

void _ffs_DecodeAndPrintMdate(int mdate)
  {
  int day,month,year;

  year = (mdate>>9)        +1970;
  month= ((mdate>>5)&0x0f) +1;
  day  = (mdate&0x1f)      +1;
  sys_printf("%s %2d, %4d",smonth[month-1],day,year);
  }

void _ffs_DecodeAndPrintMtime(int mtime)
  {
  int hour,min,sec,rhour;
  char ampm;

  rhour= (mtime>>11)&0x1f;
  min  = (mtime>>5)&0x3f;
  sec  = ((mtime)&0x1f)<<1;
  ampm = (rhour>11)?'p':'a';
  hour = rhour%12;
  hour = (hour==0)?12:hour;
  sys_printf("%2d:%02d:%02d%cm",hour,min,sec,ampm);
  }

void _ffs_SplitIntoFirstDirAndRest(char *src,char **d1,char **l1)
  {
  char *cp;

  /* src= [/]dir[/rest/rest]                                                 */
  /*         \ /  \       /                                                  */
  /*         dir     rest                                                    */

  *d1=0;
  *l1=0;
  if (strlen(src)==0) return;
  if (*src=='/') src++;
  if (strlen(src)==0) return;
  *d1=src;
  cp=strchr(src,'/');
  if (cp!=0)
    {
    *cp=0;
    cp++;
    if (strlen(cp))
      *l1=cp;
    }
  }

ffs_tEntry *_ffs_FindFFSEWithNameInDir(ffs_tEntry *ffs,int inode,char *name)
  {

  while(_ffs_GetBit16Value(ffs->inode)!=0x0ffff)
    {
    if ((inode==_ffs_GetBit16Value(ffs->inode))&&
        ((strlen(name)==ffs->fnlen)||(strlen(name)==0))&&
        (_ffs_GetBit16Value(ffs->flags)&FFS_F_DELETE)&&
        (strncmp(ffs->data,name,strlen(name))==0)     )
      {
      return(ffs);
      }
    ffs=(ffs_tEntry *)(((char *)ffs)+(sizeof(ffs_tEntry)-1)+_ffs_GetBit24Value(ffs->flen)+ffs->fnlen);
    }
  return(0);
  }

int ffs_remove(const char *filename)
  {
  char tmpfile[80],*pRestOfFileName,*cp,*dir;
  ffs_tEntry *ffs,*ffse;
  int i,slot,inode;
  char tmpmnt[20];

  /* If first char is not '/'                                                */

  if (filename[0]=='/')
    {
    strcpy(tmpfile,filename);
    }
   else
    {
    get_cwd(tmpfile);
    strcat(tmpfile,"/");
    strcat(tmpfile,filename);
    }
  pRestOfFileName=tmpfile;
  if (ffs_iNumOfFlashMounts==0) return(-1);
  ffs=(ffs_tEntry *)(((char *)ffs_sFlashFileSystemsMounts[0].ffs_ptr)+8);
  for(i=0;i<ffs_iNumOfFlashMounts;i++)
    {
    slot=ffs_sFlashFileSystemsMounts[i].slot;
    sys_sprintf(tmpmnt,"/slot%d",slot);
    if (strncmp(pRestOfFileName,tmpmnt,strlen(tmpmnt))==0)
      {
      ffs=(ffs_tEntry *)(((char *)ffs_sFlashFileSystemsMounts[i].ffs_ptr)+8);
      pRestOfFileName+=strlen(tmpmnt);
      }
    }
  ffse=ffs;
  if (strlen(pRestOfFileName))
    {
    inode=0;
    do
      {
      cp=pRestOfFileName;
      _ffs_SplitIntoFirstDirAndRest(cp,&dir,&pRestOfFileName);
      ffse=_ffs_FindFFSEWithNameInDir(ffs,inode,dir);
      if (!ffse) 
        return(-1);
      if (_ffs_GetBit16Value(ffse->flags)&FFS_F_DIRECTORY)
        inode=_ffs_GetBit16Value(ffse->data+strlen(dir));
       else
        {
        if (pRestOfFileName)
          return(-1);
        }
      }while(pRestOfFileName);
    }
  if (_ffs_GetBit16Value(ffse->flags)&FFS_F_DIRECTORY)
    {  /*Check for an empty directory first                                  */
    inode=_ffs_GetBit16Value(ffse->data+strlen(dir));
    if(_ffs_FindFFSEWithNameInDir(ffs,inode,""))
      return(-1);  /*Directory is not empty!!!                               */
    }
  _ffs_UpdateBit16Value(ffse->flags,_ffs_GetBit16Value(ffse->flags)&~FFS_F_DELETE);
  return(0);
  }

FFS_FILE *ffs_fopen(const char *filename, const char *type)
  {
  char tmpfile[255];
  char tmpmnt[20];
  char *dir,*pRestOfFileName;
  char *cp,autoloadnum=0;
  bit32u datetime;
  int inode,i,slot,rmode,wmode,amode,autoloadok,blk_aln,tmpwflags;
  ffs_tEntry *ffs,*ffse;
  FFS_FILE *pFCB;
                      
  if (!(pFCB=fcb_FileGetFCB()))
    {
/*    _StsGetFCBFail++;                                                      */
    return(0);   
    }  
      
  rmode=FALSE;
  wmode=FALSE;
  amode=FALSE;
  autoloadok=FALSE;
  blk_aln=FALSE;
  while(*type)
    {
    if (*type=='r') rmode=TRUE;
    if (*type=='w') wmode=TRUE;
    if (*type=='a') amode=TRUE; 
    if (*type=='B') blk_aln=TRUE; 
    if (*type=='X')
      {
      autoloadnum=0;
      while (isdigit(type[1]))
        {
        autoloadnum*=10;
        type++;
        autoloadnum+=*type-'0';
        autoloadok=TRUE;
        } 
      }
    type++;
    } 
    
  if (amode) return(0); 
  if ((!rmode)&&(!wmode)) return(0);    
      
  /* If first char is not '/'                                                */

  if (filename[0]=='/')
    {
    strcpy(tmpfile,filename);
    }
   else
    {
    get_cwd(tmpfile);
    strcat(tmpfile,"/");
    strcat(tmpfile,filename);
    }
  pRestOfFileName=tmpfile;
  if (ffs_iNumOfFlashMounts==0) return(0);
  ffs=(ffs_tEntry *)(((char *)ffs_sFlashFileSystemsMounts[0].ffs_ptr)+8);
  for(i=0;i<ffs_iNumOfFlashMounts;i++)
    {
    slot=ffs_sFlashFileSystemsMounts[i].slot;
    sys_sprintf(tmpmnt,"/slot%d",slot);
    if (strncmp(pRestOfFileName,tmpmnt,strlen(tmpmnt))==0)
      {
      ffs=(ffs_tEntry *)(((char *)ffs_sFlashFileSystemsMounts[i].ffs_ptr)+8);
      pRestOfFileName+=strlen(tmpmnt);
      }
    }
  ffse=ffs;
  if (strlen(pRestOfFileName))
    {
    inode=0;
    do
      {
      cp=pRestOfFileName;
      _ffs_SplitIntoFirstDirAndRest(cp,&dir,&pRestOfFileName);
      ffse=_ffs_FindFFSEWithNameInDir(ffs,inode,dir);
      if (!ffse) 
        { 
        if (pRestOfFileName)                       /*Return NULL if not leaf */
          return(0);
        if (!wmode)                                /*Return if not write request*/
          return(0);

        ffse=sys_malloc(i=((sizeof(ffs_tEntry)-1)+strlen(dir))); 
        if (!ffse) return(0);   

        _ffs_PutBit16Value(ffse->inode,inode);

        /*Create File flags                                                  */

        tmpwflags=FFS_F_DELETE;                  
        tmpwflags|=FFS_F_USER_READ|FFS_F_USER_WRITE|FFS_F_USER_EXECUTE;
        tmpwflags|=FFS_F_GROUP_READ|FFS_F_GROUP_WRITE|FFS_F_GROUP_EXECUTE;
        tmpwflags|=FFS_F_WORLD_READ|FFS_F_WORLD_WRITE|FFS_F_WORLD_EXECUTE;
        if (autoloadok) tmpwflags|=FFS_F_AUTO_EXECUTE;
        if (blk_aln) tmpwflags|=FFS_F_BLOCK_ALIGN;

        _ffs_PutBit16Value(ffse->flags,tmpwflags);
        datetime=GetCurrentDateTime();
        _ffs_PutBit16Value(ffse->mdate,(bit16u)(datetime>>16));
        _ffs_PutBit16Value(ffse->mtime,(bit16u)(datetime    ));
        ffse->uid=0;
        ffse->gid=0;
        ffse->fnlen=strlen(dir);
        _ffs_PutBit24Value(ffse->flen,0);
        ffse->aeo=(autoloadok)?autoloadnum:0xff;          
        for(cp=ffse->data,i=0;i<strlen(dir);i++)
          *cp++=dir[i];
        
        pFCB->_AvailableBytes=0;
        pFCB->SubFileSystem=(struct _fs_sFILE *)ffs;
        pFCB->_NextBytePtr=ffse->data+strlen(dir);
        pFCB->_BufferBase=(bit8 *)ffse;
        pFCB->_SubSystemType=FILE_FLASH;
        pFCB->_FileState=FILE_OPEN|FILE_WRITE|FILE_BIN; 
        return(pFCB);
        }
      if (_ffs_GetBit16Value(ffse->flags)&FFS_F_DIRECTORY)
        inode=_ffs_GetBit16Value(ffse->data+strlen(dir));
       else
        {
        if (pRestOfFileName)
          {
          return(0);
          }
        if (wmode) 
          return(0);  
        }
      }while(pRestOfFileName);
    }
  if (ffse==0)
    return(0);
  if (!rmode)
    return(0);
  pFCB->_AvailableBytes=_ffs_GetBit24Value(ffse->flen);
  pFCB->SubFileSystem=0;
  pFCB->_NextBytePtr=ffse->data+strlen(dir);
  if (_ffs_GetBit16Value(ffse->flags)&FFS_F_BLOCK_ALIGN)
    {
    bit8 *newptr;
    bit32u reducelen,blocksize;

    reducelen=0;
    blocksize=FWBGetBlockSize((bit32u)pFCB->_NextBytePtr);
    newptr=(bit8 *)((((bit32u)pFCB->_NextBytePtr)+(blocksize-1))&(~(blocksize-1)));
    if (newptr!=pFCB->_NextBytePtr)
      reducelen=blocksize-(((bit32u)pFCB->_NextBytePtr)&(blocksize-1));
    if (pFCB->_AvailableBytes<reducelen)
      return(0);
    pFCB->_AvailableBytes-=reducelen;
    pFCB->_NextBytePtr=newptr;
    }
  pFCB->_BufferBase=(bit8 *)ffse;
  pFCB->_SubSystemType=FILE_FLASH;
  pFCB->_FileState=FILE_OPEN|FILE_RO|FILE_BIN;  
  return(pFCB);
  }

size_t ffs_fread(void *ptr, size_t size, size_t nitems, FFS_FILE *stream)
  {
  bit32 BytesToRead,NumOfBytesRead; 
  bit8 *pTmpBufPtr;
             
  pTmpBufPtr=(bit8 *)ptr;               
  if ((stream->_FileState&FILE_OPEN)==0) return(0);
  if (stream->_SubSystemType!=FILE_FLASH) return(0);
  if (stream->_AvailableBytes==0) 
    { 
    stream->_FileState|=FILE_EOF;
    return(0);
    }
  BytesToRead=MIN(size*nitems,stream->_AvailableBytes);                 
  NumOfBytesRead=BytesToRead;
  stream->_AvailableBytes-=BytesToRead;
  while(BytesToRead)
    {
    BytesToRead--;
    *pTmpBufPtr++=*stream->_NextBytePtr++; 
    }
  return(NumOfBytesRead/size);
  }

void _ffs_xferstream(FFS_FILE *stream,ffs_tEntry *old,ffs_tEntry *new)
  {
  bit32u offset;

  if (stream->_BufferBase!=(bit8 *)old)
    {sys_printf("Invalid stream change!\n"); while(1) {} }

  offset=((bit32u)stream->_NextBytePtr)-
         ((bit32u)stream->_BufferBase);
  stream->_BufferBase=(bit8 *)new;
  stream->_NextBytePtr=(bit8 *)new;
  stream->_NextBytePtr+=offset;
  }

size_t ffs_fwrite(const void *ptr, size_t size, size_t nitems, FFS_FILE *stream)
  {
  bit32u BytesToWrite,NumOfBytesWritten,flen,clen,nlen,i1;
  ffs_tEntry *ffse,*i2;  
  bit8 *pTmpBufPtr;
             
  ffse=(ffs_tEntry *)stream->_BufferBase;  
  pTmpBufPtr=(bit8 *)ptr;               
  if ((stream->_FileState&FILE_OPEN)==0) return(0);
  if (stream->_SubSystemType!=FILE_FLASH) return(0);
  if ((stream->_FileState&FILE_WRITE)==0) return(0);

  if ((size*nitems)>(stream->_AvailableBytes))
    {
    clen=((bit32u)stream->_NextBytePtr)-
         ((bit32u)stream->_BufferBase)+
         stream->_AvailableBytes-
         ((bit32u)ffse->fnlen)-(sizeof(ffs_tEntry)-1);
    nlen=clen+(size*nitems)-(stream->_AvailableBytes);
    i1=((bit32u)ffse->fnlen)+(sizeof(ffs_tEntry)-1);
    i2=sys_realloc(ffse,nlen+i1);
    if (!i2) return(0);
    if (ffse!=i2) 
      _ffs_xferstream(stream,ffse,i2);
    ffse=(ffs_tEntry *)stream->_BufferBase;  
    }

  BytesToWrite=size*nitems;
  NumOfBytesWritten=BytesToWrite;
  while(BytesToWrite)
    {
    *stream->_NextBytePtr++=*pTmpBufPtr++;
    BytesToWrite--;
    }                                                                                          
  if (stream->_AvailableBytes>=NumOfBytesWritten)
    stream->_AvailableBytes-=NumOfBytesWritten;
   else
     stream->_AvailableBytes=0; 
                                       
  flen=((bit32u)stream->_NextBytePtr)-
       ((bit32u)stream->_BufferBase)+
       stream->_AvailableBytes-
       ((bit32u)ffse->fnlen)-(sizeof(ffs_tEntry)-1);
  _ffs_PutBit24Value(ffse->flen,flen);

  return(NumOfBytesWritten/size);
  }

int ffs_fclose(FFS_FILE *stream)
  {
  int i,BytesToWrite;  
  bit32u flen,fnlen,flsize,pad,padindex;
  bit8 *cp,*dp;
  ffs_tEntry *ffse,*ffs;  
             
  ffse=(ffs_tEntry *)stream->_BufferBase;  
  if ((stream->_FileState&FILE_OPEN)==0) return(EOF);
  if (stream->_SubSystemType!=FILE_FLASH) return(EOF);   
  if (stream->_FileState&FILE_WRITE)
    {
    pad=0;
    _ffs_DumpFlashFileSystemEntry((ffs_tEntry *)stream->_BufferBase,TRUE);
    flen=_ffs_GetBit24Value(ffse->flen);
    fnlen=(bit32u)ffse->fnlen;
    BytesToWrite=flen+fnlen+(sizeof(ffs_tEntry)-1);
    ffs=(ffs_tEntry *)stream->SubFileSystem;
    while(_ffs_GetBit16Value(ffs->inode)!=0x0ffff)
      ffs=(ffs_tEntry *)(((char *)ffs)+(sizeof(ffs_tEntry)-1)+_ffs_GetBit24Value(ffs->flen)+ffs->fnlen);
    dp=(bit8 *)ffs;  
    padindex=fnlen+(sizeof(ffs_tEntry)-1);
    if (_ffs_GetBit16Value(ffse->flags)&FFS_F_BLOCK_ALIGN)
      {
      bit32u filedatabase,blocksize;

      filedatabase = ((bit32u)dp)+padindex;
      blocksize=FWBGetBlockSize(filedatabase);
      pad=(blocksize-(((bit32u)filedatabase)&(blocksize-1)))&(blocksize-1);
      _ffs_PutBit24Value(ffse->flen,flen+pad);
      }

    flsize=_ffs_GetBit32Value(((char *)stream->SubFileSystem)-4);  /*Get Current Flash Disk Size*/
    flsize-=10;                                                   /*Reduce for FFS header*/
    flsize-=(((bit32u)ffs)-((bit32u)stream->SubFileSystem));      /*Reduce for current use*/
    flsize-=pad;                                                  /*Reduce for pad */
    if (BytesToWrite>flsize)
      {
      sys_printf("Insufficient Flash Disk Space!\nCompression may be in order.\n");
      stream->_FileState=FILE_FREE;
      sys_free(ffse);
      return(EOF); 
      }
    FWBOpen((bit32u)dp);
    for(cp=((char *)ffse),i=0;i<BytesToWrite;i++)
      {
      if (i==padindex)
        dp+=pad;
      if(!FWBWriteByte((bit32u)dp++,cp[i]))
        {
        stream->_FileState=FILE_FREE;
        FWBClose();
        sys_free(ffse);
        return(EOF); 
        }
      }             
    FWBClose();
    sys_free(ffse);
    }
  stream->_FileState=FILE_FREE;
  return(0);
  }

int  ffs_fseek(FFS_FILE *stream, bit32 offset, int ptrname)
  {  /*Return 0=OK or EOF=FAIL                                               */
  bit32u flen,CurOff,oflen,i1,i;
  ffs_tEntry *ffse,*i2;  
  char *cp;

  ffse=(ffs_tEntry *)stream->_BufferBase;  
  if ((stream->_FileState&FILE_OPEN)==0) return(EOF);
  if (stream->_SubSystemType!=FILE_FLASH) return(EOF);
  if (_ffs_GetBit16Value(ffse->flags)&FFS_F_BLOCK_ALIGN) return(EOF);
  flen=((bit32u)stream->_NextBytePtr)-
       ((bit32u)stream->_BufferBase)+
       stream->_AvailableBytes-
       ((bit32u)ffse->fnlen)-(sizeof(ffs_tEntry)-1); 
  oflen=flen;
  i1=_ffs_GetBit24Value(ffse->flen);
  if ((flen!=i1))
    {
    sys_printf("fseek(?,%d,%d); ",offset,ptrname);
    sys_printf("flen=%d, ffse->flen=%d.\n",flen,i1);
    }
  CurOff=((bit32u)stream->_NextBytePtr)-
         ((bit32u)stream->_BufferBase)-
         ((bit32u)ffse->fnlen)-(sizeof(ffs_tEntry)-1);     
  switch(ptrname)
    {
    case FFS_SEEK_SET: if (offset<0) return(EOF);
                   if ((offset>flen)&&((stream->_FileState&FILE_WRITE)==0)) return(EOF); 
                   if (offset>flen)
                     {
                     flen=offset; 
                     _ffs_PutBit24Value(ffse->flen,flen);
                     }                   
                   break;  
    case FFS_SEEK_CUR: if ((CurOff+offset)<0) return(EOF);
                   if (((CurOff+offset)>flen)&&((stream->_FileState&FILE_WRITE)==0)) return(EOF);
                   if ((CurOff+offset)>flen)
                     {
                     flen=CurOff+offset;
                     _ffs_PutBit24Value(ffse->flen,flen);
                     }
                   offset+=CurOff;
                   break;  
    case FFS_SEEK_END: if ((flen+offset)<0) return(EOF);
                   if ((offset>0)&&((stream->_FileState&FILE_WRITE)==0)) return(EOF);
                   if (offset>0)
                     {
                     flen+=offset;
                     _ffs_PutBit24Value(ffse->flen,flen);
                     offset=flen;
                     }     
                    else
                     offset+=flen;  
                   break;
    default:       return(EOF);
    } 

  if (flen<oflen)
    {sys_printf("Got real problems, new len=%d, old len=%d",flen,oflen); while(1) {} }
  if (flen>oflen)
    {
    i2=sys_realloc(ffse,i1=(flen+((bit32u)ffse->fnlen)+(sizeof(ffs_tEntry)-1)));
    if (!i2) return(EOF);
    for(i=0,cp=(((char *)i2)+oflen+((bit32u)ffse->fnlen)+(sizeof(ffs_tEntry)-1));i<(flen-oflen);i++)
      *cp++=0xff;
    if (ffse!=i2) 
      _ffs_xferstream(stream,ffse,i2);
    ffse=(ffs_tEntry *)stream->_BufferBase;  
    }

  stream->_NextBytePtr=(bit8 *)(((bit32u)stream->_BufferBase)+
                                ((bit32u)ffse->fnlen)+
                                (sizeof(ffs_tEntry)-1)+
                                offset); 
  stream->_AvailableBytes=flen-offset;   
                           
  return(0);
  }

