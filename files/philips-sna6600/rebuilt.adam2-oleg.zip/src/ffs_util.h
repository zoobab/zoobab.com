/*-----------------------------------------------------------------------------*/
/*                                                                             */
/*   Copyright (C) 1999-2003 by Texas Instruments, Inc.  All rights reserved.  */
/*   Copyright (C) 2001-2003 Telogy Networks.	    						   */
/*                                                                             */
/*-----------------------------------------------------------------------------*/

#include "ffs.h"

void get_cwd(char *tmpfile);
void   _ffs_DumpFlashDisk(int slot,void *ffs,int show_deleted);
int    _ffs_prepend(char *dst,int len,char *preinfo);
int    _ffs_autoexecute(int slot,void *ffs);
int    ffs_autoload(void);
bit32u ffs_dumpfilesystem(int argc, char *argv[]);
void   ffs_ReportFFSInfo(void);
void   ffs_find_new_ffs(void);
void   ffs_findfirst(cbit8 uid,cbit8 gid,cbit8 *rstruct);
void   ffs_findnext(cbit8 uid,cbit8 gid,cbit8 *rstruct);
ffs_tEntry *ffs_GetNextFileSystemEntry(ffs_tEntry *ffse);
void   ls(char filename);
void  ffs_AbandonWrite(FFS_FILE *stream);
int   _ffs_FormatRootFlashDisk(int argc, char *argv[]);

