/*------------------------------------------------------------------------------*/
/*                                                                             	*/
/*   Copyright (C) 1999-2003 by Texas Instruments, Inc.  All rights reserved.  	*/
/*   Copyright (C) 2001-2003 Telogy Networks.	    						   	*/
/*                                                                              */
/*     IMPORTANT - READ CAREFULLY BEFORE PROCEEDING TO USE SOFTWARE.           	*/
/*                                                                             	*/
/*  This document is displayed for you to read prior to using the software     	*/
/*  and documentation.  By using the software and documentation, or opening    	*/
/*  the sealed packet containing the software, or proceeding to download the   	*/
/*  software from a Bulletin Board System(BBS) or a WEB Server, you agree to   	*/
/*  abide by the following Texas Instruments License Agreement. If you choose  	*/
/*  not to agree with these provisions, promptly discontinue use of the        	*/
/*  software and documentation and return the material to the place you        	*/
/*  obtained it.                                                               	*/
/*                                                                             	*/
/*                               *** NOTE ***                                  	*/
/*                                                                             	*/
/*  The licensed materials contain MIPS Technologies, Inc. confidential        	*/
/*  information which is protected by the appropriate MIPS Technologies, Inc.  	*/
/*  license agreement.  It is your responsibility to comply with these         	*/
/*  licenses.                                                                  	*/
/*                                                                             	*/
/*                   Texas Instruments License Agreement                       	*/
/*                                                                             	*/
/*  1. License - Texas Instruments (hereinafter "TI"), grants you a license    	*/
/*  to use the software program and documentation in this package ("Licensed   	*/
/*  Materials") for Texas Instruments broadband products.                      	*/
/*                                                                             	*/
/*  2. Restrictions - You may not reverse-assemble or reverse-compile the      	*/
/*  Licensed Materials provided in object code or executable format.  You may  	*/
/*  not sublicense, transfer, assign, rent, or lease the Licensed Materials    	*/
/*  or this Agreement without written permission from TI.                      	*/
/*                                                                             	*/
/*  3. Copyright - The Licensed Materials are copyrighted. Accordingly, you    	*/
/*  may either make one copy of the Licensed Materials for backup and/or       	*/
/*  archival purposes or copy the Licensed Materials to another medium and     	*/
/*  keep the original Licensed Materials for backup and/or archival purposes.  	*/
/*                                                                             	*/
/*  4. Runtime and Applications Software - You may create modified or          	*/
/*  derivative programs of software identified as Runtime Libraries or         	*/
/*  Applications Software, which, in source code form, remain subject to this  	*/
/*  Agreement, but object code versions of such derivative programs are not    	*/
/*  subject to this Agreement.                                                 	*/
/*                                                                             	*/
/*  5. Warranty - TI warrants the media to be free from defects in material    	*/
/*  and workmanship and that the software will substantially conform to the    	*/
/*  related documentation for a period of ninety (90) days after the date of   	*/
/*  your purchase. TI does not warrant that the Licensed Materials will be     	*/
/*  free from error or will meet your specific requirements.                   	*/
/*                                                                             	*/
/*  6. Remedies - If you find defects in the media or that the software does   	*/
/*  not conform to the enclosed documentation, you may return the Licensed     	*/
/*  Materials along with the purchase receipt, postage prepaid, to the         	*/
/*  following address within the warranty period and receive a refund.         	*/
/*                                                                             	*/
/*  TEXAS INSTRUMENTS                                                          	*/
/*  Application Specific Products, MS 8650                                     	*/
/*  c/o ADAM2 Application Manager                                              	*/
/*  12500 TI Boulevard                                                         	*/
/*  Dallas, TX 75243  - U.S.A.                                                 	*/
/*                                                                             	*/
/*  7. Limitations - TI makes no warranty or condition, either expressed or    	*/
/*  implied, including, but not limited to, any implied warranties of          	*/
/*  merchantability and fitness for a particular purpose, regarding the        	*/
/*  licensed materials.                                                        	*/
/*                                                                             	*/
/*  Neither TI nor any applicable licensor will be liable for any indirect,    	*/
/*  incidental or consequential damages, including but not limited to loss of  	*/
/*  profits.                                                                   	*/
/*                                                                             	*/
/*  8. Term - The license is effective until terminated.   You may terminate   	*/
/*  it at any other time by destroying the program together with all copies,   	*/
/*  modifications and merged portions in any form. It also will terminate if   	*/
/*  you fail to comply with any term or condition of this Agreement.           	*/
/*                                                                             	*/
/*  9. Export Control - The re-export of United States origin software and     	*/
/*  documentation is subject to the U.S. Export Administration Regulations or  	*/
/*  your equivalent local regulations. Compliance with such regulations is     	*/
/*  your responsibility.                                                       	*/
/*                                                                             	*/
/*                         *** IMPORTANT NOTICE ***                            	*/
/*                                                                             	*/
/*  Texas Instruments (TI) reserves the right to make changes to or to         	*/
/*  discontinue any semiconductor product or service identified in this        	*/
/*  publication without notice. TI advises its customers to obtain the latest  	*/
/*  version of the relevant information to verify, before placing orders,      	*/
/*  that the information being relied upon is current.                         	*/
/*                                                                             	*/
/*  TI warrants performance of its semiconductor products and related          	*/
/*  software to current specifications in accordance with TI's standard        	*/
/*  warranty. Testing and other quality control techniques are utilized to     	*/
/*  the extent TI deems necessary to support this warranty. Unless mandated    	*/
/*  by government requirements, specific testing of all parameters of each     	*/
/*  device is not necessarily performed.                                       	*/
/*                                                                             	*/
/*  Please be aware that Texas Instruments products are not intended for use   	*/
/*  in life-support appliances, devices, or systems. Use of a TI product in    	*/
/*  such applications without the written approval of the appropriate TI       	*/
/*  officer is prohibited. Certain applications using semiconductor devices    	*/
/*  may involve potential risks of injury, property damage, or loss of life.   	*/
/*  In order to minimize these risks, adequate design and operating            	*/
/*  safeguards should be provided by the customer to minimize inherent or      	*/
/*  procedural hazards. Inclusion of TI products in such applications is       	*/
/*  understood to be fully at the risk of the customer using TI devices or     	*/
/*  systems.                                                                   	*/
/*                                                                             	*/
/*  TI assumes no liability for TI applications assistance, customer product   	*/
/*  design, software performance, or infringement of patents or services       	*/
/*  described herein. Nor does TI warrant or represent that license, either    	*/
/*  expressed or implied, is granted under any patent right, copyright, mask   	*/
/*  work right, or other intellectual property right of TI covering or         	*/
/*  relating to any combination, machine, or process in which such             	*/
/*  semiconductor products or services might be or are used.                   	*/
/*                                                                             	*/
/*  All company and/or product names are trademarks and/or registered          	*/
/*  trademarks of their respective manaufacturers.                             	*/
/*------------------------------------------------------------------------------*/

#include "_stdio.h"
#include "ffs_util.h"
#include "env.h"
#include "flashop.h"
#include "hw.h" 
#include "files.h" 
#include "mms.h" 
#include "support.h" 
#include "fcb.h" 
#include "avreset.h" 
#include "sio.h" 
#include "main.h" 

void AppCopyVectors(void);
bit32u progloader(int argc, char *argv[]);
void init_env(void);
bit32u getflashsize(bit32u base, bit32u size);

/* Flash File System guidlines                                               */
/* The flash file system can only open read write and close a file that      */
/*  the rights apply. That is even root has no authority to read a not       */
/*  owned file.                                                              */
/*                                                                           */
/* FindFirst finds the first file in the global file system that meets the   */
/*  rights. Only root can see all file entries, but cannot read/write them.  */
/*                                                                           */
/* INodes are FFS dependent that is the system can have many FFS and inode   */
/*  is maintained for each.                                                  */
/*                                                                           */

extern ffs_tMountPoint ffs_sFlashFileSystemsMounts[NUM_OF_SLOTS+1];
extern int              ffs_iNumOfFlashMounts;   
          
void _ffs_DumpFlashDisk(int slot,void *ffs,int show_deleted)
  {
  ffs_tEntry *ffse;
          
  if (strncmp(ffs,"FFS",3)!=0) return;        
  ffse=(ffs_tEntry *)(((char *)ffs)+8);        
  if (slot)
    sys_printf("\nFlashDiskDump for /slot%d\n",slot);
   else
    sys_printf("\nFlashDiskDump for /\n");

  while(_ffs_GetBit16Value(ffse->inode)!=0xffff)
    {
    ffse=_ffs_DumpFlashFileSystemEntry(ffse,show_deleted);
    }
  }

int _ffs_prepend(char *dst,int len,char *preinfo)
  {
  int dlen,plen;
  char *sp,*dp;

  dlen=strlen(dst);
  plen=strlen(preinfo);
  if ((plen+dlen)>=len)
    return(FALSE);
  if (plen==0) return(TRUE);
  
  for(dp=dst+dlen+plen,sp=dst+dlen;dlen;dlen--)
    *dp--=*sp--;
  *dp--=*sp--;
  for(sp=preinfo+(plen-1);plen;plen--)
    *dp--=*sp--;
  return(TRUE);
  }


int _ffs_autoexecute(int slot,void *ffs)
  {
  ffs_tEntry *ffse,*ffse2;
  int i,flags,idir,iFileNameLength,j,flags2,iFileNameLength2,inode,argc,dsts,tsts,amax;
  char appname[80],*cp,dirname[32],*argv[10],aabort[2],achar,AppToRun[80];
  bit32u gopc;
 
  amax=(cp=sys_getenv("autoload"))?atoui(cp):99;
  if (amax<10) amax=10;
  if (amax>99) amax=99;
  dsts=0;
  if (strncmp(ffs,"FFS",3)!=0) return(1);        
  aabort[0]=aabort[1]=0;
  for(i=0,tsts=0;(i<amax)&&((tsts==0)||(i<90));i++)
    {
    ffse=(ffs_tEntry *)(((char *)ffs)+8); 

    while(_ffs_GetBit16Value(ffse->inode)!=0xffff)
      {
      if (i>9)
        {
        if (SioInCharCheck(&achar))
          {
          aabort[1]=aabort[0];
          aabort[0]=achar;
          if ((aabort[0]==1)&&(aabort[1]==1))
            {
            sys_printf("Autoload Abort...\n");
            return(1);
            }
          }
        }
      flags=_ffs_GetBit16Value(ffse->flags);
      if ((flags&FFS_F_AUTO_EXECUTE)&&(flags&FFS_F_DELETE))
        {
        if (ffse->aeo==i)
          {
          iFileNameLength=ffse->fnlen&0x0ff;
          idir=_ffs_GetBit16Value(ffse->inode);
          cp=ffse->data;
          for(j=0;(j<iFileNameLength)&&(j<((sizeof appname)-1));j++)
            appname[j]=*cp++;
          appname[j]=0;
          strcpy(AppToRun,appname);
          while(idir)
            {
            ffse2=(ffs_tEntry *)(((char *)ffs)+8); 
            while(_ffs_GetBit16Value(ffse2->inode)!=0xffff)
              {
              flags2=_ffs_GetBit16Value(ffse2->flags);
              if ((flags2&FFS_F_DIRECTORY)&&(flags2&FFS_F_DELETE))
                {
                iFileNameLength2=ffse2->fnlen&0x0ff;
                inode=_ffs_GetBit16Value(ffse2->data+iFileNameLength2);
                if (inode==idir)
                  {
                  idir=_ffs_GetBit16Value(ffse2->inode);
                  _ffs_prepend(appname,sizeof appname,"/");
                  cp=ffse2->data;
                  for(j=0;(j<iFileNameLength2)&&(j<((sizeof dirname)-1));j++) 
                    dirname[j]=*cp++;
                  dirname[j]=0;
                  _ffs_prepend(appname,sizeof appname,dirname);
                  }
                }
              ffse2=ffs_GetNextFileSystemEntry(ffse2);
              }
            }
          _ffs_prepend(appname,sizeof appname,"/");

          AppCopyVectors();
          argc=1;
          argv[0]=appname;
            gopc=progloader(argc,argv); 
          init_env();
          ResetMMS();
          if (gopc)
            {
            dsts=ExeAt(gopc,argc,argv,(char **)env_vars);
            PrintfRestore();
            }
          if (dsts&0x80000000)
            tsts=dsts;
          }
        }
      ffse=ffs_GetNextFileSystemEntry(ffse);
      }
    }
  return(tsts);
  }

int ffs_autoload(void)
  {
  int i;

  for(i=0;i<ffs_iNumOfFlashMounts;i++)
    {
    _ffs_autoexecute(i,ffs_sFlashFileSystemsMounts[i].ffs_ptr);
    }
  return(0);
  }

bit32u ffs_dumpfilesystem(int argc, char *argv[])
  {
  int i,show_deleted;
  char *cp;

  show_deleted=FALSE;
  for(i=1;i<argc;i++)
    {
    cp=argv[i];
    if (*cp=='-')
      {
      cp++;
      while(*cp)
        {
        switch(*cp)
          {
          case 'a': show_deleted=TRUE;
                    break;
          default:  break;
          }
        cp++;
        } 
      }
    }
  for(i=0;i<ffs_iNumOfFlashMounts;i++)
    {
    _ffs_DumpFlashDisk(i,ffs_sFlashFileSystemsMounts[i].ffs_ptr,show_deleted);
    }
  return(0);
  }

void ffs_ReportFFSInfo(void)
  {
  ffs_tEntry *ffse;
  int i,iSlot,iFlashFileSystemSize,iCurrentFreeSpace,iFreeSpaceAfterCleanUp;
  int iCurrentUsedSpace,iFileLength,iFileNameLength,iFileFlags;
 
  sys_printf("\n");
  sys_printf("Mounted File Systems: %d.\n",ffs_iNumOfFlashMounts);
  for(i=0;i<ffs_iNumOfFlashMounts;i++)
    {
    ffse=ffs_sFlashFileSystemsMounts[i].ffs_ptr;
    iSlot=ffs_sFlashFileSystemsMounts[i].slot;
    ffse=(ffs_tEntry *)(((char *)ffse)+4);
    iFlashFileSystemSize=_ffs_GetBit32Value((char *)ffse);
    iCurrentFreeSpace=iFreeSpaceAfterCleanUp=iFlashFileSystemSize-10;
    iCurrentUsedSpace=0;
    ffse=(ffs_tEntry *)(((char *)ffse)+4);
    while(_ffs_GetBit16Value(ffse->inode)!=0xffff)
      {
      iFileLength=_ffs_GetBit24Value(ffse->flen);
      iFileNameLength=ffse->fnlen&0x0ff;
      iFileFlags=_ffs_GetBit16Value(ffse->flags);
      ffse=(ffs_tEntry *)(((char *)ffse)+(sizeof(ffs_tEntry)-1)+iFileLength+iFileNameLength);
      iCurrentFreeSpace-=(sizeof(ffs_tEntry)-1)+iFileLength+iFileNameLength;
      if (iFileFlags&FFS_F_DELETE)
        {
        iFreeSpaceAfterCleanUp-=(sizeof(ffs_tEntry)-1)+iFileLength+iFileNameLength;
        iCurrentUsedSpace+=iFileLength;
        }
      }
    sys_printf("Slot=%2d, Total=%8d, Used=%8d, Available=",iSlot,iFlashFileSystemSize-10,iCurrentUsedSpace);
    if (iCurrentFreeSpace==iFreeSpaceAfterCleanUp)
      sys_printf("%8d\n",iCurrentFreeSpace);
     else
      sys_printf("%8d / %d\n",iCurrentFreeSpace,iFreeSpaceAfterCleanUp);
    }
  }

/*void ffs_find_new_ffs(void)                                                */
/*  {                                                                        */
/*                                                                           */
/*                                                                           */
/*  }                                                                        */

/*void ffs_findfirst(cbit8 uid,cbit8 gid,cbit8 *rstruct)                     */
/*  {                                                                        */
/*                                                                           */
/*                                                                           */
/*                                                                           */
/*  }                                                                        */

/*void ffs_findnext(cbit8 uid,cbit8 gid,cbit8 *rstruct)                      */
/*  {                                                                        */
/*                                                                           */
/*                                                                           */
/*                                                                           */
/*  }                                                                        */


ffs_tEntry *ffs_GetNextFileSystemEntry(ffs_tEntry *ffse)
  {
  int   iFileNameLength;
  bit32 iFileLength;

  iFileLength=_ffs_GetBit24Value(ffse->flen);
  iFileNameLength=ffse->fnlen&0x0ff;
  return((ffs_tEntry *)(((char *)ffse)+(sizeof(ffs_tEntry)-1)+iFileLength+iFileNameLength));
  }

/*void ls(char filename)                                                     */
/*  {                                                                        */
/*                                                                           */
/*  AceGetMyUidGid(&uid,&gid);                                               */
/*                                                                           */
/*                                                                           */
/*                                                                           */
/*                                                                           */
/*  }                                                                        */

void get_cwd(char *tmpfile)
  {
  strcpy(tmpfile,"/tmp");
  }

void ffs_AbandonWrite(FFS_FILE *stream)
  {
  ffs_tEntry *ffse;  

  if ((stream->_FileState&FILE_OPEN)==0) return;
  if (stream->_SubSystemType!=FILE_FLASH) return;
  if ((stream->_FileState&FILE_WRITE)==0) return;
  ffse=(ffs_tEntry *)stream->_BufferBase;  
  stream->_FileState=FILE_FREE;
  sys_free(ffse);
  }

static char RootFlash[]={'F','F','S',0,0x00,0x00,0x0e,0x00,
                         0,0,0xff,0x83,0x7e,0xff,0x34,0x12,0,0,3,2,0,0,0,
                         'e','t','c',
                         1,0,
                         0,0,0xff,0x83,0x7e,0xff,0x34,0x12,0,0,3,2,0,0,0,
                         'b','i','n',
                         2,0,
                         1,0,0xc0,0x81,0xda,0x3a,0,0,0,0,8,7,0,0,3,
                         0x68,0x6f,0x73,0x74,0x6e,0x61,0x6d,0x65,
                         0x6d,0x79,0x73,0x65,0x6c,0x66,0x0a,
                         0xff,0xff};

int _ffs_FormatRootFlashDisk(int argc, char *argv[])
  {
  int i,slot;
  bit32u adr1,bootblocksize,envblocksize;

  slot=0;
  sys_printf("Formating Flash Disk\n");
  if (ffs_RemoveSlotMount(slot)==FFS_ERRS_NO_ERROR)
    sys_printf("Flash Disk Unmounted\n");

  bootblocksize=FWBGetBlockSize(CS0_BASE);
  if (bootblocksize<MIN_BOOT_BLOCK_SIZE) 
    bootblocksize=MIN_BOOT_BLOCK_SIZE;

  envblocksize=FWBGetBlockSize(CS0_BASE+CS0_SIZE-1);
  if (envblocksize<MIN_ENV_BLOCK_SIZE) 
    envblocksize=MIN_ENV_BLOCK_SIZE;

  i=getflashsize(CS0_BASE,CS0_SIZE)/(1024*1024);
  sys_printf("Calculated Flash size: %d Mbytes\n",i);

  adr1=1024*1024*i;
  adr1-=bootblocksize+envblocksize;

  if (argc!=7)
    {
    if (!FWBErase(CS0_BASE+bootblocksize,adr1,1))
      {
      sys_printf("\nFormatting Flash disk Failed!");
      return(0);
      }
    }
  sys_printf("\n");  
  FWBOpen(CS0_BASE+bootblocksize);
  for(i=0;i<sizeof(RootFlash);i++) 
    {
    if ((i>=4)&&(i<=7))
      {
      FWBWriteByte(CS0_BASE+bootblocksize+i,(char)(adr1>>((i-4)*8)));
      }
     else
      FWBWriteByte(CS0_BASE+bootblocksize+i,RootFlash[i]);
    }
  FWBClose();
  if (ffs_AddFileSystem(0,(void *)(CS0_BASE+bootblocksize))==FFS_ERRS_NO_ERROR)
    sys_printf("Flash Disk Mounted\n");
  return(0);
  }

ffs_tEntry *GetFfsBase(int ffs_index)
  {
  if(ffs_index<ffs_iNumOfFlashMounts)
    return(ffs_sFlashFileSystemsMounts[ffs_index].ffs_ptr);
   else
    return(0);
  }
