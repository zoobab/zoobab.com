/*-----------------------------------------------------------------------------*/
/*                                                                             */
/*   Copyright (C) 1996-2003 by Texas Instruments, Inc.  All rights reserved.  */
/*   Copyright (C) 2001-2003 Telogy Networks.	    						   */
/*                                                                             */
/*     IMPORTANT - READ CAREFULLY BEFORE PROCEEDING TO USE SOFTWARE.           */
/*                                                                             */
/*  This document is displayed for you to read prior to using the software     */
/*  and documentation.  By using the software and documentation, or opening    */
/*  the sealed packet containing the software, or proceeding to download the   */
/*  software from a Bulletin Board System(BBS) or a WEB Server, you agree to   */
/*  abide by the following Texas Instruments License Agreement. If you choose  */ 
/*  not to agree with these provisions, promptly discontinue use of the        */
/*  software and documentation and return the material to the place you        */
/*  obtained it.                                                               */
/*                                                                             */
/*                               *** NOTE ***                                  */
/*                                                                             */
/*  The licensed materials contain MIPS Technologies, Inc. confidential        */
/*  information which is protected by the appropriate MIPS Technologies, Inc.  */
/*  license agreement.  It is your responsibility to comply with these         */
/*  licenses.                                                                  */
/*                                                                             */
/*                   Texas Instruments License Agreement                       */
/*                                                                             */
/*  1. License - Texas Instruments (hereinafter "TI"), grants you a license    */
/*  to use the software program and documentation in this package ("Licensed   */
/*  Materials") for Texas Instruments broadband products.                      */
/*                                                                             */
/*  2. Restrictions - You may not reverse-assemble or reverse-compile the      */
/*  Licensed Materials provided in object code or executable format.  You may  */
/*  not sublicense, transfer, assign, rent, or lease the Licensed Materials    */
/*  or this Agreement without written permission from TI.                      */
/*                                                                             */
/*  3. Copyright - The Licensed Materials are copyrighted. Accordingly, you    */
/*  may either make one copy of the Licensed Materials for backup and/or       */
/*  archival purposes or copy the Licensed Materials to another medium and     */
/*  keep the original Licensed Materials for backup and/or archival purposes.  */
/*                                                                             */
/*  4. Runtime and Applications Software - You may create modified or          */
/*  derivative programs of software identified as Runtime Libraries or         */
/*  Applications Software, which, in source code form, remain subject to this  */
/*  Agreement, but object code versions of such derivative programs are not    */
/*  subject to this Agreement.                                                 */
/*                                                                             */
/*  5. Warranty - TI warrants the media to be free from defects in material    */
/*  and workmanship and that the software will substantially conform to the    */
/*  related documentation for a period of ninety (90) days after the date of   */
/*  your purchase. TI does not warrant that the Licensed Materials will be     */
/*  free from error or will meet your specific requirements.                   */
/*                                                                             */
/*  6. Remedies - If you find defects in the media or that the software does   */
/*  not conform to the enclosed documentation, you may return the Licensed     */
/*  Materials along with the purchase receipt, postage prepaid, to the         */
/*  following address within the warranty period and receive a refund.         */
/*                                                                             */
/*  TEXAS INSTRUMENTS                                                          */
/*  Application Specific Products, MS 8650                                     */
/*  c/o ADAM2 Application Manager                                              */
/*  12500 TI Boulevard                                                         */
/*  Dallas, TX 75243  - U.S.A.                                                 */
/*                                                                             */
/*  7. Limitations - TI makes no warranty or condition, either expressed or    */
/*  implied, including, but not limited to, any implied warranties of          */
/*  merchantability and fitness for a particular purpose, regarding the        */
/*  licensed materials.                                                        */
/*                                                                             */
/*  Neither TI nor any applicable licensor will be liable for any indirect,    */
/*  incidental or consequential damages, including but not limited to loss of  */
/*  profits.                                                                   */
/*                                                                             */
/*  8. Term - The license is effective until terminated.   You may terminate   */
/*  it at any other time by destroying the program together with all copies,   */
/*  modifications and merged portions in any form. It also will terminate if   */
/*  you fail to comply with any term or condition of this Agreement.           */
/*                                                                             */
/*  9. Export Control - The re-export of United States origin software and     */
/*  documentation is subject to the U.S. Export Administration Regulations or  */
/*  your equivalent local regulations. Compliance with such regulations is     */
/*  your responsibility.                                                       */
/*                                                                             */
/*                         *** IMPORTANT NOTICE ***                            */
/*                                                                             */
/*  Texas Instruments (TI) reserves the right to make changes to or to         */
/*  discontinue any semiconductor product or service identified in this        */
/*  publication without notice. TI advises its customers to obtain the latest  */
/*  version of the relevant information to verify, before placing orders,      */
/*  that the information being relied upon is current.                         */
/*                                                                             */
/*  TI warrants performance of its semiconductor products and related          */
/*  software to current specifications in accordance with TI's standard        */
/*  warranty. Testing and other quality control techniques are utilized to     */
/*  the extent TI deems necessary to support this warranty. Unless mandated    */
/*  by government requirements, specific testing of all parameters of each     */
/*  device is not necessarily performed.                                       */
/*                                                                             */
/*  Please be aware that Texas Instruments products are not intended for use   */
/*  in life-support appliances, devices, or systems. Use of a TI product in    */
/*  such applications without the written approval of the appropriate TI       */
/*  officer is prohibited. Certain applications using semiconductor devices    */
/*  may involve potential risks of injury, property damage, or loss of life.   */
/*  In order to minimize these risks, adequate design and operating            */
/*  safeguards should be provided by the customer to minimize inherent or      */
/*  procedural hazards. Inclusion of TI products in such applications is       */
/*  understood to be fully at the risk of the customer using TI devices or     */
/*  systems.                                                                   */
/*                                                                             */
/*  TI assumes no liability for TI applications assistance, customer product   */
/*  design, software performance, or infringement of patents or services       */
/*  described herein. Nor does TI warrant or represent that license, either    */
/*  expressed or implied, is granted under any patent right, copyright, mask   */
/*  work right, or other intellectual property right of TI covering or         */
/*  relating to any combination, machine, or process in which such             */
/*  semiconductor products or services might be or are used.                   */
/*                                                                             */
/*  All company and/or product names are trademarks and/or registered          */
/*  trademarks of their respective manaufacturers.                             */
/*                                                                             */
/*-----------------------------------------------------------------------------*/

#include "_stdio.h"
#include "env.h"
#include "flashop.h"
#include "hw.h"
#include "sio.h"
#include "shell.h"

t_env_var env_vars[SYS_USER_ENVIRONMENT_MAX_INDEX];

/*control,checksum,index,size,name,val                                       */
/*42/ff   sum      env   ##   ascii                                          */

int sys_unsetenv(char *var)
  {
  return(sys_setenv(var,0));
  }

char *EnvGetEnvBase(int *bs)
  {
  int blocksize;
  bit32u itmp;

  blocksize=FWBGetBlockSize(CS0_BASE);
  if (blocksize<(MIN_ENV_BLOCK_SIZE)) blocksize=MIN_ENV_BLOCK_SIZE;
  *bs=blocksize;
  itmp=(CS0_BASE+CS0_SIZE)-blocksize;
  return((char *)itmp);
  }

int EnvInit(void)
  {
  char *fb,*cp,control;
  int i,sts,blocksize;
#ifdef ACPEP
  FWBGet_flash_type();
#endif /* ACPEP */

  cp=fb=EnvGetEnvBase(&blocksize);
  control=*fb;
  if (control==0x42)
    return(TRUE);
  for(i=0;(i<128)&&(*fb==((char)0xff));i++,fb++)
    {
    }
  if (i==128)
    return(TRUE);
  
  /*Env flash is invalid!                                                    */
#ifdef _STAND_ALONE_
  SioReset();
#endif
  sts=FWBErase((bit32u)cp,blocksize,0);
    
  return(sts==0);
  }

int setenv(char *var,char *val)
  {
  char *nfe,*cfe,checksum,esum,control,*s1ptr,*s2ptr,*fb,*wfe,envrec[FLASH_ENV_ENTRY_SIZE],*cp,*eval,*evar;
  int varindex,index,size,s1len,s2len,done,i,highest,blocksize,j;

  varindex=-1;
  highest=0;
  fb=EnvGetEnvBase(&blocksize);
  for(done=FALSE,wfe=cfe=fb,i=0;(!done)&&(i<MAX_ENV_ENTRY);i++,cfe=nfe)
    {
  	if (cfe>=(fb+blocksize)) return(4);
    wfe=cfe;
    nfe=cfe+FLASH_ENV_ENTRY_SIZE;
    control=*cfe++;
    checksum=*cfe++;
    index=((int)*cfe++)&0x0ff;
    size=(control==0x42)?(((int)*cfe++)&0x0ff):0;
    if (size>(FLASH_ENV_ENTRY_SIZE-4)) 
      return(1);
    s1ptr=cfe;
    s1len=((control==0x42)&&(size))?strlen(s1ptr):0;
    if (s1len>(FLASH_ENV_ENTRY_SIZE-5)) 
      return(1);
    s2ptr=cfe+s1len+1;
    s2len=((control==0x42)&&(size))?strlen(s2ptr):0;
    if (s2len>(FLASH_ENV_ENTRY_SIZE-5)) 
      return(1);
    if ((s2len+s1len)>(FLASH_ENV_ENTRY_SIZE-6))
      return(1);
    esum=0;
    for(j=0;j<size;j++) esum+=s1ptr[j];

    if (control==(char)0xff) done=TRUE;
    if ((control!=(char)0x42)&&(control!=(char)0xff)) return(1);
    if (control==0x42)
      {
      if (checksum!=esum) return(2);
      if ((size)&&((size<(s1len+s2len+2))||(size>(s1len+s2len+2+3)))) return(3);
      if (size)
        {
        if (index>highest) highest=index;
        if (strcmp(s1ptr,var)==0)
          varindex=index;
        }
       else
        {
        if (index==highest) highest=index-1; /*last env deleted!             */
        if (varindex==index) varindex=-1;
        }
      }
    }
  if (i>=MAX_ENV_ENTRY) return(4);

  /*See if the current value is what we want!                                */

  if ((varindex!=-1)&&(val))  /*There is a current value to get reset        */
    {
    evar=sys_getienv(varindex);  
    if (evar)                 /*It exist                                     */
      {
      eval=sys_getenv(evar);
      if (eval)               /*It has a value                               */
        {
        if ((strcmp(var,evar)==0)&&(strcmp(val,eval)==0))  /*Is it the same? */
          return(0);                                       /*No need to write!*/
        }
      }
    }

  /*Get the first free spot!                                                 */

  if ((varindex==-1)&&(val))  /*Do we want to add an entry?                  */
    {
    i=0;
    while((sys_getienv(i))&&(i<MAX_ENV_ENTRY))
      i++;
    if (i<MAX_ENV_ENTRY)
      varindex=i;
    }

  /*Now write a new record for the var                                       */

  s1len=strlen(var);
  s2len=(val)?strlen(val):0;
  checksum=0;
  if (val)
    {
    for(i=0;i<s1len;i++) checksum+=var[i];
    for(i=0;i<s2len;i++) checksum+=val[i];
    size=4+s1len+s2len+2;
    }
   else
    {
    if (varindex==-1) return(5);
    size=4;
    }
  if (size>FLASH_ENV_ENTRY_SIZE) return(6);
  cp=envrec;
  *cp++=0x42;
  *cp++=checksum;
  *cp++=(varindex==-1)?(highest+1):varindex;
  *cp++=(val)?(s1len+s2len+2):0;
  for(i=0;i<s1len;i++) *cp++=var[i];
  *cp++=0;
  for(i=0;i<s2len;i++) *cp++=val[i];
  *cp++=0;
  FWBOpen((int)wfe);
  for(i=0;i<size;i++,wfe++)
    FWBWriteByte((int)wfe,envrec[i]);
  FWBClose();
  return(0);
  }

int sys_setenv(char *var,char *val)
{
	int ret;
	ret = setenv(var, val);
   	if (ret == 4) /* No Space left in ENV BLOCK */
	{
		fixenv(0, NULL);
		ret = setenv(var, val);
	}
	return ret;	
}

char *sys_getenv(char *var)
  {
  char *s2rtn,*nfe,*cfe,checksum,esum,control,*s1ptr,*s2ptr,*fb,*wfe;
  int index,size,s1len,s2len,done,i,vindex,blocksize,j;

  s2rtn=0;
  vindex=-1;
  fb=EnvGetEnvBase(&blocksize);
  for(done=FALSE,cfe=fb,i=0;(!done)&&(i<MAX_ENV_ENTRY);i++,cfe=nfe)
    {
  	if (cfe>=(fb+blocksize)) break;
    wfe=nfe=cfe+FLASH_ENV_ENTRY_SIZE;
    control=*cfe++;
    checksum=*cfe++;
    index=((int)*cfe++)&0x0ff;
    size=(control==0x42)?(((int)*cfe++)&0x0ff):0;
    if (size>(FLASH_ENV_ENTRY_SIZE-4)) 
      {
      size=0; 
      checksum=0;
      index=0x01ff;
      }
    s1ptr=cfe;
    s1len=((control==0x42)&&(size))?strlen(s1ptr):0;
    if (s1len>(FLASH_ENV_ENTRY_SIZE-5)) 
      {
      size=0; 
      s1len=0; 
      checksum=0;
      index=0xff;
      }
    s2ptr=cfe+s1len+1;
    s2len=((control==0x42)&&(size))?strlen(s2ptr):0;
    if (s2len>(FLASH_ENV_ENTRY_SIZE-5)) 
      {
      size=0; 
      s1len=0; 
      s2len=0; 
      checksum=0;
      index=0xff;
      }
    if ((s2len+s1len)>(FLASH_ENV_ENTRY_SIZE-6)) 
      {
      size=0; 
      s1len=0; 
      s2len=0; 
      checksum=0;
      index=0xff;
      }
    esum=0;
    for(j=0;j<size;j++) esum+=s1ptr[j];

    if (control==(char)0xff) done=TRUE;
    if ((control!=(char)0x42)&&(control!=(char)0xff)) return(0);
    if (control==0x42)
      {
      if (checksum!=esum) return(0);
      if ((size)&&((size<(s1len+s2len+2))||(size>(s1len+s2len+2+3)))) return(0);
      if (size)
        {
        if (strcmp(s1ptr,var)==0)   /*and what we want                       */
          {
          s2rtn=s2ptr;
          vindex=index;
          }
        }
       else
        {
        if (vindex==index)   /*My env was Deleted                            */
          {
          vindex=-1;
          s2rtn=0;
          }
        }
      }
    }
  return(s2rtn);
  }

char *sys_getienv(int sindex)
  {
  char *LastEnvFound,*fb,*cfe,*nfe,control,checksum,esum,*s1ptr,*s2ptr,*sfe;
  int index,size,s1len,s2len,i,done,blocksize;

  fb=EnvGetEnvBase(&blocksize);

  LastEnvFound=0;
  for(done=FALSE,cfe=fb,i=0;(!done)&&(i<MAX_ENV_ENTRY);i++,cfe=nfe)
    {
    nfe=cfe+FLASH_ENV_ENTRY_SIZE;
    sfe=cfe;
    control=*cfe++;
    cfe++;
    index=((int)*cfe)&0x0ff;
    if (control==(char)0xff) 
      done=TRUE;
    if ((index==sindex)&&(control==0x42))
      LastEnvFound=sfe;
    }
  if (!LastEnvFound) 
    return(0);
  
  cfe=LastEnvFound;
  control=*cfe++;
  checksum=*cfe++;
  index=((int)*cfe++)&0x0ff;
  size =((int)*cfe++)&0x0ff;
  if (size>(FLASH_ENV_ENTRY_SIZE-4)) 
    return(0);
  s1ptr=cfe;
  s1len=(size)?strlen(s1ptr):0;
  if (s1len>(FLASH_ENV_ENTRY_SIZE-5)) 
    return(0);
  s2ptr=cfe+s1len+1;
  s2len=(size)?strlen(s2ptr):0;
  if (s2len>(FLASH_ENV_ENTRY_SIZE-5)) 
    return(0);
  if ((s1len+s2len)>(FLASH_ENV_ENTRY_SIZE-6)) 
    return(0);
  esum=0;
  for(i=0;i<size;i++) esum+=s1ptr[i];

  if (checksum!=esum) 
    return(0);
  if ((size)&&((size<(s1len+s2len+2))||(size>(s1len+s2len+2+3)))) 
    return(0);
  if (size)
    return(s1ptr);
  return(0);
  }

void init_env(void)
  {
  int i,j;
  char *var,*val;

  for(i=0;i<SYS_USER_ENVIRONMENT_MAX_INDEX;i++)
    {
    env_vars[i].name=NULL;
    env_vars[i].val=NULL;
    }

  for(i=0,j=0;(i<MAX_ENV_ENTRY)&&(j<(SYS_USER_ENVIRONMENT_MAX_INDEX-1));i++)
    {
    var=sys_getienv(i);
    if(var)
      {
      val=sys_getenv(var);
      if (val)
        {
        env_vars[j].name=var;
        env_vars[j].val=val;
		j++;
        }
      }
    }
  }



