/*-----------------------------------------------------------------------------*/
/*   Copyright (C) 1996-2003 by Texas Instruments, Inc.  All rights reserved.  */
/*   Copyright (C) 2001-2003 Telogy Networks, Inc.							   */
/*-----------------------------------------------------------------------------*/

#include "_stdio.h"
#include "revision.h"
#include "hw.h"
#include "env.h"
#include "mms.h"
#include "sio.h"
#include "flashop.h"
#include "shell.h"
#ifdef FFS_SUPPORT
#include "files.h"
#endif
//#if defined(DHCP_SUPPORT) || defined(FTP_SERVER_SUPPORT) //By Charles addition for Support tftp server 08-13-2004
#if defined(DHCP_SUPPORT) || defined(FTP_SERVER_SUPPORT) || defined(TFTP_SERVER_SUPPORT)
#include "tinyip.h"
#endif
#include "main.h"

void SioInit(void);

extern unsigned int SetupCpuFrequency(void);
void FlushICache();
void FlushDCache();

unsigned int _CpuFrequency;
unsigned int _SbusFrequency;
unsigned int _PbusFrequency;
unsigned int _MemSize;

int autoloadFlag = FALSE;
#if  defined(FTP_SERVER_SUPPORT) || defined(TFTP_SERVER_SUPPORT)
int crashFlag = CRASH_NONE;
#endif	/* defined(FTP_SERVER_SUPPORT) || defined(TFTP_SERVER_SUPPORT) */

char *sys_getenv(char *var);
extern int end;

#ifdef AR5D01
#define Adam2Prompt		"Adam2_AR5D01 >"
#else
#ifdef ACPEP
#define Adam2Prompt		"Adam2_ACPEP >"
#else
#ifdef WA100
#define Adam2Prompt		"Adam2_WA100 >"
#else
#ifdef AR5W01
#define Adam2Prompt		"Adam2_AR5W01 >"
#else
#ifdef AR7DB
#define Adam2Prompt		"Adam2_AR7DB >"
#else
#ifdef AR7RD
#define Adam2Prompt		"Adam2_AR7RD >"
#else
#ifdef AR7WRD
#define Adam2Prompt		"Adam2_AR7WRD >"
#else
#ifdef SEAD2
#define Adam2Prompt		"Adam2_SEAD2 >"
#else
#define Adam2Prompt		"Adam2_EVM3 >"
#endif /*SEAD2 */
#endif /* AR7WRD */
#endif /* AR7RD */
#endif /* AR7DB */
#endif /* AR5W01 */
#endif /* WA100 */
#endif /* ACPEP */
#endif /* AR5D01 */


//By Charles addition for Used Golbal Variable Check Code Pattern 05-04-2004
#if CHECK_GOLBAL == YES
	char cCheckPatternStr[5];
#endif	/* CHECK_GOLBAL Endif*/

void GetFrequencyAndInitSio(void)
{
  char sbuf[30];

  _PbusFrequency=0;
  _SbusFrequency=0;
#ifdef ACPEP
  _CpuFrequency = get_clk_setting(ACPEP_CPU_FREQ);
#else
#if defined(AR7DB) || defined(AR7RD) || defined(AR7WRD)
  _CpuFrequency = get_mips_freq();
#else
  _CpuFrequency = SetupCpuFrequency();
#endif /* AR7DB || AR7RD || AR7WRD */
#endif /* ACPEP */
  if (_SbusFrequency==0) _SbusFrequency=_CpuFrequency;
  if (_PbusFrequency==0) _PbusFrequency=_SbusFrequency/2;

  /* If cpufrequency doesn't exist or you are in bypass, set the frequency environment */

  if ((!sys_getenv("cpufrequency"))||(BOOTCR&BCR_BYPASS))
    {
    sys_sprintf(sbuf,"%d",_CpuFrequency);
    sys_setenv("cpufrequency",sbuf);
    }

  SioInit();
}

void c_entry(int memsize)
{
  char buf[16];
// commented by Oleg  char *sprompt;
  int ibaud;
  char sbuf[30];
  //cjg
// commented by Oleg  char mac_value[18];
#ifdef ACPEP
  FWBGet_flash_type();
#endif
  _MemSize=memsize;
  RESET_PRCR=0;
  FlushICache(); 
  FlushDCache(); 
  EnvInit();
  PrintfRestore();
  sys_sprintf(buf,"0x%08x",memsize);
  sys_setenv("memsize",buf);
  sys_sprintf(buf,"0x%08x",getflashsize(CS0_BASE,CS0_SIZE));
  sys_setenv("flashsize",buf);

  
  //Addition by Charles for Show Flash Vendor promet 05-05-2004
  //if (!sys_getenv("FlashVendor"))
/* by Oleg commented
  {
	sys_setenv("FlashVendor",FLASH_VENDOR_STRING);
  }
*/
  //Addition by Charles for Show code pattern promet 05-05-2004
  //if (!sys_getenv("CodePattern"))
/*  {
	sys_setenv("CodePattern",CODE_PATTERN_STRING);
  }
*/
  if (!SioGetBaud("modetty0",&ibaud)) sys_setenv("modetty0","38400,n,8,1,hw");
  if (!SioGetBaud("modetty1",&ibaud)) sys_setenv("modetty1","38400,n,8,1,hw");
  if (!sys_getenv("bootserport")) sys_setenv("bootserport","tty0");

#if defined (AR7DB) || defined (AR7RD)|| defined (AR7WRD)
  cfg_cpufreq(CONF_SYS_FREQ, CONF_CPU_FREQ, 0);
  platform_init();
#else
  GetFrequencyAndInitSio();
#endif
  
  sys_sprintf(sbuf,"%d.%d.%02d",MonitorMajorRev, MonitorMinorRev, TelogyMonitorRev);
  if (!sys_getenv("bootloaderVersion")) sys_setenv("bootloaderVersion",sbuf); // by Oleg added if
  
  if (!sys_getenv("ProductID")) sys_setenv("ProductID",ProductIDStr);
/* by Oleg  
  if (!sys_getenv("HWRevision"))
  {
	sys_setenv("HWRevision","Unknown");
  }
  
  if (!sys_getenv("SerialNumber"))
  {
	sys_setenv("SerialNumber","none");
  }
*/
  if (!sys_getenv("my_ipaddress"))
  {
	sys_setenv("my_ipaddress", DEFAULT_IP);
  }
  if(!sys_getenv("maca"))
  {
	  sys_setenv("maca", DEFAULT_MAC); // by Oleg changed default mac to something other
  }
/*
  if(!sys_getenv("eth0mac"))
  {
	  sys_setenv("eth0mac", DEFAULT_MAC);
  }
  //cjg
  strcpy(mac_value, sys_getenv("eth0mac"));
  //junzhao 2004.3.19
  mac_get(mac_value);
  sys_printf("mac_value:%s\n", mac_value);
  if(strcmp(mac_value, sys_getenv("eth0mac")))
  {
	  sys_setenv("eth0mac", mac_value);
  }
*/

#if FLASH_SIZE == 4	//By Charles add for main loop different prompt display flash block size 04-28-2004
	if (!sys_getenv("mtd0"))
		sys_setenv("mtd0", "0x900a0000,0x903f0000"); // by Oleg from 0x900e0000 to 0x900a0000
	#if  BOOT_SIZE == 64
		if (!sys_getenv("mtd1"))
			sys_setenv("mtd1", "0x90010000,0x900a0000"); // by Oleg from 0x900e0000 to 0x900a0000
		if (!sys_getenv("mtd2"))
			sys_setenv("mtd2", "0x90000000,0x90010000");
		if (!sys_getenv("mtd3"))
			sys_setenv("mtd3", "0x903f0000,0x90400000");
		if (!sys_getenv("mtd4"))
			sys_setenv("mtd4", "0x90010000,0x903f0000");
	#elif BOOT_SIZE == 128
		if (!sys_getenv("mtd1"))
			sys_setenv("mtd1", "0x90020000,0x900e0000");
		if (!sys_getenv("mtd2"))
			sys_setenv("mtd2", "0x90000000,0x90020000");
		if (!sys_getenv("mtd3"))
			sys_setenv("mtd3", "0x903f0000,0x90400000");
		if (!sys_getenv("mtd4"))
			sys_setenv("mtd4", "0x90020000,0x903f0000");
	#else
		if (!sys_getenv("mtd1"))
			sys_setenv("mtd1", "0x90010000,0x900e0000");
		if (!sys_getenv("mtd2"))
			sys_setenv("mtd2", "0x90000000,0x90010000");
		if (!sys_getenv("mtd3"))
			sys_setenv("mtd3", "0x903f0000,0x90400000");
		if (!sys_getenv("mtd4"))
			sys_setenv("mtd4", "0x90010000,0x903f0000");
	#endif	/* BOOT_SIZE Endif */
#elif FLASH_SIZE == 8
	if (!sys_getenv("mtd0"))
  		sys_setenv("mtd0", "0x900e0000,0x907f0000");
	#if	BOOT_SIZE == 64
		if (!sys_getenv("mtd1"))
 			sys_setenv("mtd1", "0x90010000,0x900e0000");
		if (!sys_getenv("mtd2"))
			sys_setenv("mtd2", "0x90000000,0x90010000");
		if (!sys_getenv("mtd3"))
  			sys_setenv("mtd3", "0x907e0000,0x90800000");
		//junzhao 2004.3.22
		if (!sys_getenv("mtd4"))
 			sys_setenv("mtd4", "0x90010000,0x907e0000");
	#elif BOOT_SIZE == 128
		if (!sys_getenv("mtd1"))
 			sys_setenv("mtd1", "0x90020000,0x900e0000");
		if (!sys_getenv("mtd2"))
			sys_setenv("mtd2", "0x90000000,0x90020000");
		if (!sys_getenv("mtd3"))
  			sys_setenv("mtd3", "0x907e0000,0x90800000");
		//junzhao 2004.3.22
		if (!sys_getenv("mtd4"))
 			sys_setenv("mtd4", "0x90020000,0x907e0000");
	#else
		if (!sys_getenv("mtd1"))
 			sys_setenv("mtd1", "0x90010000,0x900e0000");
		if (!sys_getenv("mtd2"))
			sys_setenv("mtd2", "0x90000000,0x90010000");
		if (!sys_getenv("mtd3"))
  			sys_setenv("mtd3", "0x907e0000,0x90800000");
		//junzhao 2004.3.22
		if (!sys_getenv("mtd4"))
 			sys_setenv("mtd4", "0x90010000,0x907e0000");
	#endif	/* BOOT_SIZE Endif */
#else
	if (!sys_getenv("mtd0"))
		sys_setenv("mtd0", "0x900e0000,0x903f0000");
	#if	BOOT_SIZE == 64
		if (!sys_getenv("mtd1"))
			sys_setenv("mtd1", "0x90010000,0x900e0000");
		if (!sys_getenv("mtd2"))
			sys_setenv("mtd2", "0x90000000,0x90010000");
		if (!sys_getenv("mtd3"))
			sys_setenv("mtd3", "0x903f0000,0x90400000");
		if (!sys_getenv("mtd4"))
			sys_setenv("mtd4", "0x90010000,0x903f0000");
	#elif BOOT_SIZE == 128
		if (!sys_getenv("mtd1"))
			sys_setenv("mtd1", "0x90020000,0x900e0000");
		if (!sys_getenv("mtd2"))
			sys_setenv("mtd2", "0x90000000,0x90020000");
		if (!sys_getenv("mtd3"))
			sys_setenv("mtd3", "0x903f0000,0x90400000");
		if (!sys_getenv("mtd4"))
			sys_setenv("mtd4", "0x90020000,0x903f0000");
	#else
		if (!sys_getenv("mtd1"))
			sys_setenv("mtd1", "0x90010000,0x900e0000");
		if (!sys_getenv("mtd2"))
			sys_setenv("mtd2", "0x90000000,0x90010000");
		if (!sys_getenv("mtd3"))
			sys_setenv("mtd3", "0x903f0000,0x90400000");
		if (!sys_getenv("mtd4"))
			sys_setenv("mtd4", "0x90010000,0x903f0000");
	#endif	/* BOOT_SIZE Endif */
#endif	/* FLASH_SIZE Endif*/

  if (!sys_getenv("autoload")) sys_setenv("autoload", "2");
/* by Oleg commented
  if (!sys_getenv("pair_selection"))
	sys_setenv("pair_selection", "0");
*/
  sys_printf("\nADAM2 Revision %s\n",sbuf);

#ifdef FFS_SUPPORT  
  _FileSystemInit();
#endif

/* commented by Oleg sprompt = sys_getenv("prompt");
  if (sprompt == NULL) 
  {
	sys_setenv("prompt", Adam2Prompt);
	sprompt = Adam2Prompt;
  }
*/
  sys_sprintf(buf,"0x%08x",(unsigned int)&end);
  sys_setenv("firstfreeaddress",buf);

  sys_sprintf(sbuf,"%d",_CpuFrequency); /* Always make sure 'cpufrequency' is correct */
  sys_setenv("cpufrequency",sbuf);

#ifndef ACPEP
  {
	int argc = 1;
  	char *argv[2];
	
/* default the frequency to 125MHz */
	sys_setenv("req_fullrate_freq", "125000000");


	argv[0] = "setmfreq";
	setmfreq(argc, argv);
	argv[0] = "memop";
	memop(argc, argv);
  }
#endif /* ACPEP */

  if (sys_getenv("autoload")) autoloadFlag = TRUE;

#if defined(FTP_SERVER_SUPPORT) || defined(DHCP_SUPPORT) || defined(TFTP_SERVER_SUPPORT)
#if defined(FTP_SERVER_SUPPORT) || defined(TFTP_SERVER_SUPPORT)
  if (sys_getenv("crash") != NULL)
  {
   sys_unsetenv("crash");
   crashFlag = CRASH_FS;
  }  
  leds_init();
#endif /* FTP_SERVER_SUPPORT || defined(TFTP_SERVER_SUPPORT) */

  init_env();
  ResetMMS();
 
#ifdef DIAG_SUPPORT
#error hello;
  demac();
#endif

// by Oleg add check is IP stack initialized  
  if (ip_init() == 1) sys_printf("Error: ip_init failed.\n");
#endif /* defined(FTP_SERVER_SUPPORT) || defined(DHCP_SUPPORT) || defined(TFTP_SERVER_SUPPORT) */
  
#ifdef DHCP_SUPPORT
  if (sys_getenv("dhcp")) if (ip_initialized == 1) dhcpclient();
#endif

#ifdef FTP_SERVER_SUPPORT
  ftpServerStatus = STATUS_NONE;
  if (ip_initialized == 1)
  {
	adam2Autodetect();
	FTPServer();	
  }
#endif
  
//wwzh add for tftp server 
#ifdef TFTP_SERVER_SUPPORT
	sys_printf("tftpserver initialized\n");
	if (ip_initialized == 1)
		tftpserver_init();
#endif

  FWBUnLock(CS0_BASE, CS0_SIZE);

  sys_printf(Adam2Prompt); // by Oleg sys_printf("\n%s > ",sprompt);

  while(TRUE)
    {
    if (ShellMain() != -1)
	sys_printf(Adam2Prompt); // by Oleg sys_printf("%s > ",sprompt);
    }
}

void ResetMMS(void)
{
  bit32u adr;
  bit32u memsize,newsize;
  char *cp;

#ifdef FFS_SUPPORT
  _FCBCloseWriteFiles();
#endif
  
  adr = CACHED(CS1_BASE+(1*1024*1024));

  adr+= 0x0f;
  adr&=~0x0f;
  memsize=(cp=sys_getenv("memsize"))?atoui(cp):(_MemSize);
  adr&=0x1fffffff;
  newsize=memsize-(adr-(CS1_BASE&0x1fffffff));
  adr=CACHED(adr);
  if (newsize<(memsize-(128*1024)))
  {
   minit(adr,newsize);
  }
}

int getmonitorinfo(int *rp,char **rd,char **rt)
  {

  *rp=(MonitorMajorRev<<8)|(MonitorMinorRev);
  *rd=__DATE__;
  *rt=__TIME__;
  return(0);
  }

void DispHex(int val)
  {
#if 0
  int i;
  char *led_ptr;
  int tmp;

  led_ptr=(char *)ASCII_DISP_BASE;   
  for(i=0;i<8;i++)
    {
    tmp=val>>28;
    tmp&=0xf;
    if (tmp>9)
      tmp+=7;
    tmp+=0x30;
    *led_ptr=tmp;
    led_ptr+=ASCII_DISP_OFFSET;
    val=val<<4;
    }
#endif
  }

void DispStr(char *val)
  {
#if 0
  int i;
  char *led_ptr;

  led_ptr=(char *)ASCII_DISP_BASE;   
  for(i=0;i<8;i++)
    {
    if (*val)
      {
      *led_ptr=*val++;
      }
     else
      *led_ptr=' ';
    led_ptr+=ASCII_DISP_OFFSET;
    }
#endif
  }

int _wrap_bcheck(unsigned int adr1, unsigned int adr2, unsigned int len)
  {
  unsigned int *ip1,*ip2;

  ip1=(unsigned int *)adr1;
  ip2=(unsigned int *)adr2;
  len>>=4;
  while(len)
    {
    if (*ip1++!=*ip2++) return(FALSE);
    len--;
    }
  return(TRUE);
  }

bit32u getflashsize(bit32u base, bit32u size)
  {
  bit32u blocksize,i,adr1,adr2;

  i=size/(1024*1024);
  blocksize=64*1024;
  do
    {
    adr1=base;
    adr2=base+((i*1024*1024)>>1);
    i>>=1;
  }while ((_wrap_bcheck(adr1,adr2,blocksize))&&(i));
  i<<=1;
  return(i*1024*1024);
  }

void SetRefClkDiv(int val,int verbose)
  {
#if !defined(AR7DB) && !defined(AR7RD) && !defined(AR7WRD)
  SioFlush();
  SetRefClkDivReg(val);
  GetFrequencyAndInitSio(); 
#endif
  }

void SetRefClkPll(int v)
  {
  SioFlush();
  SetRefClkPllReg(v, 0);
  GetFrequencyAndInitSio(); 
  }

int GetCpuFreq(void)
  {
  return(_CpuFrequency);
  }

int GetPbusFreq(void)
  {
  return(_PbusFrequency);
  }

int GetSbusFreq(void)
  {
  return(_SbusFrequency);
  }

#include "flashop.h"

typedef int (*procref1)(bit32u base);
typedef int (*procref2)(bit32u base,int size);
typedef int (*procref3)(bit32u base);
typedef int (*procref4)(bit32u adr, bit8 cVal);
typedef int (*procref5)(void);
typedef int (*procref6)(bit32u base,int size,int verbose);

typedef struct _Adam2Flash 
          {
          procref1 FWBGetBlockSize; /* called to get block size */
          procref6 FWBErase;        /* called to erase blocks */
          procref3 FWBOpen;         /* called to open block writes */
          procref4 FWBWriteByte;    /* called to write block byte */
          procref5 FWBClose;        /* called to close block writes */
          procref2 FWBUnLock;       /* called to unlock block writes */
          procref2 FWBLock;         /* called to lock block writes */
		  procref1 FWBValid;		/* called to check whether the address is within the limit.*/
          }Adam2Flash;

int GetFlashOps(Adam2Flash *ops)
  {
  if (ops)
    {
    ops->FWBGetBlockSize = FWBGetBlockSize;
    ops->FWBErase        = FWBErase;
    ops->FWBOpen         = FWBOpen;
    ops->FWBWriteByte    = FWBWriteByte;
    ops->FWBClose        = FWBClose;
    ops->FWBUnLock       = FWBUnLock;
    ops->FWBLock         = FWBLock;
	ops->FWBValid        = FWBValid;
    }
  return(sizeof(Adam2Flash));
  }
