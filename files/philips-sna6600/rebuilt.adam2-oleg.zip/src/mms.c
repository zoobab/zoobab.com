/*-----------------------------------------------------------------------------*/
/*                                                                             */
/*   Copyright (C) 1993-2003 by Texas Instruments, Inc.  All rights reserved.  */
/*   Copyright (C) 2001-2003 Telogy Networks, Inc.							   */
/*                                                                             */
/*     IMPORTANT - READ CAREFULLY BEFORE PROCEEDING TO USE SOFTWARE.           */
/*                                                                             */
/*  This document is displayed for you to read prior to using the software     */
/*  and documentation.  By using the software and documentation, or opening    */
/*  the sealed packet containing the software, or proceeding to download the   */
/*  software from a Bulletin Board System(BBS) or a WEB Server, you agree to   */
/*  abide by the following Texas Instruments License Agreement. If you choose  */
/*  not to agree with these provisions, promptly discontinue use of the        */
/*  software and documentation and return the material to the place you        */
/*  obtained it.                                                               */
/*                                                                             */
/*                               *** NOTE ***                                  */
/*                                                                             */
/*  The licensed materials contain MIPS Technologies, Inc. confidential        */
/*  information which is protected by the appropriate MIPS Technologies, Inc.  */
/*  license agreement.  It is your responsibility to comply with these         */
/*  licenses.                                                                  */
/*                                                                             */
/*                   Texas Instruments License Agreement                       */
/*                                                                             */
/*  1. License - Texas Instruments (hereinafter "TI"), grants you a license    */
/*  to use the software program and documentation in this package ("Licensed   */
/*  Materials") for Texas Instruments broadband products.                      */
/*                                                                             */
/*  2. Restrictions - You may not reverse-assemble or reverse-compile the      */
/*  Licensed Materials provided in object code or executable format.  You may  */
/*  not sublicense, transfer, assign, rent, or lease the Licensed Materials    */
/*  or this Agreement without written permission from TI.                      */
/*                                                                             */
/*  3. Copyright - The Licensed Materials are copyrighted. Accordingly, you    */
/*  may either make one copy of the Licensed Materials for backup and/or       */
/*  archival purposes or copy the Licensed Materials to another medium and     */
/*  keep the original Licensed Materials for backup and/or archival purposes.  */
/*                                                                             */
/*  4. Runtime and Applications Software - You may create modified or          */
/*  derivative programs of software identified as Runtime Libraries or         */
/*  Applications Software, which, in source code form, remain subject to this  */
/*  Agreement, but object code versions of such derivative programs are not    */
/*  subject to this Agreement.                                                 */
/*                                                                             */
/*  5. Warranty - TI warrants the media to be free from defects in material    */
/*  and workmanship and that the software will substantially conform to the    */
/*  related documentation for a period of ninety (90) days after the date of   */
/*  your purchase. TI does not warrant that the Licensed Materials will be     */
/*  free from error or will meet your specific requirements.                   */
/*                                                                             */
/*  6. Remedies - If you find defects in the media or that the software does   */
/*  not conform to the enclosed documentation, you may return the Licensed     */
/*  Materials along with the purchase receipt, postage prepaid, to the         */
/*  following address within the warranty period and receive a refund.         */
/*                                                                             */
/*  TEXAS INSTRUMENTS                                                          */
/*  Application Specific Products, MS 8650                                     */
/*  c/o ADAM2 Application Manager                                              */
/*  12500 TI Boulevard                                                         */
/*  Dallas, TX 75243  - U.S.A.                                                 */
/*                                                                             */
/*  7. Limitations - TI makes no warranty or condition, either expressed or    */
/*  implied, including, but not limited to, any implied warranties of          */
/*  merchantability and fitness for a particular purpose, regarding the        */
/*  licensed materials.                                                        */
/*                                                                             */
/*  Neither TI nor any applicable licensor will be liable for any indirect,    */
/*  incidental or consequential damages, including but not limited to loss of  */
/*  profits.                                                                   */
/*                                                                             */
/*  8. Term - The license is effective until terminated.   You may terminate   */
/*  it at any other time by destroying the program together with all copies,   */
/*  modifications and merged portions in any form. It also will terminate if   */
/*  you fail to comply with any term or condition of this Agreement.           */
/*                                                                             */
/*  9. Export Control - The re-export of United States origin software and     */
/*  documentation is subject to the U.S. Export Administration Regulations or  */
/*  your equivalent local regulations. Compliance with such regulations is     */
/*  your responsibility.                                                       */
/*                                                                             */
/*                         *** IMPORTANT NOTICE ***                            */
/*                                                                             */
/*  Texas Instruments (TI) reserves the right to make changes to or to         */
/*  discontinue any semiconductor product or service identified in this        */
/*  publication without notice. TI advises its customers to obtain the latest  */
/*  version of the relevant information to verify, before placing orders,      */
/*  that the information being relied upon is current.                         */
/*                                                                             */
/*  TI warrants performance of its semiconductor products and related          */
/*  software to current specifications in accordance with TI's standard        */
/*  warranty. Testing and other quality control techniques are utilized to     */
/*  the extent TI deems necessary to support this warranty. Unless mandated    */
/*  by government requirements, specific testing of all parameters of each     */
/*  device is not necessarily performed.                                       */
/*                                                                             */
/*  Please be aware that Texas Instruments products are not intended for use   */
/*  in life-support appliances, devices, or systems. Use of a TI product in    */
/*  such applications without the written approval of the appropriate TI       */
/*  officer is prohibited. Certain applications using semiconductor devices    */
/*  may involve potential risks of injury, property damage, or loss of life.   */
/*  In order to minimize these risks, adequate design and operating            */
/*  safeguards should be provided by the customer to minimize inherent or      */
/*  procedural hazards. Inclusion of TI products in such applications is       */
/*  understood to be fully at the risk of the customer using TI devices or     */
/*  systems.                                                                   */
/*                                                                             */
/*  TI assumes no liability for TI applications assistance, customer product   */
/*  design, software performance, or infringement of patents or services       */
/*  described herein. Nor does TI warrant or represent that license, either    */
/*  expressed or implied, is granted under any patent right, copyright, mask   */
/*  work right, or other intellectual property right of TI covering or         */
/*  relating to any combination, machine, or process in which such             */
/*  semiconductor products or services might be or are used.                   */
/*                                                                             */
/*  All company and/or product names are trademarks and/or registered          */
/*  trademarks of their respective manaufacturers.                             */
/*                                                                             */
/*-----------------------------------------------------------------------------*/
/*                                                                             */
/*  This module contains the functions which implement the dynamic memory      */
/*  management routines. The following assumptions/rules apply:                */
/*                                                                             */
/*   1) Packets are allocated a minimum of MIN_BLOCK + BLOCK_OVERHEAD bytes.   */
/*   2) The size of the heap is set at link time, using the -heap flag         */
/*      The allocation and sizing of the heap is a cooperative effort          */
/*      involving the linker, this file, and "sysmem.c".                       */
/*   3) The heap can be reset at any time by calling the function "minit"      */
/*                                                                             */
/*  The following items are defined in this module :                           */
/*    minit(.)    : Function to initialize dynamic memory management           */
/*    malloc(.)   : Function to allocate memory from mem mgmt system.          */
/*    sys_calloc(.)   : Allocate an clear memory from mem mgmt system.         */
/*    sys_realloc(.)  : Reallocate a packet                                    */
/*    sys_free(.)     : Function to free allocated memory.                     */
/*    sys_memalign(.):Function to allocate aligned memory from mem mgmt system.*/
/*-----------------------------------------------------------------------------*/
/*    minsert(.)  : Insert a packet into free list, sorted by size             */
/*    mremove(.)  : Remove a packet from the free list.                        */
/*    sys_free   : Pointer to free list                                        */
/*                                                                             */
/*******************************************************************************/

#include "_stdio.h"
#include "mms.h"

#ifdef FFS_SUPPORT
#include "files.h"
#endif

#define MALLOC_DEBUG

/*---------------------------------------------------------------------------*/
/* MIN_BLOCK MUST BE A                                                       */
/*---------------------------------------------------------------------------*/
#define MIN_BLOCK       16
#define BLOCK_OVERHEAD  MIN_BLOCK
#define BLOCK_USED      1
#define BLOCK_MASK      (MIN_BLOCK-1)

/*---------------------------------------------------------------------------*/
/* "PACKET" is the template for a data packet.  Packet size contains         */
/* the number of bytes allocated for the user, excluding the size required   */
/* for management of the packet (BLOCK_OVERHEAD bytes).  Packets are always  */
/* allocated memory in MIN_BLOCK byte chunks. The lowest order bit of the    */
/* size field is used to indicate whether the packet is free(0) or used(1).  */
/* The next_ptr field is used to manage the free list, and is a pointer      */
/* to the next element in the free list.  The free list is sorted by size.   */
/*---------------------------------------------------------------------------*/
typedef struct pack
  {
  unsigned int mflag;
  unsigned int packet_size;     /* number of bytes        */
  struct pack  *next_ptr;       /* next elem in free list */
  struct pack  *this_ptr;
  }PACKET;

/*---------------------------------------------------------------------------*/
/* Size of the heap area as defined by the linker. Initialized in sysmem.c   */
/*---------------------------------------------------------------------------*/

int _memory_size = 0;

/*---------------------------------------------------------------------------*/
/* SYS_FREE - This variable is a pointer to the free list.                   */
/*---------------------------------------------------------------------------*/
volatile char* _sys_memory = 0;
PACKET *free = 0;

/*---------------------------------------------------------------------------*/
/* Function declarations                                                     */
/*---------------------------------------------------------------------------*/
static void minsert(PACKET *);         /* insert a packet into the free list */
static void mremove(PACKET *);         /* delete packet from the free list   */
extern void minit(unsigned adr, unsigned size);

/*****************************************************************************/
/*                                                                           */
/*  MINSERT - Insert a packet into the free list.  This list is sorted by    */
/*            size in increasing order.                                      */
/*                                                                           */
/*****************************************************************************/
static void minsert(PACKET *ptr)
  {
  register PACKET *current = (PACKET *) free;
  register PACKET *last    = NULL;

  /*-----------------------------------------------------------------------*/
  /* Setup MMS markers                                                     */
  /*-----------------------------------------------------------------------*/
  ptr->mflag = 0x11111111;
  ptr->this_ptr = ptr;

  /*-----------------------------------------------------------------------*/
  /* CHECK SPECIAL CASE, EMPTY FREE LIST.                                  */
  /*-----------------------------------------------------------------------*/
  if (current == NULL)
    {
    free      = ptr;
    ptr->next_ptr = NULL;
    return;
    }

  /*-----------------------------------------------------------------------*/
  /* SCAN THROUGH LIST, LOOKING FOR A LARGER PACKET.                       */
  /*-----------------------------------------------------------------------*/
  while (current && current->packet_size < ptr->packet_size)
    {
    last    = current;
    current = current->next_ptr;
    }

  /*-----------------------------------------------------------------------*/
  /* LINK THE NEW PACKET INTO THE LIST. THERE ARE THREE CASES :            */
  /*   THE NEW POINTER WILL EITHER BE THE FIRST, THE LAST, OR IN THE       */
  /*   MIDDLE SOMEWHERE.                                                   */
  /*-----------------------------------------------------------------------*/
  if (current == NULL)               /* PTR WILL BE LAST IN LIST           */
    {
    last->next_ptr = ptr;
    ptr->next_ptr  = NULL;
    }
   else 
    {
    if (last == NULL)                /* PTR WILL BE FIRST IN THE LIST     */
      {
      ptr->next_ptr  = free;
      free       = ptr;
      }
     else                            /* PTR IS IN THE MIDDLE OF THE LIST  */
      {
      ptr->next_ptr  = current;
      last->next_ptr = ptr;
      }
    }
  }

/*****************************************************************************/
/*                                                                           */
/* MREMOVE - REMOVE AN ITEM FROM THE FREE LIST.                              */
/*                                                                           */
/*****************************************************************************/
static void mremove(PACKET *ptr)
  {
  register PACKET *current = free;
  register PACKET *last    = NULL;

  /*-----------------------------------------------------------------------*/
  /* SCAN THROUGH LIST, LOOKING FOR PACKET TO REMOVE                       */
  /*-----------------------------------------------------------------------*/
  while (current && current != ptr)
    {
    last    = current;
    current = current->next_ptr;
    }

  /*-----------------------------------------------------------------------*/
  /* REMOVE THE PACKET FROM THE LIST.   THERE ARE TWO CASES :              */
  /*   THE OLD POINTER WILL EITHER BE THE FIRST, OR NOT THE FIRST.         */
  /*-----------------------------------------------------------------------*/
  if (current == NULL) 
    free = NULL;                                        /* NOT FOUND   */
   else 
    {
    if (last == NULL) 
      free       = ptr->next_ptr;                      /* 1ST IN LIST */
     else                      
      last->next_ptr = ptr->next_ptr;                      /* MID OF LIST */
    }
  }

void sys_memcpy(void *new, void *packet, int oldsize)
  {
  char *dp=new;
  char *sp=packet;
  while(oldsize--)
    *dp++=*sp++;
  }

/*****************************************************************************/
/*                                                                           */
/*  MINIT - This function can be called by the user to completely reset the  */
/*          memory management system.                                        */
/*                                                                           */
/*****************************************************************************/
void minit(unsigned adr, unsigned size)
  {

  _memory_size=size;
  _sys_memory=(char *)adr;

    /*-----------------------------------------------------------------------*/
    /* TO INITIALIZE THE MEMORY SYSTEM, SET UP THE FREE LIST TO POINT TO     */
    /* THE ENTIRE HEAP, AND INITIALIZE HEAP TO A SINGLE EMPTY PACKET.        */
    /*-----------------------------------------------------------------------*/
  free = (PACKET *)_sys_memory;
  free->packet_size   = _memory_size - BLOCK_OVERHEAD;
  free->next_ptr      = NULL;
  free->mflag         = 0x11111111;
  free->this_ptr      = free;
  }

void *mallocc(unsigned size)
  {
  unsigned char *current = sys_malloc(size);
  unsigned char *save;
  unsigned i;

  if (current == 0) 
    return(0);
  save=current;
  for(i=0;i<size;i++) *current++=0;
  return(save);
  }


/*****************************************************************************/
/*                                                                           */
/*  MALLOC - Allocate a packet of a given size, and return a pointer to it.  */
/*           This function only allocates in multiples of MIN_BLOCK bytes.   */
/*                                                                           */
/*****************************************************************************/
void* sys_malloc(unsigned size)
  {
  register PACKET       *current = free;
  register unsigned int  newsize = (size + BLOCK_MASK) & ~BLOCK_MASK;
  register unsigned int  oldsize = 0;

  if (size <= 0) 
    return(0);
  /*-----------------------------------------------------------------------*/
  /* SCAN THROUGH FREE LIST FOR PACKET LARGE ENOUGH TO CONTAIN PACKET      */
  /*-----------------------------------------------------------------------*/
  while (current && current->packet_size < newsize)
    {
    current = current->next_ptr;
    }

  if (!current) return(0);

  oldsize = current->packet_size;         /* REMEMBER OLD SIZE             */
  mremove(current);                       /* REMOVE PACKET FROM FREE LIST  */
  /*-----------------------------------------------------------------------*/
  /* IF PACKET IS LARGER THAN NEEDED, FREE EXTRA SPACE AT END              */
  /* BY INSERTING REMAINING SPACE INTO FREE LIST.                          */
  /*-----------------------------------------------------------------------*/
  if ((oldsize - newsize) >= (MIN_BLOCK + BLOCK_OVERHEAD))
    {
    register PACKET *next =
               (PACKET *) ((char *) current + BLOCK_OVERHEAD + newsize);

    next->packet_size    = oldsize - newsize - BLOCK_OVERHEAD;
    minsert(next);
    current->packet_size = newsize;
    }
  current->packet_size |= BLOCK_USED;
  current->mflag        = 0x11111111;
  current->this_ptr     = current;
  return(((char *)current) + BLOCK_OVERHEAD);
  }

/*****************************************************************************/
/*                                                                           */
/*  CALLOC - Allocate a packet of a given size, set the data in the packet   */
/*           to nulls, and return a pointer to it.                           */
/*                                                                           */
/*****************************************************************************/
void* sys_calloc(unsigned num, unsigned size)
  {
  register unsigned      i     = size * num;
  register bit32u *current = sys_malloc(i);
  register char       *save    = (char *) current;

  if (current == 0) 
    return(0);

  i = ((i + BLOCK_MASK) & ~BLOCK_MASK) / sizeof(bit32u);

  while (i--) *current++ = 0;
  return(save);
  }

/*****************************************************************************/
/*                                                                           */
/*  REALLOC - Reallocate a packet to a new size.                             */
/*                                                                           */
/*****************************************************************************/
void* sys_realloc(void *packet, unsigned size)
  {
  register char *pptr    = (char *) packet - BLOCK_OVERHEAD;
  register int   newsize = (size + BLOCK_MASK) & ~BLOCK_MASK;
  register int   oldsize;

  if (packet == 0)
    return(sys_malloc(size));
  if (size   == 0)
    { 
    sys_free(packet); 
    return(0); 
    }

  oldsize = ((PACKET *)pptr)->packet_size;

  if (!(oldsize & BLOCK_USED))  return 0;
  if (newsize == --oldsize)     return packet;

  /*-----------------------------------------------------------------------*/
  /* IF NEW SIZE IS LESS THAN CURRENT SIZE, TRUNCATE PACKET AND RETURN END */
  /* TO FREE LIST                                                          */
  /*-----------------------------------------------------------------------*/
  if (newsize < oldsize)
    {
    if ((oldsize - newsize) < (MIN_BLOCK + BLOCK_OVERHEAD))
      return(packet);
    ((PACKET *)pptr)->packet_size = newsize | BLOCK_USED;
    ((PACKET *)pptr)->this_ptr = (PACKET *)pptr;
    ((PACKET *)pptr)->mflag    = 0x11111111;

    oldsize -= newsize + BLOCK_OVERHEAD;
    pptr    += newsize + BLOCK_OVERHEAD;
    ((PACKET *)pptr)->packet_size = oldsize | BLOCK_USED;
    ((PACKET *)pptr)->this_ptr = (PACKET *)pptr;
    ((PACKET *)pptr)->mflag    = 0x11111111;
    sys_free(pptr + BLOCK_OVERHEAD);
    return(packet);
    }

    /*-----------------------------------------------------------------------*/
    /* IF NEW SIZE IS BIGGER THAN CURRENT PACKET,                            */
    /*  1) CHECK NEXT PACKET IN LIST, SEE IF PACKET CAN BE EXPANDED          */
    /*  2) IF NOT, MOVE PACKET TO NEW LOCATION.                              */
    /*-----------------------------------------------------------------------*/
   else
    {
    PACKET *next = (PACKET *)(pptr + oldsize + BLOCK_OVERHEAD);
    int     temp;

    if (((char *)next < &_sys_memory[_memory_size - BLOCK_OVERHEAD]) &&
        (!(next->packet_size & BLOCK_USED))                           &&
        ((temp = oldsize + next->packet_size +BLOCK_OVERHEAD -newsize) >= 0))
      {
      mremove(next);
      ((PACKET *)pptr)->mflag    = 0x11111111;
      ((PACKET *)pptr)->this_ptr = (PACKET *)pptr;
      if (temp < MIN_BLOCK + BLOCK_OVERHEAD)
        {
        ((PACKET *)pptr)->packet_size = (newsize + temp) | BLOCK_USED;
        return(packet);
        }

      ((PACKET *)pptr)->packet_size = newsize | BLOCK_USED;
      pptr += newsize + BLOCK_OVERHEAD;
      ((PACKET *)pptr)->packet_size = temp - BLOCK_OVERHEAD;
      minsert((PACKET *)pptr);
      return(packet);
      }
     else
      {
      /*---------------------------------------------------------------*/
      /* ALLOCATE NEW PACKET AND MOVE DATA INTO IT.                    */
      /*---------------------------------------------------------------*/
      register char *new = sys_malloc(size);
      if (new == 0) return 0;
      sys_memcpy(new, packet, oldsize);
      sys_free(packet);
      return(new);
      }
    }
  }

/*****************************************************************************/
/*                                                                           */
/*  FREE - Return a packet allocated by malloc to free memory pool.          */
/*         Return 0 if successful, -1 if not successful.                     */
/*                                                                           */
/*****************************************************************************/
void sys_free(void *packet)
  {
  register char   *ptr = (char *)packet;
  register PACKET *last;            /* POINT TO PREVIOUS PACKET            */
  register PACKET *current;         /* POINTER TO THIS PACKET              */
  register PACKET *next;            /* POINTER TO NEXT PACKET              */

  if (ptr == NULL) return;

  last = next = NULL;               /* INITIALIZE POINTERS                 */
  ptr -= BLOCK_OVERHEAD;            /* ADJUST POINT TO BEGINNING OF PACKET */

  current = (PACKET *)_sys_memory;

  /*-----------------------------------------------------------------------*/
  /* SEARCH FOR THE POINTER IN THE PACKET POINTED TO                       */
  /*-----------------------------------------------------------------------*/
  while (current < (PACKET *) ptr)
    {
    last    = current;
    current = (PACKET *)((char *)current +
              (current->packet_size & ~BLOCK_USED) + BLOCK_OVERHEAD);
    }

  /*-----------------------------------------------------------------------*/
  /* CHECK FOR POINTER OR PACKET ERRORS.                                   */
  /*-----------------------------------------------------------------------*/
  if ((current != (PACKET *) ptr) || (!(current->packet_size & BLOCK_USED)))
    return;

  current->packet_size &= ~BLOCK_USED;   /* MARK PACKET AS FREE */


  /*-----------------------------------------------------------------------*/
  /* GET POINTER TO NEXT PACKET IN MEMORY, IF ANY.                         */
  /*-----------------------------------------------------------------------*/
  next = (PACKET *) ((char *)current + BLOCK_OVERHEAD + current->packet_size);
  if (next > (PACKET *) &_sys_memory[_memory_size-BLOCK_OVERHEAD])
    next = NULL;

  if (last && (last->packet_size & BLOCK_USED)) last = NULL;
  if (next && (next->packet_size & BLOCK_USED)) next = NULL;

  /*-----------------------------------------------------------------------*/
  /* ATTEMPT TO COLLESCE THE THREE PACKETS (PREVIOUS, CURRENT, NEXT)       */
  /*-----------------------------------------------------------------------*/
  if (last && next)
    {
    mremove(last);
    mremove(next);
    last->packet_size += current->packet_size + next->packet_size +
                             BLOCK_OVERHEAD + BLOCK_OVERHEAD;
    minsert(last);
    return;
    }

  /*-----------------------------------------------------------------------*/
  /* ATTEMPT TO COLLESCE THE CURRENT WITH LAST PACKET. (LAST, CURRENT)     */
  /*-----------------------------------------------------------------------*/
  if (last)
    {
    mremove(last);
    last->packet_size += current->packet_size + BLOCK_OVERHEAD;
    minsert(last);
    return;
    }

  /*-----------------------------------------------------------------------*/
  /* ATTEMPT TO COLLESCE THE CURRENT WITH NEXT PACKET. (CURRENT, NEXT)     */
  /*-----------------------------------------------------------------------*/
  if (next)
    {
    mremove(next);
    current->packet_size += next->packet_size + BLOCK_OVERHEAD;
    minsert(current);
    return;
    }

  /*-----------------------------------------------------------------------*/
  /* NO COLLESCENCE POSSIBLE, JUST INSERT THIS PACKET INTO LIST            */
  /*-----------------------------------------------------------------------*/
  minsert(current);
  }

/*****************************************************************************/
/*                                                                           */
/*  MEMALIGN - Allocate a packet of a given size, and on a given boundary.   */
/*                                                                           */
/*****************************************************************************/
void* sys_memalign(unsigned alignment, unsigned size)
  {
  PACKET *aln_packet;
  PACKET *current  = free;
  unsigned  newsize  = (size + BLOCK_MASK) & ~BLOCK_MASK;
  unsigned  aln_mask = alignment - 1;
  int     leftover = -1;
  char   *aln_start;
  char   *un_aln_start;

  if (size <= 0) return 0;

  /*--------------------------------------------------------------------*/
  /* IF ALIGNMENT IS NOT A POWER OF TWO OR IS LESS THAN THE DEFAULT     */
  /* ALIGNMENT OF MALLOC, THEN SIMPLY RETURN WHAT MALLOC RETURNS.       */
  /*--------------------------------------------------------------------*/
  if (alignment <= BLOCK_OVERHEAD || (alignment & (alignment-1)))
    return sys_malloc(size);

  /*-----------------------------------------------------------------------*/
  /* SCAN THROUGH FREE LIST FOR PACKET LARGE ENOUGH TO CONTAIN ALIGNED     */
  /* PACKET                                                                */
  /*-----------------------------------------------------------------------*/
  for ( ; current ; current = current->next_ptr)
    {
    un_aln_start = (char *) current + BLOCK_OVERHEAD;
    aln_start    = (char *) (((unsigned) un_aln_start + aln_mask) & ~aln_mask);
    leftover     = un_aln_start + current->packet_size - aln_start - newsize;

    /*--------------------------------------------------------------------*/
    /* MAKE SURE THAT THE PRE BLOCK SPACE IS LARGE ENOUGH TO BE A BLOCK   */
    /* OF ITS OWN.                                                        */
    /*--------------------------------------------------------------------*/
    for ( ; (char *)current+sizeof(PACKET) > aln_start-BLOCK_OVERHEAD ;
          aln_start += alignment, leftover -= alignment);

    if (leftover >= 0) 
      break;
    }

  if (!current) 
    return(0);

  /*-----------------------------------------------------------------------*/
  /* SETUP NEW PACKET FOR ALIGNED MEMORY.                                  */
  /*-----------------------------------------------------------------------*/
  mremove(current);
  aln_packet              = (PACKET *) (aln_start - BLOCK_OVERHEAD);
  aln_packet->packet_size = newsize | BLOCK_USED;
  aln_packet->mflag       = 0x11111111;
  aln_packet->this_ptr    = aln_packet;

  /*-----------------------------------------------------------------------*/
  /* HANDLE THE FREE SPACE BEFORE THE ALIGNED BLOCK.  IF THE ORIGINAL      */
  /* BLOCK WAS ALIGNED, THERE WON'T BE FREE SPACE BEFORE THE ALIGNED BLOCK.*/
  /*-----------------------------------------------------------------------*/
  if (aln_start != un_aln_start)
    {
    current->packet_size = (char *)aln_packet - un_aln_start;
    minsert(current);
    }

  /*-----------------------------------------------------------------------*/
  /* HANDLE THE FREE SPACE AFTER THE ALIGNED BLOCK. IF IT IS LARGE ENOUGH  */
  /* TO BE A BLOCK OF ITS OWN, THEN MAKE IT ONE, OTHERWISE ADD THE         */
  /* LEFTOVER SIZE TO THE ALIGNED BLOCK.                                   */
  /*-----------------------------------------------------------------------*/
  if (leftover >= BLOCK_OVERHEAD + MIN_BLOCK)
    {
    register PACKET *next = (PACKET *) (aln_start + newsize);
    next->packet_size     = leftover - BLOCK_OVERHEAD;
    minsert(next);
    }
   else 
    aln_packet->packet_size += leftover;

  return(aln_start);
  }

void sys_memset(void *new, UINT8 data, int oldsize)
{
  	char *dp=new;
  	while(oldsize--)
    	*dp++=data;
}

#ifdef MALLOC_DEBUG
/*****************************************************************************/
/*                                                                           */
/*  MEMMAP -  Print dynamic memory allocation statistics                     */
/*                                                                           */
/*****************************************************************************/
void sys_memmap(int lvl)
  {
#if 0		  
  PACKET *current = (PACKET *)_sys_memory;

  int free_block_num          = 0;
  int free_block_space        = 0;
  int free_block_max          = 0;
  int used_block_num          = 0;
  int used_block_space        = 0;
  int used_block_max          = 0;

  /*-----------------------------------------------------------------------*/
  /* LOOP THROUGH ALL PACKETS                                              */
  /*-----------------------------------------------------------------------*/
  while (current < ((PACKET *) &_sys_memory[_memory_size-BLOCK_OVERHEAD]))
    {
    int size = current->packet_size & ~BLOCK_USED;
    int used = current->packet_size & BLOCK_USED;

    if (lvl) 
      sys_printf(">> Used:%1d size:%6d addr:%08x\n", used, size, (unsigned int)current);

    if (used)
      {
      used_block_num++;
      used_block_space += size;
      used_block_max   = MAX(used_block_max, size);
      }
     else
      {
      free_block_num++;
      free_block_space += size;
      free_block_max   = MAX(free_block_max, size);
      }

    current = (PACKET *)((char *)current + size + BLOCK_OVERHEAD);
    }

  sys_printf("free_num:%9d free_space:%9d free_max:%9d\nused_num:%9d used_space:%9d used_max:%9d\n",
         free_block_num, free_block_space, free_block_max,
         used_block_num, used_block_space, used_block_max);
  sys_printf("Free ptr Addr: %8x overhead:%8d\n", (unsigned int) free,
         (free_block_num + used_block_num) * BLOCK_OVERHEAD);
#endif
  }
#endif

