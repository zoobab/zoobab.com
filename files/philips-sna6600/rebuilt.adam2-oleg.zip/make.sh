#!/bin/sh
export PATH=/opt/mcmcc-mipsel/bin:/opt/hardhat/previewkit/mips/fp_le/lib/gcc-lib/mipsel-hardhat-linux/2.95.3:$PATH
cd bin
make clean
make all
cd ..
cd src
make clean
make all
cd ..
cd bin
make clean
cd ..
cd src
make clean
cd ..
