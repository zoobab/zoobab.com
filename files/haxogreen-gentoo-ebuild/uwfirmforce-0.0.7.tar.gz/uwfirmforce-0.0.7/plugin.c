/* $Id: plugin.c,v 1.1.1.1 2007/12/22 17:48:57 khorben Exp $ */
/* Copyright (c) 2007 khorben of Uberwall */
/* This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation version 2 of the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA */



#include <stdarg.h>
#include <stdlib.h>
#include <string.h>
#include <dlfcn.h>
#include "plugins/plugin.h"
#include "UWfirmforce.h"


/* macros */
#define max(a, b) ((a) > (b) ? (a) : (b))


/* Plugin */
/* types */
typedef enum _PluginFlag
{
	PF_VERBOSE = 0x01
} PluginFlag;

struct _PluginHelperData
{
	PluginFlag flags;
	char const * filename;
};

struct _PluginHandle
{
	Plugin * plugin;
	void * handle;
};


PluginHandle * plugin_new(char const * filename)
{
	PluginHandle * plugin;

	if((plugin = malloc(sizeof(*plugin))) == NULL)
	{
		UWfirmforce_error(filename, 0);
		return NULL;
	}
	if((plugin->handle = dlopen(filename, RTLD_LAZY)) == NULL)
	{
		UWfirmforce_dlerror(filename, 0);
		plugin_delete(plugin);
		return NULL;
	}
	if((plugin->plugin = dlsym(plugin->handle, "plugin")) == NULL
			|| plugin->plugin->name == NULL)
	{
		UWfirmforce_dlerror(filename, 0);
		plugin_delete(plugin);
		return NULL;
	}
	return plugin;
}


/* plugin_delete */
void plugin_delete(PluginHandle * plugin)
{
	if(plugin->handle != NULL && dlclose(plugin->handle) != 0)
		UWfirmforce_dlerror("plugin_delete", 0);
	free(plugin);
}


/* accessors */
/* plugin_get_name */
char const * plugin_get_name(PluginHandle * plugin)
{
	return plugin->plugin->name;
}


/* plugin_get_buffer_size */
size_t plugin_get_buffer_size(PluginHandle * plugin)
{
	unsigned int i;
	size_t len = 0;

	if(plugin->plugin->magic == NULL)
		return 0;
	for(i = 0; plugin->plugin->magic[i].magic != NULL; i++)
	{
		len = max(len, plugin->plugin->magic[i].overhead);
		len = max(len, plugin->plugin->magic[i].offset
				+ plugin->plugin->magic[i].magic_len);
	}
	return len;
}


/* useful */
/* plugin_do */
static int _do_printf(PluginHelper * ph, char const * format, ...);

int plugin_do(PluginHandle * plugin, int signature, int verbose,
		char const * filename, FILE * fp)
{
	static PluginHelperData data;
	PluginHelper ph;

	if(plugin->plugin->callback == NULL)
		return 0;
	data.flags = verbose ? PF_VERBOSE : 0;
	data.filename = filename;
	ph.data = &data;
	ph.printf = _do_printf;
	return plugin->plugin->callback(&ph, signature, fp);
}

static int _do_printf(PluginHelper * ph, char const * format, ...)
{
	int ret;
	va_list arg;

	if(!(ph->data->flags & PF_VERBOSE))
		return 0;
	va_start(arg, format);
	ret = vprintf(format, arg);
	va_end(arg);
	return ret;
}


/* plugin_info */
void plugin_info(PluginHandle * plugin)
{
	struct
	{
		PluginType type;
		char const * description;
	} td[] =
	{
		{ PT_COMPRESSION,	"compressed"	},
		{ PT_EXECUTABLE,	"executable"	},
		{ PT_ARCHIVE,		"archive"	},
		{ PT_FORENSIC,		"forensic"	},
		{ 0,			NULL		}
	};
	unsigned int i;

	printf("%s:", plugin->plugin->name);
	for(i = 0; td[i].description != NULL; i++)
		if((td[i].type & plugin->plugin->type) == td[i].type)
			printf(" %s", td[i].description);
	fputc('\n', stdout);
}


/* plugin_match
 * RETURNS:	>= 0	matched signature id returned
 * 		else	nothing was found or an error occured */
int plugin_match(PluginHandle * plugin, char const * buf, size_t buf_cnt)
{
	unsigned int i;
	PluginMagic * magic;

	for(i = 0; (magic = &plugin->plugin->magic[i]) != NULL
			&& magic->magic != NULL; i++)
	{
		if(buf_cnt < magic->offset + magic->magic_len
				|| memcmp(&buf[magic->offset], magic->magic,
					magic->magic_len) != 0)
			continue;
		return i;
	}
	return -1;
}
