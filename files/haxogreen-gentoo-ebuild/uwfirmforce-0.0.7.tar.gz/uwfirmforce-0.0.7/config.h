#define PACKAGE "UWfirmforce"
#define VERSION "0.0.7"

#ifndef PREFIX
# define PREFIX "/usr/local"
#endif
