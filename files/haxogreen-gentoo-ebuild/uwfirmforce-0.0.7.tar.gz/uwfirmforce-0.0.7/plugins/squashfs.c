/* $Id: squashfs.c,v 1.1.1.1 2007/12/22 17:48:57 khorben Exp $ */
/* Copyright (c) 2007 Matthias Wenzel, matthias /at/ mazzoo /dot/ de,
 * Copyright (c) 2007 khorben of UberWall */
/* This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation version 2 of the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA */



#include "plugin.h"


/* squashfs */
/* public */
/* variables */
/* magic */
static unsigned char sig1[] = "hsqs";
static unsigned char sig2[] = "sqsh";

static PluginMagic squashfs_magic[] =
{
	{ 4, 0, sig1,	sizeof(sig1)-1	},
	{ 4, 0, sig2,	sizeof(sig2)-1	},
	{ 0, 0, NULL,	0		}
};


/* plugin */
Plugin plugin =
{
	PT_ARCHIVE | PT_COMPRESSION,
	"SQUASHFS",
	squashfs_magic,
	NULL
};
