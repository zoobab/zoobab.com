/* $Id: ar.c,v 1.1.1.1 2007/12/22 17:48:57 khorben Exp $ */
/* Copyright (c) 2007 khorben of Uberwall */
/* This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation version 2 of the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA */



#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "plugin.h"


/* ar */
/* public */
/* types */
#pragma pack(1)
#include <ar.h>
#pragma pack()


/* variables */
/* magic */
static unsigned char sig[] = ARMAG;

static PluginMagic ar_magic[] =
{
	{ sizeof(struct ar_hdr),	0,	sig,	sizeof(sig)-1	},
	{ 0,				0,	NULL,	0		}
};


/* functions */
static int ar_callback(PluginHelper * ph, int signature, FILE * fp);


/* plugin */
Plugin plugin =
{
	PT_ARCHIVE,
	"AR",
	ar_magic,
	ar_callback
};


/* private */
/* functions */
/* ar_callback */
static int _callback_name(PluginHelper * ph, char const * buf);
static int _callback_uid(PluginHelper * ph, char const * buf);
static int _callback_gid(PluginHelper * ph, char const * buf);
static int _callback_size(PluginHelper * ph, char const * buf);

static int ar_callback(PluginHelper * ph, int signature, FILE * fp)
{
	struct ar_hdr ar;
	char buf[17];
	char * p;
	int score = 0;

	if(fseek(fp, sizeof(sig)-1, SEEK_CUR) != 0 || fread(&ar, sizeof(ar), 1,
				fp) != 1)
		return 0;
	strncpy(buf, ar.ar_name, sizeof(ar.ar_name));
	buf[sizeof(ar.ar_name)] = '\0';
	if((p = strchr(buf, ' ')) != NULL)
		*p = '\0';
	score+=_callback_name(ph, buf) / 4;
	strncpy(buf, ar.ar_uid, sizeof(ar.ar_uid));
	buf[sizeof(ar.ar_uid)] = '\0';
	if((p = strchr(buf, ' ')) != NULL)
		*p = '\0';
	score+=_callback_uid(ph, buf) / 4;
	strncpy(buf, ar.ar_gid, sizeof(ar.ar_gid));
	buf[sizeof(ar.ar_gid)] = '\0';
	if((p = strchr(buf, ' ')) != NULL)
		*p = '\0';
	score+=_callback_gid(ph, buf) / 4;
	strncpy(buf, ar.ar_size, sizeof(ar.ar_size));
	buf[sizeof(ar.ar_size)] = '\0';
	if((p = strchr(buf, ' ')) != NULL)
		*p = '\0';
	score+=_callback_size(ph, buf) / 4;
	ph->printf(ph, "\n");
	return score;
}

int _callback_name(PluginHelper * ph, char const * buf)
{
	if(*buf == '\0')
	{
		ph->printf(ph, "%s", "filename empty");
		return 0;
	}
	ph->printf(ph, "%s%s%c", " filename \"", buf, '"');
	return 100;
}

int _callback_uid(PluginHelper * ph, char const * buf)
{
	uid_t uid;
	char * p;

	uid = strtol(buf, &p, 10);
	if(*buf == '\0' || *p != '\0')
	{
		ph->printf(ph, "%s", ", uid invalid");
		return 0;
	}
	ph->printf(ph, "%s%u", ", uid ", uid);
	return 100;
}

int _callback_gid(PluginHelper * ph, char const * buf)
{
	gid_t gid;
	char * p;

	gid = strtol(buf, &p, 10);
	if(*buf == '\0' || *p != '\0')
	{
		ph->printf(ph, "%s", ", gid invalid");
		return 0;
	}
	ph->printf(ph, "%s%u", ", gid ", gid);
	return 100;
}

int _callback_size(PluginHelper * ph, char const * buf)
{
	long size;
	char * p;

	size = strtol(buf, &p, 10);
	if(*buf == '\0' || *p != '\0')
	{
		ph->printf(ph, "%s", ", size invalid");
		return 0;
	}
	ph->printf(ph, "%s%ld", ", size ", size);
	return 100;
}
