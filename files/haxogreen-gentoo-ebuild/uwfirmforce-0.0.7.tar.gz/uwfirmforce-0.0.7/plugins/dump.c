/* $Id: dump.c,v 1.3 2008/01/10 20:11:44 khorben Exp $ */
/* Copyright (c) 2007 khorben of Uberwall */



#include <stdint.h>
#include "plugin.h"


/* dump */
/* public */
/* constants */
#define TP_BSIZE	1024
#define NTREC		10
#define HIGHDENSITYTREC	32
#define TP_NINDIR	(TP_BSIZE/2)
#define LBLSIZE		16
#define NAMELEN		64

#define OFS_MAGIC	(int)60011
#define NFS_MAGIC	(int)60012
#ifndef FS_UFS2_MAGIC
#define FS_UFS2_MAGIC	(int)0x19540119
#endif
#define CHECKSUM	(int)84446

#define TS_TAPE		1	/* dump tape header */
#define TS_INODE	2	/* beginning of file record */
#define TS_ADDR		4	/* continuation of file record */
#define TS_BITS		3	/* map of inodes on tape */
#define TS_CLRI		6	/* map of inodes deleted since last dump */
#define TS_END		5	/* end of volume marker */


/* types */
union u_spcl {
	char dummy[TP_BSIZE];
	struct s_spcl {
		int32_t c_type;
		int32_t c_old_date;
		int32_t c_old_ddate;
		int32_t c_volume;
		int32_t c_old_tapea;
		int32_t c_inumber;
		int32_t c_magic;
		int32_t c_checksum;
		union {
			struct {
				uint16_t __uc_mode;
				int16_t __uc_spare1[3];
				uint64_t __uc_size;
				int32_t __uc_old_atime;
				int32_t __uc_atimensec;
				int32_t __uc_old_mtime;
				int32_t __uc_mtimensec;
				int32_t __uc_spare2[2];
				int32_t __uc_rdev;
				int32_t __uc_birthtimensec;
				int64_t __uc_birthtime;
				int64_t __uc_atime;
				int64_t __uc_mtime;
				int32_t __uc_spare4[7];
				uint32_t __uc_file_flags;
				int32_t __uc_spare5[2];
				uint32_t __uc_uid;
				uint32_t __uc_gid;
				int32_t __uc_spare6[2];
			} __uc_ino;
		} __c_ino;
		int32_t c_count;
		char c_addr[TP_NINDIR];
		char c_label[LBLSIZE];
		int32_t c_level;
		char c_filesys[NAMELEN];
		char c_dev[NAMELEN];
		char c_host[NAMELEN];
		int32_t c_flags;
		int32_t c_old_firstrec;
		int64_t c_date;
		int64_t c_ddate;
		int64_t c_tapea;
		int64_t c_firstrec;
		int32_t c_spare[24];
	} s_spcl;
} u_spcl;


/* variables */
/* magic */
static unsigned char sigb[] = "\x00\x00\x00\x01";
static unsigned char sigl[] = "\x01\x00\x00\x00";

static PluginMagic dump_magic[] =
{
	{ sizeof(union u_spcl),	0,	sigb,	sizeof(sigb)-1	},
	{ sizeof(union u_spcl),	0,	sigl,	sizeof(sigl)-1	},
	{ 0,			0,	NULL,	0		}
};


/* functions */
static int dump_callback(PluginHelper * ph, int signature, FILE * fp);


/* plugin */
Plugin plugin =
{
	PT_ARCHIVE,
	"DUMP",
	dump_magic,
	dump_callback
};


/* private */
/* functions */
/* dump_callback */
static int _callback_big(PluginHelper * ph, union u_spcl * s);
static int _callback_little(PluginHelper * ph, union u_spcl * s);

static int dump_callback(PluginHelper * ph, int signature, FILE * fp)
{
	union u_spcl s;

	if((fread(&s, sizeof(s), 1, fp)) != 1)
		return -1;
	if(signature == 0)
		return _callback_big(ph, &s);
	return _callback_little(ph, &s);
}

static int _callback_big(PluginHelper * ph, union u_spcl * s)
{
	if(htob32(s->s_spcl.c_type) != TS_TAPE
			|| htob32(s->s_spcl.c_magic) != NFS_MAGIC)
		return -1;
	ph->printf(ph, "DUMP: big endian, volume #%d, host %s, level %d"
			", device %s, filesystem %s\n",
			htob32(s->s_spcl.c_volume), s->s_spcl.c_host,
			htob32(s->s_spcl.c_level), s->s_spcl.c_dev,
			s->s_spcl.c_filesys);
	return 100;
}

static int _callback_little(PluginHelper * ph, union u_spcl * s)
{
	if(htol32(s->s_spcl.c_type) != TS_TAPE
			|| htol32(s->s_spcl.c_magic) != NFS_MAGIC)
		return -1;
	ph->printf(ph, "DUMP: little endian, volume #%d, host %s, level %d"
			", device %s, filesystem %s\n",
			htol32(s->s_spcl.c_volume), s->s_spcl.c_host,
			htol32(s->s_spcl.c_level), s->s_spcl.c_dev,
			s->s_spcl.c_filesys);
	return 100;
}
