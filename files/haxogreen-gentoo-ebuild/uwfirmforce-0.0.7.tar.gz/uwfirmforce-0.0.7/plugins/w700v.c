/* $Id: w700v.c,v 1.1.1.1 2007/12/22 17:48:57 khorben Exp $ */



#include <stdint.h>
#include "plugin.h"


/* w700v */
/* types */
enum W700VUnknown
{
	UNK_VAL1 = 0x00080000,
				/* 1.00.000 #2 */
				/* 1.02.000 #2 */
				/* 1.22.000 #2, #3 */
				/* 2.05.999 #2, #3 */
				/* 2.06.000 #2, #3 */
	UNK_VAL2 = 0x00200000,
				/* 1.00.000 #1, #2 */
				/* 1.02.000 #1, #2 */
				/* 1.22.000 #1, #2 */
				/* 2.05.999 #1, #2 */
				/* 2.08.000 #1, #2 */
	UNK_VAL3 = 0x01000000,
				/* 1.00.000 #2, #3 */
				/* 1.02.000 #2, #3 */
				/* 2.05.999 #2 */
				/* 2.08.000 #2 */
	UNK_VAL4 = 0x02000000,
				/* 1.22.000 #4 */
				/* 2.05.999 #4 */
				/* 2.08.000 #4 */
	UNK_VAL5 = 0x10000000
				/* 1.00.000 #2 */
				/* 1.02.000 #2 */
				/* 2.05.999 #2 */
				/* 2.06.000 #2 */
				/* 2.08.000 #2 */
};

#pragma pack(1)
struct w700v
{
	char magic[4];
	uint32_t unknown1;
	uint32_t unknown2;
	uint32_t unknown3;
};
#pragma pack()

/* variables */
/* magic */
static unsigned char sig[] = "\x5d\x00\x00\x80";

static PluginMagic w700v_magic[] =
{
	{ 0,	0,	sig,	sizeof(sig)-1	},
	{ 0,	0,	NULL,	0		}
};


/* functions */
static int w700v_callback(PluginHelper * ph, int signature, FILE * fp);


/* plugin */
Plugin plugin =
{
	PT_ARCHIVE | PT_COMPRESSION,
	"W700V",
	w700v_magic,
	w700v_callback
};


/* private */
static int w700v_callback(PluginHelper * ph, int signature, FILE * fp)
{
	int score = 100;
	struct w700v buf;

	if(fread(&buf, sizeof(buf), 1, fp) != 1)
		return -1;
	ph->printf(ph, "unknown 0x%08x, unknown 0x%08x, unknown 0x%08x\n",
			buf.unknown1, buf.unknown2, buf.unknown3);
	if(buf.unknown2 == 0)
		score += 100;
	return score / 2;
}
