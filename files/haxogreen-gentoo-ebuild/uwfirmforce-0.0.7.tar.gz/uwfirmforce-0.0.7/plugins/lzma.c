/* $Id: lzma.c,v 1.1.1.1 2007/12/22 17:48:57 khorben Exp $ */
/* Copyright (c) 2007 khorben of Uberwall */



#include "plugin.h"


/* lzma */
/* public */
/* types */
struct lzma
{
	/* FIXME implement */
};


/* variables */
/* magic */
static unsigned char sig[] = "\xff\xff\xff\xff\xff";

static PluginMagic lzma_magic[] =
{
	/* FIXME implement */
	{ 0,	0,	NULL,	0	}
};


/* functions */
static int lzma_callback(PluginHelper * ph, int signature, FILE * fp);


/* plugin */
Plugin plugin =
{
	PT_ARCHIVE | PT_COMPRESSION,
	"LZMA",
	lzma_magic,
	lzma_callback
};


/* private */
/* functions */
/* lzma_callback */
static int lzma_callback(PluginHelper * ph, int signature, FILE * fp)
{
	return 100; /* FIXME implement */
}
