/* $Id: ace.c,v 1.1.1.1 2007/12/22 17:48:57 khorben Exp $ */
/* Copyright (c) 2007 khorben of Uberwall */
/* This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation version 2 of the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA */



#include <stdint.h>
#include <time.h>
#include "plugin.h"


/* ace */
/* public */
/* types */
#pragma pack(1)
struct ace
{
	uint16_t crc;
	uint16_t size;
	uint8_t type;
	uint16_t flags;
	char string[7];
	uint8_t extract;
	uint8_t create;
	uint8_t host;
	uint8_t volume;
	uint32_t time;
};
#pragma pack()


/* variables */
/* magic */
static unsigned char sig[] = "**ACE**";

static PluginMagic ace_magic[] =
{
	{ sizeof(struct ace),	7,	sig,	sizeof(sig)-1	},
	{ 0,			0,	NULL,	0,		}
};


/* functions */
static int ace_callback(PluginHelper * ph, int signature, FILE * fp);


/* plugin */
Plugin plugin =
{
	PT_ARCHIVE | PT_COMPRESSION,
	"ACE",
	ace_magic,
	ace_callback
};


/* private */
/* functions */
/* ace_callback */
static int _callback_size(PluginHelper * ph, uint16_t size);
static int _callback_time(PluginHelper * ph, time_t mtime);

static int ace_callback(PluginHelper * ph, int signature, FILE * fp)
{
	struct ace buf;
	int score = 0;

	if(fread(&buf, sizeof(buf), 1, fp) != 1)
		return 0;
	score+=_callback_size(ph, buf.size) / 2;
	score+=_callback_time(ph, buf.time) / 2;
	ph->printf(ph, "\n");
	return score;
}

static int _callback_size(PluginHelper * ph, uint16_t size)
{
	ph->printf(ph, "%s%d", "size ", size);
	return 100;
}

static int _callback_time(PluginHelper * ph, time_t mtime)
{
	struct tm tm;
	char tmp[22];

	if(gmtime_r(&mtime, &tm) == NULL || strftime(tmp, sizeof(tmp),
			", %d/%m/%Y %H:%M:%S", &tm) == 0)
	{
		ph->printf(ph, "%s", ", unknown date");
		return 0;
	}
	ph->printf(ph, "%s", tmp);
	return mtime < time(NULL) ? 100 : 0;
}
