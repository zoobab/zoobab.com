/* $Id: plugin.h,v 1.2 2008/04/15 15:21:09 khorben Exp $ */
/* Copyright (c) 2007 khorben of Uberwall */
/* This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation version 2 of the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA */



#ifndef UWFIRMFORCE_PLUGIN_H
# define UWFIRMFORCE_PLUGIN_H

# include <stdint.h>
# if defined(__NetBSD__) || defined(__OpenBSD__) || defined(__FreeBSD__)
#  include <sys/endian.h>
# elif defined(__linux__)
#  include <endian.h>
/* # else
#  warning "Unable to detect endian on your system" */
# endif
# include <stdio.h>


/* types */
typedef enum _PluginType
{
	PT_ARCHIVE	= 0x1,
	PT_COMPRESSION	= 0x2,
	PT_FORENSIC	= 0x4,
	PT_EXECUTABLE	= 0x8
} PluginType;

typedef struct _PluginHelperData PluginHelperData;

typedef struct _PluginHelper
{
	/* private */
	PluginHelperData * data;

	/* functions */
	int (*printf)(struct _PluginHelper * ph, char const * format, ...);
} PluginHelper;

typedef struct _PluginMagic
{
	size_t overhead;
	size_t offset;
	unsigned char const * magic;
	size_t magic_len;
} PluginMagic;

typedef struct _Plugin
{
	PluginType type;
	char const * name;

	/* signature matching */
	PluginMagic * magic;
	int (*callback)(PluginHelper * ph, int signature, FILE * fp);
} Plugin;

typedef struct _PluginHandle PluginHandle;


/* macros */
# if BYTE_ORDER == BIG_ENDIAN 
#  define htob16(a) (a) 
#  define htol16(a) ((a) << 8 | (a) >> 8)
#  define htob32(a) (a) 
#  define htol32(a) ((a) << 24 | (((a) >> 8) << 24) | (((a) << 8) >> 24) \
		| (a) >> 24)
#  define htob64(a) (a)
#  define htol64(a) ((a) << 56 | (((a) >> 8) << 48) | (((a) >> 16) << 40) \
		| (((a) >> 24) << 32) | (((a) >> 32) << 24) \
		| (((a) >> 40) << 16) | (((a) >> 48) << 8) | (a) >> 56)
# else
#  define htob16(a) ((a) << 8 | (a) >> 8)
#  define htol16(a) (a)
#  define htob32(a) ((a) << 24 | (((a) >> 8) << 24) | (((a) << 8) >> 24) \
		| (a) >> 24)
#  define htol32(a) (a) 
#  define htob64(a) ((a) << 56 | (((a) >> 8) << 48) | (((a) >> 16) << 40) \
		| (((a) >> 24) << 32) | (((a) >> 32) << 24) \
		| (((a) >> 40) << 16) | (((a) >> 48) << 8) | (a) >> 56)
#  define htol64(a) (a)
# endif


/* functions */
PluginHandle * plugin_new(char const * filename);
void plugin_delete(PluginHandle * plugin);

/* accessors */
char const * plugin_get_name(PluginHandle * plugin);
size_t plugin_get_buffer_size(PluginHandle * plugin);

/* useful */
int plugin_do(PluginHandle * plugin, int signature, int verbose,
		char const * filename, FILE * fp);
void plugin_info(PluginHandle * plugin);
int plugin_match(PluginHandle * plugin, char const * buf, size_t buf_cnt);

#endif /* !UWFIRMFORCE_PLUGIN_H */
