/* $Id: bzip2.c,v 1.1.1.1 2007/12/22 17:48:57 khorben Exp $ */
/* Copyright (c) 2007 khorben of Uberwall */
/* This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation version 2 of the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA */



#include <stdio.h>
#include <string.h>
#include "plugin.h"


/* bzip2 */
/* public */
/* variables */
/* magic */
static unsigned char sig1[] = "BZh1\x31\x41\x59\x26\x53\x59";
static unsigned char sig2[] = "BZh2\x31\x41\x59\x26\x53\x59";
static unsigned char sig3[] = "BZh3\x31\x41\x59\x26\x53\x59";
static unsigned char sig4[] = "BZh4\x31\x41\x59\x26\x53\x59";
static unsigned char sig5[] = "BZh5\x31\x41\x59\x26\x53\x59";
static unsigned char sig6[] = "BZh6\x31\x41\x59\x26\x53\x59";
static unsigned char sig7[] = "BZh7\x31\x41\x59\x26\x53\x59";
static unsigned char sig8[] = "BZh8\x31\x41\x59\x26\x53\x59";
static unsigned char sig9[] = "BZh9\x31\x41\x59\x26\x53\x59";
static unsigned char flbck1[] = "\x31\x41\x59\x26\x53\x59";
static unsigned char flbck2[] = "\x17\x72\x45\x38\x50\x90";
static unsigned char flbck3[] = "BZh";

static PluginMagic bzip2_magic[] =
{
	{ 0,	0,	sig1,	sizeof(sig1)-1	},
	{ 0,	0,	sig2,	sizeof(sig2)-1	},
	{ 0,	0,	sig3,	sizeof(sig3)-1	},
	{ 0,	0,	sig4,	sizeof(sig4)-1	},
	{ 0,	0,	sig5,	sizeof(sig5)-1	},
	{ 0,	0,	sig6,	sizeof(sig6)-1	},
	{ 0,	0,	sig7,	sizeof(sig7)-1	},
	{ 0,	0,	sig8,	sizeof(sig8)-1	},
	{ 0,	0,	sig9,	sizeof(sig9)-1	},
	{ 0,	4,	flbck1,	sizeof(flbck1)-1},
	{ 0,	4,	flbck2,	sizeof(flbck2)-1},
	{ 0,	0,	flbck3,	sizeof(flbck3)-1},
	{ 0,	0,	NULL,	0,		}
};


/* functions */
static int bzip2_callback(PluginHelper * ph, int signature, FILE * fp);


/* plugin */
Plugin plugin =
{
	PT_ARCHIVE | PT_COMPRESSION,
	"BZIP2",
	bzip2_magic,
	bzip2_callback
};


/* private */
/* functions */
/* bzip2_callback */
static int bzip2_callback(PluginHelper * ph, int signature, FILE * fp)
{
	char buf[4+sizeof(flbck1)];

	if(fread(&buf, sizeof(buf), 1, fp) != 1)
		return 0;
	if(strncmp("BZh", buf, 3) != 0)
		return 0;
	if(buf[3] < '0' || buf[3] > '9')
		return 0;
	ph->printf(ph, "compression %c\n", buf[3]);
	if(memcmp(&buf[4], flbck1, sizeof(flbck1)-1) == 0
			|| memcmp(&buf[4], flbck2, sizeof(flbck2)-1) == 0)
		return 100;
	return 50;
}
