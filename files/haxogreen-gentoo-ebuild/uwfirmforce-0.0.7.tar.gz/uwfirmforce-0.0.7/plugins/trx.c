/* $Id: trx.c,v 1.2 2008/01/10 18:39:42 khorben Exp $ */
/* Copyright (c) 2007 khorben of Uberwall */
/* This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation version 2 of the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA */



#include <stdint.h>
#include "plugin.h"


/* trx */
/* public */
/* types */
#pragma pack(1)
struct trx
{
	uint32_t magic;
	uint32_t len;
	uint32_t crc;
	uint16_t flags;		/* FIXME not sure about flags|version */
	uint16_t version;
	uint32_t offset[3];
};
#pragma pack()


/* constants */
#define TRX_MAGIC	0x30524448


/* variables */
/* magic */
static unsigned char sig1[] = "HDR0";
static unsigned char sig2[] = "0RDH";

static PluginMagic trx_magic[] =
{
	{ 0,	0,	sig1,	sizeof(sig1)-1	},
	{ 0,	0,	sig2,	sizeof(sig2)-1	},
	{ 0,	0,	NULL,	0		}
};


/* functions */
static int trx_callback(PluginHelper * ph, int signature, FILE * fp);


/* plugin */
Plugin plugin =
{
	PT_ARCHIVE,
	"TRX",
	trx_magic,
	trx_callback
};


/* private */
/* functions */
/* trx_callback */
static void _callback_endian_little(struct trx * hdr);
static void _callback_endian_big(struct trx * hdr);

static int trx_callback(PluginHelper * ph, int signature, FILE * fp)
{
	int score = 100;
	struct trx buf;

	ph->printf(ph, "%s, ", signature == 0 ? "big endian" : "little endian");
	if(fread(&buf, sizeof(buf), 1, fp) != 1)
		return -1;
	if(buf.magic != TRX_MAGIC)
	{
		if(htol32(buf.magic) == TRX_MAGIC)
			_callback_endian_little(&buf);
		else if(htob32(buf.magic) == TRX_MAGIC)
			_callback_endian_big(&buf);
		else
			score = 0;
	}
	if(buf.version == 1)
		score += 100;
	ph->printf(ph, "%s%u%s%u%s%u%s%08x%s%08x%s%08x\n", "length ",
			buf.len, ", flags ", buf.flags, ", version ",
			buf.version, ", offset #0 0x", buf.offset[0],
			", offset #1 0x", buf.offset[1], ", offset #2 0x",
			buf.offset[2]); /* FIXME check offsets */
	return score / 2;
}

static void _callback_endian_little(struct trx * hdr)
{
	int i;

	hdr->magic = htol32(hdr->magic);
	hdr->len = htol32(hdr->len);
	hdr->crc = htol32(hdr->crc);
	hdr->flags = htol16(hdr->flags);
	hdr->version = htol16(hdr->version);
	for(i = 0; i < 3; i++)
		hdr->offset[i] = htol32(hdr->offset[i]);
}

static void _callback_endian_big(struct trx * hdr)
{
	int i;

	hdr->magic = htob32(hdr->magic);
	hdr->len = htob32(hdr->len);
	hdr->crc = htob32(hdr->crc);
	hdr->flags = htob16(hdr->flags);
	hdr->version = htob16(hdr->version);
	for(i = 0; i < 3; i++)
		hdr->offset[i] = htob32(hdr->offset[i]);
}
