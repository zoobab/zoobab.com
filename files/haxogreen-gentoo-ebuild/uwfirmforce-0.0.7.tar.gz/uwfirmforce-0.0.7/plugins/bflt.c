/* $Id: bflt.c,v 1.1.1.1 2007/12/22 17:48:57 khorben Exp $ */
/* Copyright (c) 2007 khorben of Uberwall */
/* This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation version 2 of the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA */



#include <stdint.h>
#include "plugin.h"


/* bflt */
/* public */
/* types */
#pragma pack(1)
struct flat_hdr
{
	char magic[4];
	uint32_t rev;
	uint32_t entry;
	uint32_t data_start;
	uint32_t data_end;
	uint32_t bss_end;
	uint32_t stack_size;
	uint32_t reloc_start;
	uint32_t reloc_count;
	uint32_t flags;
	uint32_t filler[6];
};
#pragma pack()


/* constants */
#define FLAT_FLAG_RAM		0x0001
#define FLAT_FLAG_GOTPIC	0x0002
#define FLAT_FLAG_GZIP		0x0004


/* variables */
/* magic */
static unsigned char sig[] = "bFLT";

static PluginMagic bflt_magic[] =
{
	{ sizeof(struct flat_hdr),	0,	sig,	sizeof(sig)-1	},
	{ 0,				0,	NULL,	0		}
};


/* functions */
static int bflt_callback(PluginHelper * ph, int signature, FILE * fp);


/* plugin */
Plugin plugin =
{
	PT_COMPRESSION | PT_EXECUTABLE,
	"BFLT",
	bflt_magic,
	bflt_callback
};


/* functions */
/* bflt_callback */
static int _callback_version(PluginHelper * ph, uint32_t version);
static int _callback_offsets(PluginHelper * ph, uint32_t data_start,
		uint32_t data_end, uint32_t bss_end);
static int _callback_stack(PluginHelper * ph, uint32_t stack_size);
static int _callback_reloc(PluginHelper * ph, uint32_t reloc_start,
		uint32_t reloc_count);
static int _callback_flags(PluginHelper * ph, uint32_t flags);

static int bflt_callback(PluginHelper * ph, int signature, FILE * fp)
{
	int score = 0;
	struct flat_hdr buf;

	if(fread(&buf, sizeof(buf), 1, fp) != 1)
		return 0;
	score+=_callback_version(ph, buf.rev);
	score+=_callback_offsets(ph, buf.data_start, buf.data_end, buf.bss_end);
	score+=_callback_stack(ph, buf.stack_size);
	score+=_callback_reloc(ph, buf.reloc_start, buf.reloc_count);
	score+=_callback_flags(ph, buf.flags);
	ph->printf(ph, "\n");
	return score / 5;
}

static int _callback_version(PluginHelper * ph, uint32_t version)
{
	ph->printf(ph, "%s%u", "version ", version);
	if(version == 2 || version == 4)
		return 100;
	if(version <= 4)
		return 50;
	return 0;
}

static int _callback_offsets(PluginHelper * ph, uint32_t data_start, uint32_t data_end,
		uint32_t bss_end)
{
	ph->printf(ph, "%s%x%s%x%s%x", ", data_start 0x", data_start,
			", data_end 0x", data_end, ", bss_end 0x", bss_end);
	if(data_start >= sizeof(struct flat_hdr) && data_end > data_start
			&& (bss_end > data_end || bss_end <= data_start))
		return 100;
	return 0;
}

static int _callback_stack(PluginHelper * ph, uint32_t stack_size)
{
	ph->printf(ph, "%s%x", ", stack_size 0x", stack_size);
	if(stack_size == 0x2000)
		return 100;
	return 50;
}

static int _callback_reloc(PluginHelper * ph, uint32_t reloc_start,
		uint32_t reloc_count)
{
	ph->printf(ph, "%s%u%s%x", ", ", reloc_count, " relocations at 0x",
			reloc_start);
	return 100;
}

static int _callback_flags(PluginHelper * ph, uint32_t flags)
{
	static const struct
	{
		uint32_t flag;
		char const * string;
	}
	name[] =
	{
		{ FLAT_FLAG_RAM,	"loaded in RAM"		},
		{ FLAT_FLAG_GOTPIC,	"is PIC with GOT"	},
		{ FLAT_FLAG_GZIP,	"compressed" 		},
		{ 0,			NULL			}
	};
	unsigned int i;

	for(i = 0; name[i].string != NULL; i++)
		if((flags & name[i].flag) == name[i].flag)
			ph->printf(ph, "%s%s", ", ", name[i].string);
	return flags & ~(FLAT_FLAG_RAM | FLAT_FLAG_GOTPIC | FLAT_FLAG_GZIP)
		? 0 : 100;
}
