/* $Id: tar.c,v 1.1.1.1 2007/12/22 17:48:57 khorben Exp $ */
/* Copyright (c) 2007 khorben of Uberwall */
/* This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation version 2 of the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA */



#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include "plugin.h"

#define max(a, b) ((a) > (b) ? (a) : (b))


/* tar */
/* public */
/* types */
#pragma pack(1)
struct tar
{
	char filename[100];
	char mode[8];
	char uid[8];
	char gid[8];
	char size[12];
	char mtime[12];
	char checksum[8];
	uint8_t type;
	char link[100];
};
#pragma pack()


/* variables */
/* magic */
static unsigned char sig[] = "ustar";

static PluginMagic tar_magic[] =
{
	{ 512,	257,	sig,	sizeof(sig)-1	},
	{ 0,	0,	NULL,	0		}
};


/* functions */
static int tar_callback(PluginHelper * ph, int signature, FILE * fp);


/* plugin */
Plugin plugin =
{
	PT_ARCHIVE,
	"TAR",
	tar_magic,
	tar_callback
};


/* private */
/* functions */
/* tar_callback */
static int _callback_filename(PluginHelper * ph, struct tar * buf);
static int _callback_mode(PluginHelper * ph, struct tar * buf);
static int _callback_uid(PluginHelper * ph, struct tar * buf);
static int _callback_gid(PluginHelper * ph, struct tar * buf);
static int _callback_mtime(PluginHelper * ph, struct tar * buf);

static int tar_callback(PluginHelper * ph, int signature, FILE * fp)
{
	int score = 0;
	struct tar buf;

	if(fread(&buf, sizeof(buf), 1, fp) != 1)
		return 0;
	score += _callback_filename(ph, &buf);
	score += _callback_mode(ph, &buf);
	score += _callback_uid(ph, &buf);
	score += _callback_gid(ph, &buf);
	score += _callback_mtime(ph, &buf);
	ph->printf(ph, "\n");
	return score / 5;
}

static int _callback_filename(PluginHelper * ph, struct tar * buf)
{
	char tmp[sizeof(buf->filename)+1];

	memcpy(tmp, buf->filename, sizeof(buf->filename));
	tmp[sizeof(tmp)-1] = '\0';
	ph->printf(ph, "%s%s%s", "filename \"", tmp, "\"");
	return 100;
}

static int _callback_mode(PluginHelper * ph, struct tar * buf)
{
	char tmp[sizeof(buf->mode)+1];
	size_t i;
	int score = 0;

	memcpy(tmp, buf->mode, sizeof(buf->mode));
	tmp[sizeof(tmp)-1] = '\0';
	ph->printf(ph, "%s%s", ", mode ", tmp);
	for(i = 0; i < sizeof(tmp)-1; i++)
		if(tmp[i] >= '0' && tmp[i] <= '7')
			score+=14;
	return score + 2;
}

static int _callback_uid(PluginHelper * ph, struct tar * buf)
{
	unsigned char tmp[sizeof(buf->uid)+1];
	size_t i;
	int score = 0;

	memcpy(tmp, buf->uid, sizeof(buf->uid));
	tmp[sizeof(tmp)-1] = '\0';
	ph->printf(ph, "%s%s", ", uid ", tmp);
	for(i = 0; i < sizeof(tmp)-1; i++)
		if((tmp[i] >= '0' && tmp[i] <= '7') || isalpha(tmp[i]))
			score+=14;
	return score + 2;
}

static int _callback_gid(PluginHelper * ph, struct tar * buf)
{
	unsigned char tmp[sizeof(buf->gid)+1];
	size_t i;
	int score = 0;

	memcpy(tmp, buf->gid, sizeof(buf->gid));
	tmp[sizeof(tmp)-1] = '\0';
	ph->printf(ph, "%s%s", ", gid ", tmp);
	for(i = 0; i < sizeof(tmp)-1; i++)
		if((tmp[i] >= '0' && tmp[i] <= '7') || isalpha(tmp[i]))
			score+=14;
	return score + 2;
}

static int _callback_mtime(PluginHelper * ph, struct tar * buf)
{
	char tmp[max(sizeof(buf->mtime)+1, 22)];
	time_t mtime;
	char * p;
	size_t i;
	int score = 0;
	struct tm tm;

	memcpy(tmp, buf->mtime, sizeof(buf->mtime));
	tmp[sizeof(tmp)-1] = '\0';
	mtime = strtol(tmp, &p, 8);
	if(*tmp == '\0' || *p != '\0')
	{
		ph->printf(ph, "%s%s", ", mtime ", tmp);
		for(i = 0; i < sizeof(tmp)-1; i++)
			if((tmp[i] >= '0' && tmp[i] <= '7') || isalpha(tmp[i]))
				score+=14;
		return score + 2;
	}
	if((gmtime_r(&mtime, &tm)) == NULL || strftime(tmp, sizeof(tmp),
				", %d/%m/%Y %H:%M:%S", &tm) == 0)
	{
		ph->printf(ph, "%s", ", unknown date");
		return 0;
	}
	ph->printf(ph, "%s", tmp);
	return mtime < time(NULL) ? 100 : 0;
}
