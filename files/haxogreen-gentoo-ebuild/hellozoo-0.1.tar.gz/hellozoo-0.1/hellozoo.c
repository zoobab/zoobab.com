/* hello.c: display a message on the screen */

#include <stdio.h>

main()
{
	printf("hello, zoobab\n");
}
